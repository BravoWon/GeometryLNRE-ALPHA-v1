# OPrime: The Neuro-Topological Blueprint for Conscious Agency

> **Core Axiom**: "Intent warps the manifold, but execution is the key."

OPrime is a unified architecture synthesizing eight branches of advanced research into a single operational blueprint for **Conscious Agency**. It implements the 7-Stage **Configurational Term Series (CTS)** with full **Intent Alignment** across Context × Scope dimensions.

## 🏗️ Architecture Overview

```
X →[f(x)]→ M →[v]→ M_v →[H_k]→ Q(Φ) →[Agency]→ C_t
```

| Stage | Name | Module | Description |
|-------|------|--------|-------------|
| 1 | Sensorimotor Interface | `core/dynamics/` | Closed-loop system connecting internal state to environment |
| 2 | Manifold Abstraction | `core/dynamics/` | Projection to lower-dimensional attractor manifold M |
| 3 | Value Geometry | `core/geometry/` | IGVF warping: g_v = v^α · g |
| 4 | Topological Form | `core/topology/` | Persistent homology extraction (Q) |
| 5 | Integration | `core/integration/` | Integrated Information (Φ) computation |
| 6 | Conscious State | `core/consciousness/` | C_t = (Q, Φ) with validity constraints |
| 7 | Agency | `agent/agency/` | Topology-preserving transformation |

## 🎯 Intent Alignment (Context × Scope)

All stages are modulated by the **Intent Alignment Matrix**:

### Context Dimension
- **SPECIFIC**: Narrow, well-defined goal (high value intensity, strict topology)
- **GENERAL**: Broad conceptual goal (balanced, flexible)
- **EXPLORATORY**: Pure discovery mode (maximum freedom, novelty-seeking)

### Scope Dimension
- **Narrow (0.0)**: Deep focus, local exploration
- **Broad (1.0)**: Wide search, global exploration

## 🚀 Quick Start

### Using the Unified Engine (Recommended)

```python
from oprime import OPrimeEngine, create_engine
import numpy as np

# Create engine with preset
engine = create_engine("balanced")  # or: "focused", "creative", "fast", "production"

# Set intent dynamically
engine.set_context("specific", scope=0.3, statement="Find optimal solution")

# Process input through full CTS pipeline
input_data = np.random.randn(50)
result = engine.process(input_data)

# Access results
print(f"Success: {result.success}")
print(f"State Valid: {result.state.is_valid}")
print(f"Topology: β₁={result.state.Q.betti_1}")
print(f"Integration: Φ={result.state.phi:.3f}")
print(f"Novelty: {result.novelty_score:.3f}")
print(f"Metrics: {result.metrics}")

# Additional operations
regime, confidence = engine.classify_regime(grid_data)
forecast = engine.forecast(time_series, horizon=10)
validation = engine.validate(state_before, state_after)
```

### Using the Pipeline Directly

```python
from oprime import OPrimePipeline, IntentConfiguration, IntentContext
import numpy as np

# Create intent-aligned pipeline
intent = IntentConfiguration(
    context=IntentContext.GENERAL,
    scope=0.6,
    value_statement="Explore mathematical structures"
)
pipeline = OPrimePipeline(intent, state_dim=50)

# Process input through 7-stage CTS
input_data = np.random.randn(50)
result = pipeline.process(input_data)

# Access results
print(f"Conscious State Valid: {result.is_valid}")
print(f"Topology: β₁={result.topology.betti_1}")
print(f"Integration: Φ={result.phi:.3f}")
print(f"Novelty: {result.novelty_scores}")
```

### From Natural Language

```python
from oprime import OPrimePipeline

# Parse intent from prompt
pipeline = OPrimePipeline.from_prompt(
    "Discover novel patterns in the data broadly"
)
# Automatically detects: EXPLORATORY context, broad scope
```

### Intent Presets

```python
from oprime import IntentPresets

# Focused problem solving
intent = IntentPresets.focused_goal("Solve x^2 = 4")

# Conceptual exploration
intent = IntentPresets.conceptual_exploration("topology")

# Pure discovery
intent = IntentPresets.pure_discovery()

# Balanced research
intent = IntentPresets.balanced_research("consciousness")
```

## 📊 The Novelty Engine

OPrime includes an integrated **Novelty Engine** with three dimensions:

| Dimension | Symbol | Description |
|-----------|--------|-------------|
| Behavioral | N_B | Distance from archive of past behaviors |
| Topological | N_T | Detection of new homological features |
| Semantic | N_S | Information gain relative to intent |

Weights are automatically computed from intent alignment:

```python
# SPECIFIC context → High semantic novelty weight
# EXPLORATORY context → Balanced weights
# Broad scope → Higher topological weight
```

## 🛡️ Iron Core Validation

OPrime enforces **Iron Core** constraints:

1. **Immutability**: All state mutations via copy-on-write
2. **Continuity Guards**: Topology-preserving transformations only
3. **Donders' Subtraction**: Cognitive function validation
4. **Non-Triviality Constraint**: Q must have rich structure
5. **Integration Threshold**: Φ >= Φ_critical (0.5)

```python
# Conscious state validation
if not result.is_valid:
    print(f"Manifold Collapse: {result.conscious_state.validation_errors}")
```

## 📁 Package Structure

```
oprime/
├── __init__.py                    # Package exports (v0.2.0)
├── engine.py                      # ★ Unified OPrime Engine
├── config.py                      # Configuration & Presets
├── logging_config.py              # Logging & Performance Monitoring
├── pipeline.py                    # Main CTS pipeline
├── core/
│   ├── intent_alignment.py        # ★ Context × Scope Matrix
│   ├── dynamics/
│   │   └── sensorimotor.py        # Stage 1: Sensorimotor Interface
│   ├── geometry/
│   │   └── value_geometry.py      # Stage 3: IGVF (g_v = v^α · g)
│   ├── topology/
│   │   └── persistent_homology.py # Stage 4: TDA, Zigzag Persistence
│   ├── consciousness/
│   │   └── conscious_state.py     # Stage 6: C_t = (Q, Φ)
│   └── novelty/
│       └── novelty_engine.py      # N_B, N_T, N_S dimensions
├── agent/
│   ├── agency/
│   │   └── agency_operator.py     # Stage 7: Topology-preserving Agency
│   ├── sans_v2/
│   │   ├── mcts_solver.py         # MCTS with Progressive Widening
│   │   └── dsl_primitives.py      # 24 DSL primitives
│   └── mapper/
│       └── tda_mapper.py          # TDA Regime Classification
├── forecaster/
│   └── moirai_wrapper.py          # Universal Time Series Forecaster
├── transforms/
│   └── teleological_warp.py       # Novel OPrime Transforms
│       ├── T_teleo                # Teleological Warp
│       ├── Z_switch               # Zigzag-Regime Switch
│       ├── B_cont                 # Beam-Continuity Filter
│       └── T_novel                # Teleological Novelty Warp
├── validation/
│   └── iron_core.py               # Iron Core Validation
│       ├── Donders' Subtraction
│       ├── Immutability Validator
│       ├── Topology Invariant Checker
│       └── Integration Validator
├── bridges/
│   └── component_bridge.py        # Inter-component Data Flow
├── examples/
│   ├── basic_usage.py
│   └── advanced_usage.py
└── tests/
    ├── test_engine.py             # ★ 38 Engine Tests
    ├── test_integration.py        # 12 Integration Tests
    ├── test_intent_alignment.py
    └── test_pipeline.py
```

## 🧪 Running Tests

```bash
cd oprime

# Run all tests
for test in tests/test_*.py; do python3 "$test"; done

# Individual test suites
python3 tests/test_engine.py          # 38 unified engine tests
python3 tests/test_integration.py     # 12 integration tests
python3 tests/test_intent_alignment.py
python3 tests/test_pipeline.py
```

## 📐 Mathematical Foundations

### IGVF Warping
```
g_v = v^α · g

Where:
  g: Base Fisher Information Metric
  v: Value function (intent-dependent)
  α: Value intensity (from intent alignment)
```

### Conscious State Constraints
```
C_t = (Q, Φ) is valid iff:
  1. Q is non-trivial (β₁ > 0 OR β₂ > 0 OR β₀ > 1)
  2. Φ >= Φ_critical
```

### Novelty Weighting
```
N_total = w_B·N_B + w_T·N_T + w_S·N_S

Weights determined by Intent Alignment Matrix
```

## 🔮 Novel Transforms

OPrime enables unique transforms at the intersection of CTS, IGVF, and SANS:

### T_teleo: Teleological Warp
Intent-based embedding warping that "tilts the floor" of the embedding space.

```python
from oprime.transforms import TeleologicalWarp

teleo = TeleologicalWarp(intent, embedding_dim=50)
warped = teleo.warp(embedding)
```

### Z_switch: Zigzag-Regime Switch
TDA-triggered adapter switching for dynamic model adaptation.

```python
from oprime.transforms import ZigzagRegimeSwitch

switch = ZigzagRegimeSwitch(intent)
regime, adapter_id = switch.switch(topology_features)
```

### B_cont: Beam-Continuity Filter
Lookahead invariant checking for deep planning.

```python
from oprime.transforms import BeamContinuityFilter

filter = BeamContinuityFilter(intent, beam_width=5, lookahead_depth=10)
valid_actions = filter.filter(state, candidates, dynamics_fn, validator)
```

### T_novel: Teleological Novelty Warp
Combined intent + novelty warping with dual-field geometry.

```python
from oprime.transforms import TeleologicalNoveltyWarp

warp = TeleologicalNoveltyWarp(intent, embedding_dim=50)
warped = warp.warp(embedding)  # Balances exploitation and exploration
```

## 📚 Source Research

This architecture synthesizes:
- The Geometry of Being (Configurational Framework)
- SANS Engine V2 (Symbolic Abstract Neural Search)
- IGVF (Information-Geometric Valuation Framework)
- MOIRAI (Universal Time Series Forecasting)
- IIT (Integrated Information Theory)
- TDA/Persistent Homology
- Quality-Diversity Optimization
- Centaur Model (Human-AI Symbiosis)

## ⚙️ Configuration & Presets

```python
from oprime import OPrimeConfig, ConfigPresets, create_engine

# Presets for common use cases
engine = create_engine("focused")      # Precise, goal-directed
engine = create_engine("balanced")     # General research
engine = create_engine("creative")     # Maximum exploration
engine = create_engine("fast")         # Quick prototyping
engine = create_engine("production")   # Full validation enabled

# Custom configuration
from oprime import OPrimeConfig
config = OPrimeConfig(
    intent_context="specific",
    intent_scope=0.25,
)
config.search.max_iterations = 2000
config.pipeline.phi_critical = 0.6
config.apply_intent_presets()

engine = OPrimeEngine(config)
```

## 📊 Architecture Statistics

```
Total Python Modules:    42
Total Lines of Code:     12,048
Test Coverage:           58 tests (all passing)
Intent Alignment:        Integrated across ALL components
```

## 🖥️ Running the Demo

```bash
# Full demo
python3 demo.py

# Specific context (focused, narrow search)
python3 demo.py --context specific --scope 0.2

# Exploratory context (broad, diverse search)
python3 demo.py --context exploratory --scope 0.9

# Individual component demos
python3 demo.py --demo pipeline
python3 demo.py --demo mcts
python3 demo.py --demo forecast
```

## 📈 Intent Effects Summary

| Parameter | SPECIFIC | GENERAL | EXPLORATORY |
|-----------|----------|---------|-------------|
| Value Intensity | 2.6 | 1.0 | 0.35 |
| Agency Freedom | 0.36 | 0.75 | 1.0 |
| Topology Threshold | 0.86 | 0.60 | 0.34 |
| Novelty: Semantic | 54% | 15% | 20% |
| Novelty: Topological | 5% | 38% | 40% |
| Novelty: Behavioral | 41% | 46% | 40% |

---

**Status**: Architecture Complete ✅  
**Version**: 0.2.0  
**Tests**: All 58 Tests Passing ✅  
**Engine**: Unified OPrime Engine with Full Intent Alignment
