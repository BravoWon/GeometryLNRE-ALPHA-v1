"""
SIIP: System Intent Integration Protocol
========================================

Protocol for integrating probabilistic AI outputs into deterministic 
Verification & Validation (V&V) workflows.

From the knowledge library (SIIP Protocol V&V Integration Analysis):
    AI Output → Probabilistic Assessment → SIIP Transform → V&V Compatible

The core challenge: AI systems produce probabilistic outputs with uncertainty,
while V&V workflows require deterministic assertions with clear pass/fail.
SIIP bridges this gap through:

1. Confidence Thresholding: Convert probabilities to categorical decisions
2. Evidence Accumulation: Aggregate multiple assessments for robustness
3. Conservative Bounds: Ensure safety through pessimistic bounds
4. Audit Trail: Complete traceability from AI output to V&V assertion
5. Intent Alignment: Modulate strictness based on operational context

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │                    SIIP PROTOCOL STACK                           │
    ├─────────────────────────────────────────────────────────────────┤
    │  Layer 4: V&V Integration    │ Pass/Fail Assertions, Audit Trail│
    │  Layer 3: Decision Transform │ Thresholding, Aggregation        │
    │  Layer 2: Evidence Layer     │ Confidence, Uncertainty Bounds   │
    │  Layer 1: AI Output Layer    │ Probabilistic Assessments        │
    └─────────────────────────────────────────────────────────────────┘

Intent Alignment:
    - SPECIFIC: Conservative thresholds, strict V&V requirements
    - GENERAL: Balanced thresholds, standard V&V
    - EXPLORATORY: Lenient thresholds, informational V&V
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Callable
from enum import Enum
from datetime import datetime
import numpy as np
import copy
import hashlib

from ..core.intent_alignment import (
    IntentConfiguration,
    IntentAlignedOperator,
    IntentContext,
)


class AssessmentType(Enum):
    """Types of AI assessments that need V&V integration."""
    CLASSIFICATION = "classification"
    REGRESSION = "regression"
    ANOMALY_DETECTION = "anomaly_detection"
    SEQUENCE_PREDICTION = "sequence_prediction"
    CONSTRAINT_CHECK = "constraint_check"
    TOPOLOGY_VALIDATION = "topology_validation"


class VVDecision(Enum):
    """V&V-compatible decision outcomes."""
    PASS = "pass"
    FAIL = "fail"
    INDETERMINATE = "indeterminate"
    REQUIRES_HUMAN_REVIEW = "requires_human_review"


@dataclass
class ProbabilisticAssessment:
    """
    Layer 1: AI Output Layer
    
    Represents a probabilistic assessment from an AI system.
    """
    assessment_id: str
    assessment_type: AssessmentType
    timestamp: float
    
    # Probabilistic outputs
    prediction: Any
    confidence: float  # [0, 1]
    uncertainty: float  # Standard deviation or similar
    
    # Optional distribution parameters
    distribution_type: str = "point_estimate"
    distribution_params: Dict[str, float] = field(default_factory=dict)
    
    # Metadata
    model_id: str = "unknown"
    input_hash: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def lower_bound(self) -> float:
        """Conservative lower bound (2-sigma)."""
        if isinstance(self.prediction, (int, float)):
            return self.prediction - 2 * self.uncertainty
        return float('-inf')
    
    @property
    def upper_bound(self) -> float:
        """Conservative upper bound (2-sigma)."""
        if isinstance(self.prediction, (int, float)):
            return self.prediction + 2 * self.uncertainty
        return float('inf')


@dataclass
class EvidencePacket:
    """
    Layer 2: Evidence Layer
    
    Aggregates multiple assessments into a unified evidence packet.
    """
    packet_id: str
    assessments: List[ProbabilisticAssessment]
    
    # Aggregated statistics
    mean_confidence: float = 0.0
    confidence_variance: float = 0.0
    consensus_prediction: Any = None
    disagreement_score: float = 0.0
    
    # Evidence quality
    sample_size: int = 0
    temporal_span: float = 0.0  # Time span of assessments
    
    def __post_init__(self):
        self._compute_aggregates()
    
    def _compute_aggregates(self):
        """Compute aggregate statistics from assessments."""
        if not self.assessments:
            return
        
        self.sample_size = len(self.assessments)
        
        # Confidence statistics
        confidences = [a.confidence for a in self.assessments]
        self.mean_confidence = np.mean(confidences)
        self.confidence_variance = np.var(confidences)
        
        # Temporal span
        timestamps = [a.timestamp for a in self.assessments]
        self.temporal_span = max(timestamps) - min(timestamps)
        
        # Disagreement (using prediction variance for numeric)
        predictions = [a.prediction for a in self.assessments 
                       if isinstance(a.prediction, (int, float))]
        if predictions:
            pred_variance = np.var(predictions)
            pred_mean = np.mean(predictions)
            self.disagreement_score = (
                np.sqrt(pred_variance) / (abs(pred_mean) + 1e-10)
            )
            self.consensus_prediction = pred_mean
        else:
            # For non-numeric: use mode
            from collections import Counter
            pred_counts = Counter(str(a.prediction) for a in self.assessments)
            if pred_counts:
                self.consensus_prediction = pred_counts.most_common(1)[0][0]
                top_count = pred_counts.most_common(1)[0][1]
                self.disagreement_score = 1.0 - (top_count / self.sample_size)


@dataclass
class SIIPTransformConfig:
    """
    Layer 3: Decision Transform Configuration
    
    Configures how probabilistic assessments are converted to V&V decisions.
    """
    # Confidence thresholds
    pass_threshold: float = 0.95
    fail_threshold: float = 0.3
    indeterminate_band: Tuple[float, float] = (0.3, 0.95)
    
    # Evidence requirements
    min_sample_size: int = 1
    max_disagreement: float = 0.3
    max_confidence_variance: float = 0.1
    
    # Conservative bounds
    use_conservative_bounds: bool = True
    sigma_level: float = 2.0
    
    # Human review triggers
    require_human_for_indeterminate: bool = True
    require_human_for_high_stakes: bool = True
    high_stakes_threshold: float = 0.8  # Impact threshold
    
    # Audit requirements
    generate_audit_trail: bool = True
    include_raw_assessments: bool = True


@dataclass
class VVAssertion:
    """
    Layer 4: V&V Integration
    
    A V&V-compatible assertion with complete audit trail.
    """
    assertion_id: str
    timestamp: float
    
    # Decision
    decision: VVDecision
    decision_confidence: float
    
    # Evidence basis
    evidence_packet_id: str
    assessment_count: int
    
    # Thresholds used
    pass_threshold: float
    fail_threshold: float
    
    # Audit trail
    transformation_steps: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Traceability
    input_hash: str = ""
    config_hash: str = ""
    
    # Optional human review
    requires_human_review: bool = False
    human_review_reason: str = ""
    human_decision: Optional[VVDecision] = None
    human_reviewer: str = ""
    
    def to_vv_format(self) -> Dict[str, Any]:
        """Export in standard V&V format."""
        return {
            "assertion_id": self.assertion_id,
            "timestamp": datetime.fromtimestamp(self.timestamp).isoformat(),
            "result": self.decision.value,
            "confidence": self.decision_confidence,
            "evidence_count": self.assessment_count,
            "requires_review": self.requires_human_review,
            "traceability": {
                "input_hash": self.input_hash,
                "config_hash": self.config_hash,
                "evidence_packet": self.evidence_packet_id
            },
            "warnings": self.warnings
        }


class SIIPTransformer(IntentAlignedOperator):
    """
    SIIP Transformer: Converts probabilistic AI outputs to V&V assertions.
    
    This is the core transformation engine that bridges AI uncertainty
    with V&V determinism through principled statistical reasoning.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: Optional[SIIPTransformConfig] = None):
        super().__init__(intent)
        
        # Apply intent-modulated config
        self.config = config or self._create_intent_config()
        
        # Audit storage
        self.audit_log: List[VVAssertion] = []
        
        # Statistics
        self.total_transforms = 0
        self.pass_count = 0
        self.fail_count = 0
        self.indeterminate_count = 0
        self.human_review_count = 0
    
    def _create_intent_config(self) -> SIIPTransformConfig:
        """Create configuration based on intent alignment."""
        if self.intent.context == IntentContext.SPECIFIC:
            # Conservative: High bar for pass, low bar for fail
            return SIIPTransformConfig(
                pass_threshold=0.99,
                fail_threshold=0.2,
                indeterminate_band=(0.2, 0.99),
                min_sample_size=3,
                max_disagreement=0.1,
                use_conservative_bounds=True,
                sigma_level=3.0,
                require_human_for_indeterminate=True,
                require_human_for_high_stakes=True
            )
        elif self.intent.context == IntentContext.GENERAL:
            # Balanced
            return SIIPTransformConfig(
                pass_threshold=0.95,
                fail_threshold=0.3,
                min_sample_size=1,
                max_disagreement=0.3,
                use_conservative_bounds=True,
                sigma_level=2.0,
                require_human_for_indeterminate=True
            )
        else:  # EXPLORATORY
            # Lenient: More tolerance, fewer human reviews
            return SIIPTransformConfig(
                pass_threshold=0.85,
                fail_threshold=0.4,
                indeterminate_band=(0.4, 0.85),
                min_sample_size=1,
                max_disagreement=0.5,
                use_conservative_bounds=False,
                require_human_for_indeterminate=False,
                require_human_for_high_stakes=False
            )
    
    def transform_single(self,
                          assessment: ProbabilisticAssessment,
                          impact_level: float = 0.5
                          ) -> VVAssertion:
        """
        Transform a single probabilistic assessment to V&V assertion.
        """
        # Create evidence packet from single assessment
        packet = EvidencePacket(
            packet_id=f"ep_{assessment.assessment_id}",
            assessments=[assessment]
        )
        
        return self.transform_evidence(packet, impact_level)
    
    def transform_evidence(self,
                            evidence: EvidencePacket,
                            impact_level: float = 0.5
                            ) -> VVAssertion:
        """
        Transform an evidence packet to a V&V assertion.
        
        This is the main transformation method implementing the SIIP protocol.
        """
        self.total_transforms += 1
        
        steps = []
        warnings = []
        
        # Step 1: Check sample size
        if evidence.sample_size < self.config.min_sample_size:
            warnings.append(
                f"Sample size {evidence.sample_size} below minimum "
                f"{self.config.min_sample_size}"
            )
        steps.append(f"Sample size check: {evidence.sample_size}")
        
        # Step 2: Check disagreement
        if evidence.disagreement_score > self.config.max_disagreement:
            warnings.append(
                f"Disagreement {evidence.disagreement_score:.2f} exceeds "
                f"maximum {self.config.max_disagreement}"
            )
        steps.append(f"Disagreement check: {evidence.disagreement_score:.3f}")
        
        # Step 3: Apply conservative bounds if configured
        effective_confidence = evidence.mean_confidence
        if self.config.use_conservative_bounds:
            # Reduce confidence by variance
            penalty = self.config.sigma_level * np.sqrt(evidence.confidence_variance)
            effective_confidence = max(0.0, effective_confidence - penalty)
            steps.append(
                f"Conservative adjustment: {evidence.mean_confidence:.3f} → "
                f"{effective_confidence:.3f}"
            )
        
        # Step 4: Determine decision
        if effective_confidence >= self.config.pass_threshold:
            if evidence.disagreement_score <= self.config.max_disagreement:
                decision = VVDecision.PASS
                self.pass_count += 1
            else:
                decision = VVDecision.INDETERMINATE
                self.indeterminate_count += 1
                warnings.append("High confidence but significant disagreement")
        elif effective_confidence <= self.config.fail_threshold:
            decision = VVDecision.FAIL
            self.fail_count += 1
        else:
            decision = VVDecision.INDETERMINATE
            self.indeterminate_count += 1
        
        steps.append(f"Decision: {decision.value} (conf={effective_confidence:.3f})")
        
        # Step 5: Check if human review required
        requires_human = False
        human_reason = ""
        
        if decision == VVDecision.INDETERMINATE:
            if self.config.require_human_for_indeterminate:
                requires_human = True
                human_reason = "Indeterminate result requires human review"
        
        if impact_level >= self.config.high_stakes_threshold:
            if self.config.require_human_for_high_stakes:
                requires_human = True
                human_reason = f"High-stakes decision (impact={impact_level:.2f})"
        
        if requires_human:
            decision = VVDecision.REQUIRES_HUMAN_REVIEW
            self.human_review_count += 1
            steps.append(f"Routed to human review: {human_reason}")
        
        # Create assertion
        assertion = VVAssertion(
            assertion_id=f"vv_{evidence.packet_id}_{self.total_transforms}",
            timestamp=datetime.now().timestamp(),
            decision=decision,
            decision_confidence=effective_confidence,
            evidence_packet_id=evidence.packet_id,
            assessment_count=evidence.sample_size,
            pass_threshold=self.config.pass_threshold,
            fail_threshold=self.config.fail_threshold,
            transformation_steps=steps,
            warnings=warnings,
            input_hash=self._hash_evidence(evidence),
            config_hash=self._hash_config(),
            requires_human_review=requires_human,
            human_review_reason=human_reason
        )
        
        # Log for audit
        if self.config.generate_audit_trail:
            self.audit_log.append(assertion)
        
        return assertion
    
    def submit_human_review(self,
                             assertion_id: str,
                             decision: VVDecision,
                             reviewer: str,
                             notes: str = "") -> bool:
        """
        Submit human review decision for an assertion.
        """
        for assertion in self.audit_log:
            if assertion.assertion_id == assertion_id:
                assertion.human_decision = decision
                assertion.human_reviewer = reviewer
                assertion.transformation_steps.append(
                    f"Human review by {reviewer}: {decision.value}"
                )
                if notes:
                    assertion.transformation_steps.append(f"Notes: {notes}")
                return True
        return False
    
    def _hash_evidence(self, evidence: EvidencePacket) -> str:
        """Generate hash of evidence for traceability."""
        content = str([a.assessment_id for a in evidence.assessments])
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def _hash_config(self) -> str:
        """Generate hash of configuration."""
        content = str(self.config.__dict__)
        return hashlib.sha256(content.encode()).hexdigest()[:16]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get transformation statistics."""
        return {
            "total_transforms": self.total_transforms,
            "pass_count": self.pass_count,
            "fail_count": self.fail_count,
            "indeterminate_count": self.indeterminate_count,
            "human_review_count": self.human_review_count,
            "pass_rate": self.pass_count / max(1, self.total_transforms),
            "human_review_rate": self.human_review_count / max(1, self.total_transforms),
            "config": {
                "pass_threshold": self.config.pass_threshold,
                "fail_threshold": self.config.fail_threshold,
                "conservative_bounds": self.config.use_conservative_bounds
            }
        }
    
    def export_audit_trail(self) -> List[Dict[str, Any]]:
        """Export complete audit trail in V&V format."""
        return [assertion.to_vv_format() for assertion in self.audit_log]


class SIIPProtocol(IntentAlignedOperator):
    """
    Complete SIIP Protocol implementation.
    
    Provides end-to-end integration of AI assessments into V&V workflows
    with full traceability and audit compliance.
    
    Usage:
        protocol = SIIPProtocol(intent)
        
        # Register an AI assessment
        assessment = protocol.register_assessment(
            prediction=0.85,
            confidence=0.92,
            uncertainty=0.05,
            assessment_type=AssessmentType.CLASSIFICATION
        )
        
        # Transform to V&V assertion
        assertion = protocol.transform_to_vv(assessment)
        
        # Check result
        if assertion.decision == VVDecision.PASS:
            print("V&V PASSED")
        elif assertion.requires_human_review:
            # Route to human
            protocol.submit_human_review(assertion.assertion_id, ...)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: Optional[SIIPTransformConfig] = None):
        super().__init__(intent)
        
        self.transformer = SIIPTransformer(intent, config)
        
        # Assessment registry
        self.assessments: Dict[str, ProbabilisticAssessment] = {}
        self.evidence_packets: Dict[str, EvidencePacket] = {}
        
        # Counter for IDs
        self._assessment_counter = 0
    
    def register_assessment(self,
                             prediction: Any,
                             confidence: float,
                             uncertainty: float,
                             assessment_type: AssessmentType = AssessmentType.CLASSIFICATION,
                             model_id: str = "default",
                             metadata: Optional[Dict[str, Any]] = None
                             ) -> ProbabilisticAssessment:
        """
        Register a new probabilistic assessment.
        """
        self._assessment_counter += 1
        assessment_id = f"assess_{self._assessment_counter}_{int(datetime.now().timestamp())}"
        
        assessment = ProbabilisticAssessment(
            assessment_id=assessment_id,
            assessment_type=assessment_type,
            timestamp=datetime.now().timestamp(),
            prediction=prediction,
            confidence=confidence,
            uncertainty=uncertainty,
            model_id=model_id,
            metadata=metadata or {}
        )
        
        self.assessments[assessment_id] = assessment
        return assessment
    
    def create_evidence_packet(self,
                                assessment_ids: List[str]
                                ) -> Optional[EvidencePacket]:
        """
        Create an evidence packet from multiple assessments.
        """
        assessments = []
        for aid in assessment_ids:
            if aid in self.assessments:
                assessments.append(self.assessments[aid])
        
        if not assessments:
            return None
        
        packet_id = f"packet_{len(self.evidence_packets)}_{int(datetime.now().timestamp())}"
        packet = EvidencePacket(packet_id=packet_id, assessments=assessments)
        
        self.evidence_packets[packet_id] = packet
        return packet
    
    def transform_to_vv(self,
                         assessment_or_packet,
                         impact_level: float = 0.5
                         ) -> VVAssertion:
        """
        Transform an assessment or evidence packet to V&V assertion.
        """
        if isinstance(assessment_or_packet, ProbabilisticAssessment):
            return self.transformer.transform_single(
                assessment_or_packet, impact_level
            )
        elif isinstance(assessment_or_packet, EvidencePacket):
            return self.transformer.transform_evidence(
                assessment_or_packet, impact_level
            )
        else:
            raise TypeError(
                f"Expected ProbabilisticAssessment or EvidencePacket, "
                f"got {type(assessment_or_packet)}"
            )
    
    def submit_human_review(self,
                             assertion_id: str,
                             decision: VVDecision,
                             reviewer: str,
                             notes: str = "") -> bool:
        """Submit human review for an assertion."""
        return self.transformer.submit_human_review(
            assertion_id, decision, reviewer, notes
        )
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive protocol statistics."""
        return {
            "assessments_registered": len(self.assessments),
            "evidence_packets": len(self.evidence_packets),
            "transformer": self.transformer.get_statistics()
        }
    
    def export_audit_trail(self) -> Dict[str, Any]:
        """Export complete audit trail."""
        return {
            "protocol": "SIIP",
            "version": "1.0",
            "intent_context": self.intent.context.value,
            "intent_scope": self.intent.scope,
            "statistics": self.get_statistics(),
            "assertions": self.transformer.export_audit_trail()
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'AssessmentType',
    'VVDecision',
    'ProbabilisticAssessment',
    'EvidencePacket',
    'SIIPTransformConfig',
    'VVAssertion',
    'SIIPTransformer',
    'SIIPProtocol',
]
