"""
Validation Module - Iron Core Validation Logic
===============================================

Ensures structural validity through:
- Donders' Subtraction (cognitive function validation)
- Immutability (copy-on-write state management)
- Topology preservation (invariant checking)
- Integration threshold (Φ validation)
- Sheaf Laplacian (cohomological obstruction detection)
"""

from .iron_core import (
    ValidationSeverity,
    ValidationResult,
    ValidationReport,
    DondersSubtraction,
    ImmutabilityValidator,
    TopologyInvariantChecker,
    IntegrationValidator,
    IronCoreValidator,
)

from .continuity import (
    SheafVertex,
    SheafEdge,
    SheafGraph,
    CoboundaryMap,
    SheafLaplacian,
    ConsistencyResult,
    CohomologicalValidator,
    HallucinationDetector,
    SheafContinuityGuard,
)

from .siip_protocol import (
    AssessmentType,
    VVDecision,
    ProbabilisticAssessment,
    EvidencePacket,
    SIIPTransformConfig,
    VVAssertion,
    SIIPTransformer,
    SIIPProtocol,
)

__all__ = [
    # Iron Core
    'ValidationSeverity',
    'ValidationResult',
    'ValidationReport',
    'DondersSubtraction',
    'ImmutabilityValidator',
    'TopologyInvariantChecker',
    'IntegrationValidator',
    'IronCoreValidator',
    # Sheaf-based Continuity
    'SheafVertex',
    'SheafEdge',
    'SheafGraph',
    'CoboundaryMap',
    'SheafLaplacian',
    'ConsistencyResult',
    'CohomologicalValidator',
    'HallucinationDetector',
    'SheafContinuityGuard',
    # SIIP Protocol
    'AssessmentType',
    'VVDecision',
    'ProbabilisticAssessment',
    'EvidencePacket',
    'SIIPTransformConfig',
    'VVAssertion',
    'SIIPTransformer',
    'SIIPProtocol',
]
