"""
Continuity Validation: Sheaf Laplacian & Cohomological Obstruction
===================================================================

Implements the "Iron Core" consistency detection mechanism from Sheaf Theory.

The Sheaf Laplacian L_F identifies where local data patches (LLM outputs,
local beliefs, partial solutions) fail to "glue" into a global section (Truth).

Key Concepts:
    - Sheaf: Assignment of data to each vertex that respects edge constraints
    - Coboundary Map: δ: C^0 → C^1 (measures local inconsistency)
    - Sheaf Laplacian: L = δ* δ (spectral signature of obstruction)
    - Non-zero eigenvalues indicate logical inconsistency ("The Shape of a Lie")

Mathematical Foundation:
    The Sheaf Laplacian spectrum provides:
    - λ_min = 0: Perfect global consistency
    - λ_min > 0: Irreducible inconsistency (obstruction to global section)
    - Large λ_max: High information divergence between patches

Usage in OPrime:
    - Prune MCTS branches with non-zero obstruction
    - Detect hallucinations in LLM outputs
    - Verify topology-preserving transformations

Intent Alignment:
    - SPECIFIC: Strict consistency (reject any obstruction)
    - EXPLORATORY: Lenient (allow small obstructions during exploration)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional, Callable, Set
import numpy as np
from abc import ABC, abstractmethod
import copy

from ..core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# SHEAF DATA STRUCTURES
# =============================================================================

@dataclass
class SheafVertex:
    """
    Vertex in the sheaf graph.
    
    Each vertex carries a "stalk" — a vector space of local data.
    """
    id: int
    stalk_dim: int
    data: np.ndarray
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if len(self.data) != self.stalk_dim:
            if len(self.data) < self.stalk_dim:
                self.data = np.pad(self.data, (0, self.stalk_dim - len(self.data)))
            else:
                self.data = self.data[:self.stalk_dim]


@dataclass
class SheafEdge:
    """
    Edge in the sheaf graph with restriction maps.
    
    The restriction maps ρ_uv and ρ_vu define how data should
    transform when moving between vertices.
    """
    source: int
    target: int
    restriction_st: np.ndarray  # ρ_{source→target}
    restriction_ts: Optional[np.ndarray] = None  # ρ_{target→source}
    weight: float = 1.0
    
    def __post_init__(self):
        if self.restriction_ts is None:
            # Default: transpose (symmetric relationship)
            self.restriction_ts = self.restriction_st.T


@dataclass 
class SheafGraph:
    """
    Complete sheaf over a graph.
    
    A sheaf assigns:
    - Vector space (stalk) to each vertex
    - Linear maps (restrictions) to each edge
    - Consistency condition: data should agree under restrictions
    """
    vertices: List[SheafVertex] = field(default_factory=list)
    edges: List[SheafEdge] = field(default_factory=list)
    
    def get_vertex(self, vertex_id: int) -> Optional[SheafVertex]:
        """Get vertex by ID."""
        for v in self.vertices:
            if v.id == vertex_id:
                return v
        return None
    
    def get_neighbors(self, vertex_id: int) -> List[int]:
        """Get neighbor vertex IDs."""
        neighbors = set()
        for e in self.edges:
            if e.source == vertex_id:
                neighbors.add(e.target)
            if e.target == vertex_id:
                neighbors.add(e.source)
        return list(neighbors)
    
    def get_edge(self, source: int, target: int) -> Optional[SheafEdge]:
        """Get edge between vertices."""
        for e in self.edges:
            if e.source == source and e.target == target:
                return e
            if e.source == target and e.target == source:
                return e
        return None
    
    @property
    def n_vertices(self) -> int:
        return len(self.vertices)
    
    @property
    def n_edges(self) -> int:
        return len(self.edges)
    
    @property
    def total_stalk_dim(self) -> int:
        """Total dimension of all stalks."""
        return sum(v.stalk_dim for v in self.vertices)


# =============================================================================
# COBOUNDARY MAP (δ: C^0 → C^1)
# =============================================================================

class CoboundaryMap:
    """
    Coboundary operator δ: C^0(F) → C^1(F).
    
    Measures local inconsistency between adjacent vertices.
    For an edge (u,v), the coboundary maps:
        (δf)(u,v) = ρ_{u→v}(f_u) - ρ_{v→u}(f_v)
    
    Zero coboundary = local consistency (data agrees under restrictions).
    """
    
    def __init__(self, sheaf: SheafGraph):
        self.sheaf = sheaf
        self._build_matrix()
    
    def _build_matrix(self):
        """Build the coboundary matrix representation."""
        n_vertices = self.sheaf.n_vertices
        n_edges = self.sheaf.n_edges
        
        if n_vertices == 0 or n_edges == 0:
            self.matrix = np.zeros((0, 0))
            return
        
        # Compute dimensions
        vertex_dims = [v.stalk_dim for v in self.sheaf.vertices]
        total_vertex_dim = sum(vertex_dims)
        
        # For simplicity, assume uniform edge stalk dimension
        # (equal to max vertex stalk dim)
        max_dim = max(vertex_dims) if vertex_dims else 1
        total_edge_dim = n_edges * max_dim
        
        # Build sparse matrix
        self.matrix = np.zeros((total_edge_dim, total_vertex_dim))
        
        vertex_offsets = [0]
        for d in vertex_dims[:-1]:
            vertex_offsets.append(vertex_offsets[-1] + d)
        
        for e_idx, edge in enumerate(self.sheaf.edges):
            edge_offset = e_idx * max_dim
            
            # Find vertex indices
            s_idx = next(i for i, v in enumerate(self.sheaf.vertices) if v.id == edge.source)
            t_idx = next(i for i, v in enumerate(self.sheaf.vertices) if v.id == edge.target)
            
            s_offset = vertex_offsets[s_idx]
            t_offset = vertex_offsets[t_idx]
            
            s_dim = vertex_dims[s_idx]
            t_dim = vertex_dims[t_idx]
            
            # Place restriction maps
            # +ρ_{s→t} for source contribution
            rho_st = edge.restriction_st
            for i in range(min(max_dim, rho_st.shape[0])):
                for j in range(min(s_dim, rho_st.shape[1])):
                    self.matrix[edge_offset + i, s_offset + j] = edge.weight * rho_st[i, j]
            
            # -ρ_{t→s} for target contribution
            rho_ts = edge.restriction_ts
            for i in range(min(max_dim, rho_ts.shape[0])):
                for j in range(min(t_dim, rho_ts.shape[1])):
                    self.matrix[edge_offset + i, t_offset + j] = -edge.weight * rho_ts[i, j]
    
    def apply(self, vertex_data: np.ndarray) -> np.ndarray:
        """Apply coboundary operator to vertex data."""
        return self.matrix @ vertex_data
    
    def get_obstruction(self) -> np.ndarray:
        """
        Compute obstruction (coboundary of current data).
        
        Returns vector in edge space measuring inconsistency.
        """
        # Collect all vertex data into single vector
        all_data = []
        for v in self.sheaf.vertices:
            all_data.extend(v.data.tolist())
        
        all_data = np.array(all_data)
        return self.apply(all_data)


# =============================================================================
# SHEAF LAPLACIAN (L = δ*δ)
# =============================================================================

class SheafLaplacian(IntentAlignedOperator):
    """
    Sheaf Laplacian: L_F = δ* δ
    
    The spectral signature of the Sheaf Laplacian reveals:
    - Kernel (λ=0 eigenspace): Space of globally consistent sections
    - Non-zero eigenvalues: Indicate obstruction to consistency
    - Largest eigenvalue: Maximum information divergence
    
    Intent Alignment:
        - SPECIFIC: Zero tolerance for obstruction
        - EXPLORATORY: Allow exploration of inconsistent regions
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 sheaf: SheafGraph):
        super().__init__(intent)
        
        self.sheaf = sheaf
        self.coboundary = CoboundaryMap(sheaf)
        
        # Compute Laplacian matrix: L = δ^T δ
        delta = self.coboundary.matrix
        self.laplacian = delta.T @ delta
        
        # Compute spectrum
        self._compute_spectrum()
        
        # Intent-aligned threshold
        self.obstruction_threshold = self._compute_threshold()
    
    def _compute_spectrum(self):
        """Compute eigenvalue spectrum of Laplacian."""
        if self.laplacian.size == 0:
            self.eigenvalues = np.array([0.0])
            self.eigenvectors = np.array([[1.0]])
            return
        
        try:
            eigenvalues, eigenvectors = np.linalg.eigh(self.laplacian)
            # Sort by eigenvalue
            idx = np.argsort(eigenvalues)
            self.eigenvalues = eigenvalues[idx]
            self.eigenvectors = eigenvectors[:, idx]
        except np.linalg.LinAlgError:
            # Fallback for numerical issues
            self.eigenvalues = np.array([0.0])
            self.eigenvectors = np.eye(self.laplacian.shape[0])[:, :1]
    
    def _compute_threshold(self) -> float:
        """
        Compute obstruction threshold based on intent.
        
        SPECIFIC: Near-zero tolerance
        EXPLORATORY: Higher tolerance
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.01
        elif context == IntentContext.GENERAL:
            base = 0.1
        else:  # EXPLORATORY
            base = 0.3
        
        return base * (0.5 + self.intent.scope)
    
    @property
    def lambda_min(self) -> float:
        """Smallest eigenvalue (should be ~0 for consistent data)."""
        return float(self.eigenvalues[0]) if len(self.eigenvalues) > 0 else 0.0
    
    @property
    def lambda_max(self) -> float:
        """Largest eigenvalue (maximum divergence)."""
        return float(self.eigenvalues[-1]) if len(self.eigenvalues) > 0 else 0.0
    
    @property
    def spectral_gap(self) -> float:
        """Gap between smallest and second-smallest eigenvalue."""
        if len(self.eigenvalues) < 2:
            return 0.0
        return float(self.eigenvalues[1] - self.eigenvalues[0])
    
    def has_global_section(self) -> bool:
        """
        Check if sheaf admits a global section.
        
        True iff smallest eigenvalue is (approximately) zero.
        """
        return self.lambda_min < self.obstruction_threshold
    
    def compute_obstruction_norm(self) -> float:
        """
        Compute L2 norm of the obstruction.
        
        Zero = perfect consistency
        Large = severe inconsistency
        """
        obstruction = self.coboundary.get_obstruction()
        return float(np.linalg.norm(obstruction))
    
    def get_inconsistency_locations(self) -> List[Tuple[int, int, float]]:
        """
        Identify edges with highest inconsistency.
        
        Returns list of (source, target, inconsistency_score).
        """
        obstruction = self.coboundary.get_obstruction()
        
        if len(obstruction) == 0:
            return []
        
        results = []
        n_edges = self.sheaf.n_edges
        if n_edges == 0:
            return []
            
        edge_dim = len(obstruction) // n_edges
        
        for e_idx, edge in enumerate(self.sheaf.edges):
            start = e_idx * edge_dim
            end = start + edge_dim
            edge_obstruction = obstruction[start:end]
            score = float(np.linalg.norm(edge_obstruction))
            results.append((edge.source, edge.target, score))
        
        # Sort by inconsistency (highest first)
        results.sort(key=lambda x: x[2], reverse=True)
        return results
    
    def project_to_consistent(self, data: np.ndarray) -> np.ndarray:
        """
        Project data to nearest consistent (harmonic) section.
        
        Uses the kernel of the Laplacian.
        """
        # Find kernel (eigenvalue ≈ 0)
        kernel_threshold = 1e-6
        kernel_mask = self.eigenvalues < kernel_threshold
        
        if not np.any(kernel_mask):
            # No kernel - return best approximation
            return data
        
        kernel_vectors = self.eigenvectors[:, kernel_mask]
        
        # Project onto kernel
        projection = kernel_vectors @ (kernel_vectors.T @ data)
        
        return projection


# =============================================================================
# CONSISTENCY VALIDATOR
# =============================================================================

@dataclass
class ConsistencyResult:
    """Result of consistency validation."""
    is_consistent: bool
    obstruction_norm: float
    lambda_min: float
    lambda_max: float
    spectral_gap: float
    inconsistent_edges: List[Tuple[int, int, float]]
    details: Dict[str, Any] = field(default_factory=dict)


class CohomologicalValidator(IntentAlignedOperator):
    """
    Cohomological Validator: Iron Core Consistency Checker.
    
    Uses Sheaf Laplacian to validate logical consistency of:
    - LLM outputs (detecting hallucinations)
    - MCTS branches (pruning invalid paths)
    - State transitions (topology preservation)
    
    The "Shape of a Lie" is identified by non-zero obstruction.
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # Intent-aligned parameters
        self.obstruction_threshold = self._compute_obstruction_threshold()
        self.edge_threshold = self._compute_edge_threshold()
        
        # Statistics
        self.validations_run = 0
        self.rejections = 0
    
    def _compute_obstruction_threshold(self) -> float:
        """
        Compute global obstruction threshold.
        
        SPECIFIC: Very strict
        EXPLORATORY: More lenient
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.05
        elif context == IntentContext.GENERAL:
            base = 0.2
        else:  # EXPLORATORY
            base = 0.5
        
        return base * (0.5 + self.intent.scope)
    
    def _compute_edge_threshold(self) -> float:
        """Compute per-edge inconsistency threshold."""
        return self.obstruction_threshold * 0.3
    
    def build_sheaf_from_states(self,
                                 states: List[np.ndarray],
                                 adjacency: Optional[List[Tuple[int, int]]] = None) -> SheafGraph:
        """
        Build a sheaf from a collection of states.
        
        Each state becomes a vertex stalk.
        Adjacent states are connected with identity restrictions.
        """
        vertices = []
        for i, state in enumerate(states):
            vertices.append(SheafVertex(
                id=i,
                stalk_dim=len(state),
                data=state.copy()
            ))
        
        # Default adjacency: chain
        if adjacency is None:
            adjacency = [(i, i+1) for i in range(len(states) - 1)]
        
        edges = []
        for s, t in adjacency:
            if s >= len(states) or t >= len(states):
                continue
            dim = min(len(states[s]), len(states[t]))
            # Identity restriction (states should be similar)
            restriction = np.eye(dim)
            edges.append(SheafEdge(
                source=s,
                target=t,
                restriction_st=restriction,
                restriction_ts=restriction
            ))
        
        return SheafGraph(vertices=vertices, edges=edges)
    
    def validate_trajectory(self,
                            trajectory: List[np.ndarray]) -> ConsistencyResult:
        """
        Validate consistency of a trajectory.
        
        Checks that state transitions are smooth (no teleportation).
        """
        if len(trajectory) < 2:
            return ConsistencyResult(
                is_consistent=True,
                obstruction_norm=0.0,
                lambda_min=0.0,
                lambda_max=0.0,
                spectral_gap=0.0,
                inconsistent_edges=[]
            )
        
        # Build sheaf
        sheaf = self.build_sheaf_from_states(trajectory)
        
        # Compute Laplacian
        laplacian = SheafLaplacian(self.intent, sheaf)
        
        # Get metrics
        obstruction_norm = laplacian.compute_obstruction_norm()
        inconsistent_edges = laplacian.get_inconsistency_locations()
        
        # Filter edges above threshold
        critical_edges = [
            (s, t, score) for s, t, score in inconsistent_edges
            if score > self.edge_threshold
        ]
        
        self.validations_run += 1
        is_consistent = obstruction_norm < self.obstruction_threshold
        
        if not is_consistent:
            self.rejections += 1
        
        return ConsistencyResult(
            is_consistent=is_consistent,
            obstruction_norm=obstruction_norm,
            lambda_min=laplacian.lambda_min,
            lambda_max=laplacian.lambda_max,
            spectral_gap=laplacian.spectral_gap,
            inconsistent_edges=critical_edges,
            details={
                "n_states": len(trajectory),
                "n_edges": len(sheaf.edges),
                "threshold": self.obstruction_threshold
            }
        )
    
    def validate_local_patch(self,
                              center: np.ndarray,
                              neighbors: List[np.ndarray]) -> ConsistencyResult:
        """
        Validate consistency of a local patch.
        
        Checks that center agrees with all neighbors under restrictions.
        """
        states = [center] + neighbors
        adjacency = [(0, i+1) for i in range(len(neighbors))]
        
        sheaf = self.build_sheaf_from_states(states, adjacency)
        laplacian = SheafLaplacian(self.intent, sheaf)
        
        obstruction_norm = laplacian.compute_obstruction_norm()
        inconsistent_edges = laplacian.get_inconsistency_locations()
        
        is_consistent = obstruction_norm < self.obstruction_threshold
        
        return ConsistencyResult(
            is_consistent=is_consistent,
            obstruction_norm=obstruction_norm,
            lambda_min=laplacian.lambda_min,
            lambda_max=laplacian.lambda_max,
            spectral_gap=laplacian.spectral_gap,
            inconsistent_edges=inconsistent_edges
        )
    
    def prune_inconsistent_branches(self,
                                     branches: List[List[np.ndarray]]) -> List[int]:
        """
        Identify branch indices that should be pruned.
        
        Returns indices of consistent branches (to keep).
        """
        consistent_indices = []
        
        for i, branch in enumerate(branches):
            result = self.validate_trajectory(branch)
            if result.is_consistent:
                consistent_indices.append(i)
        
        return consistent_indices
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get validation statistics."""
        total = self.validations_run
        return {
            "validations": total,
            "rejections": self.rejections,
            "rejection_rate": self.rejections / total if total > 0 else 0.0,
            "obstruction_threshold": self.obstruction_threshold
        }


# =============================================================================
# HALLUCINATION DETECTOR
# =============================================================================

class HallucinationDetector(IntentAlignedOperator):
    """
    Detects hallucinations in LLM outputs using cohomological analysis.
    
    A "hallucination" is defined as a local assertion that fails to
    integrate with the global context — a non-zero obstruction.
    
    Method:
        1. Build sheaf from context windows
        2. Compute obstruction between claims
        3. High obstruction = hallucination detected
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 embedding_fn: Optional[Callable[[str], np.ndarray]] = None):
        super().__init__(intent)
        
        self.embedding_fn = embedding_fn or self._default_embedding
        self.validator = CohomologicalValidator(intent)
    
    def _default_embedding(self, text: str) -> np.ndarray:
        """Default text embedding (hash-based, for testing)."""
        import hashlib
        digest = hashlib.sha256(text.encode()).digest()
        return np.array([b / 255.0 for b in digest[:32]])
    
    def detect(self,
               context: str,
               claim: str,
               supporting_facts: Optional[List[str]] = None) -> ConsistencyResult:
        """
        Detect if claim is consistent with context.
        
        Args:
            context: Background context
            claim: Statement to verify
            supporting_facts: Optional supporting evidence
        """
        # Embed all components
        context_emb = self.embedding_fn(context)
        claim_emb = self.embedding_fn(claim)
        
        fact_embs = []
        if supporting_facts:
            fact_embs = [self.embedding_fn(f) for f in supporting_facts]
        
        # Build sheaf: context is center, claim and facts are neighbors
        states = [context_emb, claim_emb] + fact_embs
        adjacency = [(0, i) for i in range(1, len(states))]
        
        # Also connect claim to facts
        for i in range(2, len(states)):
            adjacency.append((1, i))
        
        sheaf = self.validator.build_sheaf_from_states(states, adjacency)
        laplacian = SheafLaplacian(self.intent, sheaf)
        
        obstruction = laplacian.compute_obstruction_norm()
        
        return ConsistencyResult(
            is_consistent=obstruction < self.validator.obstruction_threshold,
            obstruction_norm=obstruction,
            lambda_min=laplacian.lambda_min,
            lambda_max=laplacian.lambda_max,
            spectral_gap=laplacian.spectral_gap,
            inconsistent_edges=laplacian.get_inconsistency_locations(),
            details={"type": "hallucination_check"}
        )


# =============================================================================
# MCTS CONTINUITY GUARD (Integration with SANS)
# =============================================================================

class SheafContinuityGuard(IntentAlignedOperator):
    """
    Continuity Guard enhanced with Sheaf Laplacian analysis.
    
    Integrates into SANS MCTS to prune branches with non-zero
    cohomological obstruction.
    
    This is the "Iron Core" of the search — mathematically rigorous
    pruning of logically invalid paths.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 window_size: int = 5):
        super().__init__(intent)
        
        self.validator = CohomologicalValidator(intent)
        self.window_size = window_size
        
        # Track recent states for windowed validation
        self.state_window: List[np.ndarray] = []
        
        # Statistics
        self.checks = 0
        self.pruned = 0
    
    def check_transition(self,
                         current_state: np.ndarray,
                         proposed_state: np.ndarray) -> bool:
        """
        Check if transition is cohomologically valid.
        
        Returns True if transition should be allowed.
        """
        self.checks += 1
        
        # Add to window
        window = self.state_window.copy()
        window.append(current_state)
        window.append(proposed_state)
        
        # Keep only recent states
        if len(window) > self.window_size:
            window = window[-self.window_size:]
        
        # Validate trajectory
        result = self.validator.validate_trajectory(window)
        
        if not result.is_consistent:
            self.pruned += 1
            return False
        
        # Update window on success
        self.state_window = window
        
        return True
    
    def check_branch(self, branch: List[np.ndarray]) -> bool:
        """
        Check if entire branch is consistent.
        
        Used for beam search pruning.
        """
        result = self.validator.validate_trajectory(branch)
        return result.is_consistent
    
    def get_obstruction_score(self, branch: List[np.ndarray]) -> float:
        """
        Get obstruction score for branch ranking.
        
        Lower is better (more consistent).
        """
        result = self.validator.validate_trajectory(branch)
        return result.obstruction_norm
    
    def reset(self):
        """Reset state window."""
        self.state_window = []
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get guard statistics."""
        return {
            "checks": self.checks,
            "pruned": self.pruned,
            "prune_rate": self.pruned / self.checks if self.checks > 0 else 0.0,
            "window_size": self.window_size,
            "validator_stats": self.validator.get_statistics()
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'SheafVertex',
    'SheafEdge',
    'SheafGraph',
    'CoboundaryMap',
    'SheafLaplacian',
    'ConsistencyResult',
    'CohomologicalValidator',
    'HallucinationDetector',
    'SheafContinuityGuard',
]
