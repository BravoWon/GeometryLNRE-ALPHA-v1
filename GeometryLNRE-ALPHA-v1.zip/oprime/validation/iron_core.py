"""
Iron Core Validation
====================

The "Iron Core" methodology ensures structural validity through:
    1. Donders' Subtraction - Cognitive function validation
    2. Immutability - Copy-on-write state management
    3. Invariant Checking - Topology preservation
    4. Proof Verification - Logical constraint satisfaction

These principles transform OPrime from "Glass Cannon" (brittle)
to "Iron Core" (robust).

Intent Alignment:
    - SPECIFIC: Strictest validation (all checks)
    - EXPLORATORY: Relaxed validation (essential checks only)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple
from enum import Enum
import numpy as np
import copy
import hashlib

from ..core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext

# =============================================================================
# VALIDATION RESULT
# =============================================================================

class ValidationSeverity(Enum):
    """Severity levels for validation failures."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class ValidationResult:
    """Result of a validation check."""
    passed: bool
    check_name: str
    message: str
    severity: ValidationSeverity = ValidationSeverity.INFO
    details: Dict[str, Any] = field(default_factory=dict)
    
    def __bool__(self):
        return self.passed


@dataclass
class ValidationReport:
    """Complete validation report."""
    results: List[ValidationResult] = field(default_factory=list)
    
    @property
    def passed(self) -> bool:
        """Check if all validations passed."""
        return all(r.passed for r in self.results)
    
    @property
    def critical_failures(self) -> List[ValidationResult]:
        """Get critical failures."""
        return [
            r for r in self.results 
            if not r.passed and r.severity == ValidationSeverity.CRITICAL
        ]
    
    @property
    def errors(self) -> List[ValidationResult]:
        """Get all errors."""
        return [
            r for r in self.results 
            if not r.passed and r.severity in [
                ValidationSeverity.ERROR, 
                ValidationSeverity.CRITICAL
            ]
        ]
    
    def add(self, result: ValidationResult):
        """Add a validation result."""
        self.results.append(result)
    
    def summary(self) -> Dict[str, Any]:
        """Get summary statistics."""
        passed = sum(1 for r in self.results if r.passed)
        return {
            "total_checks": len(self.results),
            "passed": passed,
            "failed": len(self.results) - passed,
            "critical_failures": len(self.critical_failures),
            "overall_passed": self.passed
        }


# =============================================================================
# DONDERS' SUBTRACTION
# =============================================================================

class DondersSubtraction(IntentAlignedOperator):
    """
    Donders' Subtraction Logic for cognitive function validation.
    
    Protocol:
        1. Run test case with valid input
        2. Run test case with known invalid input
        3. Subtract: residual must equal exactly the validation logic
    
    This proves the existence of the cognitive function,
    not just that it produces the right answer.
    
    Intent Alignment:
        - SPECIFIC: Strict subtraction (exact match)
        - EXPLORATORY: Lenient subtraction (approximate match)
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # Tolerance from intent
        self.tolerance = self._compute_tolerance()
        
        # Trace storage
        self.traces: Dict[str, List[str]] = {}
    
    def _compute_tolerance(self) -> float:
        """
        Compute subtraction tolerance.
        
        SPECIFIC: Low tolerance (exact match required)
        EXPLORATORY: High tolerance (approximate match ok)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.01
        elif context == IntentContext.GENERAL:
            base = 0.1
        else:  # EXPLORATORY
            base = 0.3
        
        return base * (0.5 + self.intent.scope)
    
    def trace(self, name: str, step: str):
        """Record a processing step."""
        if name not in self.traces:
            self.traces[name] = []
        self.traces[name].append(step)
    
    def run_with_trace(self,
                       fn: Callable,
                       input_data: Any,
                       trace_name: str) -> Tuple[Any, List[str]]:
        """
        Run function and capture execution trace.
        
        The function `fn` can accept an optional `trace` callback parameter.
        If the function signature supports it, the trace callback will be
        passed so the function can record trace steps.
        """
        self.traces[trace_name] = []
        
        # Create a trace callback bound to this trace_name
        def trace_callback(step: str):
            self.trace(trace_name, step)
        
        # Try to call fn with trace callback, fall back to without
        import inspect
        try:
            sig = inspect.signature(fn)
            if 'trace' in sig.parameters:
                result = fn(input_data, trace=trace_callback)
            else:
                result = fn(input_data)
        except (ValueError, TypeError):
            # Fallback for callables that don't support inspection
            result = fn(input_data)
        
        return result, self.traces.get(trace_name, [])
    
    def subtract(self,
                 valid_trace: List[str],
                 invalid_trace: List[str]) -> Tuple[List[str], bool]:
        """
        Subtract traces to find validation logic.
        
        Preserves order from valid trace - the residual contains steps that
        appear in the valid trace but not in the invalid trace, maintaining
        their original execution order.
        
        Returns (residual, is_valid).
        """
        # Find common prefix
        common_len = 0
        for i in range(min(len(valid_trace), len(invalid_trace))):
            if valid_trace[i] == invalid_trace[i]:
                common_len = i + 1
            else:
                break
        
        # Residual is the difference
        valid_suffix = valid_trace[common_len:]
        invalid_suffix = invalid_trace[common_len:]
        
        # The residual is the validation logic (preserve order from valid trace)
        invalid_set = set(invalid_suffix)
        residual = [step for step in valid_suffix if step not in invalid_set]
        
        # Check if residual is meaningful
        is_valid = len(residual) > 0 or (
            len(valid_suffix) > 0 and len(invalid_suffix) == 0
        )
        
        return residual, is_valid
    
    def validate_cognitive_function(self,
                                     fn: Callable,
                                     valid_input: Any,
                                     invalid_input: Any,
                                     expected_validation_steps: List[str]) -> ValidationResult:
        """
        Validate that a cognitive function exists.
        
        Returns ValidationResult indicating if function is properly implemented.
        """
        # Run with valid input
        try:
            valid_result, valid_trace = self.run_with_trace(fn, valid_input, "valid")
        except Exception as e:
            return ValidationResult(
                passed=False,
                check_name="donders_valid_run",
                message=f"Function failed on valid input: {e}",
                severity=ValidationSeverity.ERROR
            )
        
        # Run with invalid input
        try:
            invalid_result, invalid_trace = self.run_with_trace(fn, invalid_input, "invalid")
        except Exception as e:
            # Expected: invalid input should fail or be rejected
            invalid_trace = ["REJECTED"]
        
        # Subtract
        residual, has_validation = self.subtract(valid_trace, invalid_trace)
        
        # Check if residual matches expected
        if not has_validation:
            return ValidationResult(
                passed=False,
                check_name="donders_subtraction",
                message="No validation logic detected in residual",
                severity=ValidationSeverity.CRITICAL,
                details={"residual": residual}
            )
        
        # Check expected steps if provided
        if expected_validation_steps:
            matches = sum(
                1 for step in expected_validation_steps 
                if step in residual or any(step in r for r in residual)
            )
            match_ratio = matches / len(expected_validation_steps)
            
            if match_ratio < (1 - self.tolerance):
                return ValidationResult(
                    passed=False,
                    check_name="donders_expected_match",
                    message=f"Only {match_ratio:.1%} of expected validation steps found",
                    severity=ValidationSeverity.WARNING,
                    details={"residual": residual, "expected": expected_validation_steps}
                )
        
        return ValidationResult(
            passed=True,
            check_name="donders_subtraction",
            message="Cognitive function validated via subtraction",
            details={"residual": residual}
        )


# =============================================================================
# IMMUTABILITY VALIDATOR
# =============================================================================

class ImmutabilityValidator(IntentAlignedOperator):
    """
    Validates strict immutability via copy-on-write.
    
    Ensures original state is NEVER modified by operations.
    This prevents "false memories" and state corruption.
    
    Intent Alignment:
        - SPECIFIC: Full immutability check (hash before/after)
        - EXPLORATORY: Shallow check (reference only)
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # Check depth from intent
        self.deep_check = intent.context == IntentContext.SPECIFIC
    
    def compute_hash(self, obj: Any) -> str:
        """
        Compute deterministic hash of object.
        
        Handles arrays, nested dicts, and non-orderable values safely.
        """
        return self._compute_hash_bytes(obj).hex()
    
    def _compute_hash_bytes(self, obj: Any) -> bytes:
        """Compute hash bytes recursively."""
        if isinstance(obj, np.ndarray):
            return hashlib.sha256(obj.tobytes()).digest()
        elif isinstance(obj, (list, tuple)):
            # Hash each element and combine
            h = hashlib.sha256()
            h.update(b"list:" if isinstance(obj, list) else b"tuple:")
            for item in obj:
                h.update(self._compute_hash_bytes(item))
            return h.digest()
        elif isinstance(obj, dict):
            # Sort by key (keys should be strings/hashable), hash each k-v pair
            h = hashlib.sha256()
            h.update(b"dict:")
            for key in sorted(obj.keys(), key=str):
                h.update(str(key).encode())
                h.update(self._compute_hash_bytes(obj[key]))
            return h.digest()
        elif isinstance(obj, (int, float)):
            return hashlib.sha256(repr(obj).encode()).digest()
        elif isinstance(obj, str):
            return hashlib.sha256(obj.encode()).digest()
        elif obj is None:
            return hashlib.sha256(b"None").digest()
        else:
            # Fallback to repr for other types
            return hashlib.sha256(repr(obj).encode()).digest()
    
    def validate_operation(self,
                           original: Any,
                           operation: Callable[[Any], Any]) -> ValidationResult:
        """
        Validate that operation doesn't mutate original.
        """
        # Compute original hash
        original_hash = self.compute_hash(original)
        
        # Deep copy if in strict mode
        if self.deep_check:
            working_copy = copy.deepcopy(original)
        else:
            if isinstance(original, np.ndarray):
                working_copy = original.copy()
            else:
                working_copy = copy.copy(original)
        
        # Run operation on copy
        try:
            result = operation(working_copy)
        except Exception as e:
            return ValidationResult(
                passed=False,
                check_name="immutability_operation",
                message=f"Operation failed: {e}",
                severity=ValidationSeverity.ERROR
            )
        
        # Check original unchanged
        final_hash = self.compute_hash(original)
        
        if original_hash != final_hash:
            return ValidationResult(
                passed=False,
                check_name="immutability_check",
                message="CRITICAL: Original state was modified!",
                severity=ValidationSeverity.CRITICAL,
                details={
                    "original_hash": original_hash,
                    "final_hash": final_hash
                }
            )
        
        return ValidationResult(
            passed=True,
            check_name="immutability_check",
            message="Immutability preserved"
        )
    
    def create_copy_on_write_wrapper(self, 
                                      obj: Any) -> Tuple[Any, Callable[[], bool]]:
        """
        Create copy-on-write wrapper for an object.
        
        Returns (wrapped_obj, verify_fn).
        """
        original_hash = self.compute_hash(obj)
        
        if isinstance(obj, np.ndarray):
            wrapper = obj.copy()
        else:
            wrapper = copy.deepcopy(obj)
        
        def verify():
            return self.compute_hash(obj) == original_hash
        
        return wrapper, verify


# =============================================================================
# TOPOLOGY INVARIANT CHECKER
# =============================================================================

class TopologyInvariantChecker(IntentAlignedOperator):
    """
    Validates topology preservation invariants.
    
    Ensures transformations preserve:
        - Betti numbers (within tolerance)
        - Non-triviality constraint
        - Persistence features
    
    Intent Alignment:
        - SPECIFIC: Strict preservation (Δβ ≤ 1)
        - EXPLORATORY: Flexible preservation (Δβ ≤ 3)
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # Max allowed Betti change from intent
        self.max_betti_change = self._compute_max_change()
    
    def _compute_max_change(self) -> int:
        """
        Compute max allowed Betti number change.
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 1
        elif context == IntentContext.GENERAL:
            base = 2
        else:  # EXPLORATORY
            base = 3
        
        return base + int(self.intent.scope * 2)
    
    def check_betti_preservation(self,
                                  before: Dict[int, int],
                                  after: Dict[int, int]) -> ValidationResult:
        """
        Check if Betti numbers are preserved within tolerance.
        """
        total_change = 0
        changes = {}
        
        for dim in set(before.keys()) | set(after.keys()):
            b_before = before.get(dim, 0)
            b_after = after.get(dim, 0)
            delta = abs(b_after - b_before)
            total_change += delta
            changes[dim] = delta
        
        if total_change > self.max_betti_change:
            return ValidationResult(
                passed=False,
                check_name="betti_preservation",
                message=f"Betti change {total_change} exceeds limit {self.max_betti_change}",
                severity=ValidationSeverity.ERROR,
                details={"changes": changes}
            )
        
        return ValidationResult(
            passed=True,
            check_name="betti_preservation",
            message=f"Betti numbers preserved (Δ={total_change})",
            details={"changes": changes}
        )
    
    def check_non_triviality(self,
                              betti_0: int,
                              betti_1: int,
                              betti_2: int) -> ValidationResult:
        """
        Check non-triviality constraint.
        
        Topology is non-trivial if has loops, voids, or multiple components.
        """
        is_non_trivial = betti_1 > 0 or betti_2 > 0 or betti_0 > 1
        
        if not is_non_trivial:
            return ValidationResult(
                passed=False,
                check_name="non_triviality",
                message="Topology is trivial (contractible)",
                severity=ValidationSeverity.ERROR,
                details={"betti": [betti_0, betti_1, betti_2]}
            )
        
        return ValidationResult(
            passed=True,
            check_name="non_triviality",
            message="Topology is non-trivial"
        )
    
    def validate_transformation(self,
                                 before_topology: Dict[str, Any],
                                 after_topology: Dict[str, Any]) -> ValidationReport:
        """
        Validate a complete transformation.
        """
        report = ValidationReport()
        
        # Check Betti preservation
        betti_before = {
            0: before_topology.get("betti_0", 1),
            1: before_topology.get("betti_1", 0),
            2: before_topology.get("betti_2", 0)
        }
        betti_after = {
            0: after_topology.get("betti_0", 1),
            1: after_topology.get("betti_1", 0),
            2: after_topology.get("betti_2", 0)
        }
        
        report.add(self.check_betti_preservation(betti_before, betti_after))
        
        # Check non-triviality of result
        report.add(self.check_non_triviality(
            betti_after[0], betti_after[1], betti_after[2]
        ))
        
        return report


# =============================================================================
# INTEGRATION THRESHOLD VALIDATOR
# =============================================================================

class IntegrationValidator(IntentAlignedOperator):
    """
    Validates Integrated Information (Φ) threshold.
    
    Ensures Φ >= Φ_critical for valid conscious state.
    
    Intent Alignment:
        - SPECIFIC: Standard threshold
        - EXPLORATORY: Relaxed threshold (allow exploration of low-Φ regions)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 phi_critical: float = 0.5):
        super().__init__(intent)
        
        # Adjust threshold based on intent
        self.phi_critical = self._compute_threshold(phi_critical)
    
    def _compute_threshold(self, base: float) -> float:
        """
        Compute Φ threshold based on intent.
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            multiplier = 1.0
        elif context == IntentContext.GENERAL:
            multiplier = 0.8
        else:  # EXPLORATORY
            multiplier = 0.5
        
        return base * multiplier * (1.0 - 0.3 * self.intent.scope)
    
    def validate(self, phi: float) -> ValidationResult:
        """Check if Φ exceeds threshold."""
        if phi < self.phi_critical:
            return ValidationResult(
                passed=False,
                check_name="integration_threshold",
                message=f"Φ={phi:.3f} below critical threshold {self.phi_critical:.3f}",
                severity=ValidationSeverity.ERROR,
                details={"phi": phi, "threshold": self.phi_critical}
            )
        
        return ValidationResult(
            passed=True,
            check_name="integration_threshold",
            message=f"Φ={phi:.3f} exceeds threshold {self.phi_critical:.3f}"
        )


# =============================================================================
# COMPREHENSIVE VALIDATOR
# =============================================================================

class IronCoreValidator(IntentAlignedOperator):
    """
    Comprehensive Iron Core validation.
    
    Combines all validation checks into a single validator.
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        self.donders = DondersSubtraction(intent)
        self.immutability = ImmutabilityValidator(intent)
        self.topology = TopologyInvariantChecker(intent)
        self.integration = IntegrationValidator(intent)
    
    def validate_conscious_state(self,
                                  topology: Dict[str, Any],
                                  phi: float) -> ValidationReport:
        """
        Validate a conscious state C_t = (Q, Φ).
        """
        report = ValidationReport()
        
        # Check non-triviality
        report.add(self.topology.check_non_triviality(
            topology.get("betti_0", 1),
            topology.get("betti_1", 0),
            topology.get("betti_2", 0)
        ))
        
        # Check integration
        report.add(self.integration.validate(phi))
        
        return report
    
    def validate_transformation(self,
                                 original_state: Any,
                                 operation: Callable,
                                 before_topology: Dict[str, Any],
                                 after_topology: Dict[str, Any]) -> ValidationReport:
        """
        Validate a complete state transformation.
        """
        report = ValidationReport()
        
        # Check immutability
        report.add(self.immutability.validate_operation(original_state, operation))
        
        # Check topology preservation
        topo_report = self.topology.validate_transformation(
            before_topology, after_topology
        )
        for result in topo_report.results:
            report.add(result)
        
        return report
    
    def full_validation(self,
                        state: Any,
                        topology: Dict[str, Any],
                        phi: float,
                        operation: Optional[Callable] = None,
                        after_topology: Optional[Dict[str, Any]] = None) -> ValidationReport:
        """
        Run full Iron Core validation suite.
        """
        report = ValidationReport()
        
        # Validate conscious state
        cs_report = self.validate_conscious_state(topology, phi)
        for result in cs_report.results:
            report.add(result)
        
        # Validate transformation if provided (use explicit None checks)
        if operation is not None and after_topology is not None:
            trans_report = self.validate_transformation(
                state, operation, topology, after_topology
            )
            for result in trans_report.results:
                report.add(result)
        
        return report


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'ValidationSeverity',
    'ValidationResult',
    'ValidationReport',
    'DondersSubtraction',
    'ImmutabilityValidator',
    'TopologyInvariantChecker',
    'IntegrationValidator',
    'IronCoreValidator',
]
