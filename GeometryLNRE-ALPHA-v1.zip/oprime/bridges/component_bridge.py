"""
Component Bridges
=================

Bridges connecting OPrime components:
    - MOIRAI → TDA (forecasts to topology)
    - Value → Search (geometry to MCTS)
    - Conscious State → IO (C_t serialization)
    - Intent → All (alignment distribution)

These bridges ensure seamless data flow between modules
while respecting Intent Alignment.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple
import numpy as np
import json

from ..core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# MOIRAI → TDA BRIDGE
# =============================================================================

class MoiraiToTDABridge(IntentAlignedOperator):
    """
    Bridge from forecaster outputs to TDA inputs.
    
    Converts probabilistic forecasts into point clouds
    suitable for persistent homology analysis.
    
    Intent Alignment:
        - SPECIFIC: Dense sampling from forecasts
        - EXPLORATORY: Sparse sampling
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        self.sample_density = self._compute_sample_density()
    
    def _compute_sample_density(self) -> int:
        """Compute point cloud density."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            return 100
        elif context == IntentContext.GENERAL:
            return 50
        else:  # EXPLORATORY
            return 25
    
    def forecast_to_pointcloud(self,
                                forecast: Dict[str, Any]) -> np.ndarray:
        """
        Convert forecast to point cloud for TDA.
        
        Uses forecast samples as point cloud.
        """
        samples = forecast.get("samples", np.array([]))
        
        if len(samples) == 0:
            # Fall back to point forecast
            point = forecast.get("point_forecast", np.array([0]))
            return point.reshape(-1, 1)
        
        # Subsample if needed
        if len(samples) > self.sample_density:
            indices = np.random.choice(
                len(samples), 
                self.sample_density, 
                replace=False
            )
            samples = samples[indices]
        
        return samples
    
    def extract_topology_features(self,
                                   forecast: Dict[str, Any]) -> Dict[str, float]:
        """
        Extract topology-relevant features from forecast.
        """
        samples = forecast.get("samples", np.array([[]]))
        
        features = {
            "variance": float(forecast.get("mixture_variance", 0)),
            "mean": float(forecast.get("mixture_mean", 0)),
            "confidence_width": 0.0
        }
        
        if "lower_bound" in forecast and "upper_bound" in forecast:
            width = np.mean(forecast["upper_bound"] - forecast["lower_bound"])
            features["confidence_width"] = float(width)
        
        return features


# =============================================================================
# VALUE → SEARCH BRIDGE
# =============================================================================

class ValueToSearchBridge(IntentAlignedOperator):
    """
    Bridge from value geometry to MCTS search.
    
    Converts value function into reward/heuristic
    for search algorithms.
    
    Intent Alignment:
        - SPECIFIC: Sharp value gradient
        - EXPLORATORY: Smooth value gradient
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        self.gradient_sharpness = self._compute_sharpness()
    
    def _compute_sharpness(self) -> float:
        """Compute gradient sharpness."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            return 2.0  # Sharp gradients
        elif context == IntentContext.GENERAL:
            return 1.0
        else:  # EXPLORATORY
            return 0.5  # Smooth gradients
    
    def value_to_reward(self,
                         value: float,
                         baseline: float = 0.0) -> float:
        """
        Convert value to reward signal.
        
        Applies sharpness transformation.
        """
        delta = value - baseline
        
        # Apply sharpness
        if delta >= 0:
            return np.tanh(delta * self.gradient_sharpness)
        else:
            return -np.tanh(abs(delta) * self.gradient_sharpness)
    
    def gradient_to_prior(self,
                           gradient: np.ndarray,
                           actions: List[Any],
                           action_vectors: Optional[Dict[Any, np.ndarray]] = None) -> Dict[Any, float]:
        """
        Convert value gradient to action priors.
        
        Actions aligned with gradient get higher prior.
        """
        if action_vectors is None:
            # Uniform priors
            return {a: 1.0 / len(actions) for a in actions}
        
        priors = {}
        gradient_norm = np.linalg.norm(gradient)
        
        for action in actions:
            if action in action_vectors:
                vec = action_vectors[action]
                
                # Cosine similarity with gradient
                if gradient_norm > 1e-8 and np.linalg.norm(vec) > 1e-8:
                    similarity = np.dot(gradient, vec) / (gradient_norm * np.linalg.norm(vec))
                else:
                    similarity = 0.0
                
                # Convert to prior (softmax-like)
                priors[action] = np.exp(similarity * self.gradient_sharpness)
            else:
                priors[action] = 1.0
        
        # Normalize
        total = sum(priors.values())
        return {a: p / total for a, p in priors.items()}


# =============================================================================
# CONSCIOUS STATE I/O BRIDGE
# =============================================================================

class ConsciousStateIOBridge(IntentAlignedOperator):
    """
    Bridge for Conscious State serialization.
    
    Handles C_t = (Q, Φ) serialization and deserialization
    for storage, transmission, and logging.
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
    
    def serialize(self, 
                  topology: Dict[str, Any],
                  phi: float,
                  metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Serialize conscious state to JSON.
        """
        state = {
            "Q": {
                "betti_0": topology.get("betti_0", 1),
                "betti_1": topology.get("betti_1", 0),
                "betti_2": topology.get("betti_2", 0),
                "total_persistence": topology.get("total_persistence", 0.0),
                "is_non_trivial": topology.get("is_non_trivial", False)
            },
            "phi": phi,
            "intent": {
                "context": self.intent.context.value,
                "scope": self.intent.scope
            },
            "metadata": metadata or {}
        }
        
        return json.dumps(state, indent=2)
    
    def deserialize(self, json_str: str) -> Tuple[Dict[str, Any], float]:
        """
        Deserialize conscious state from JSON.
        
        Returns (topology, phi).
        """
        state = json.loads(json_str)
        
        topology = state.get("Q", {})
        phi = state.get("phi", 0.0)
        
        return topology, phi
    
    def to_vector(self,
                  topology: Dict[str, Any],
                  phi: float) -> np.ndarray:
        """
        Convert conscious state to vector representation.
        
        Useful for embedding or distance computation.
        """
        return np.array([
            topology.get("betti_0", 1),
            topology.get("betti_1", 0),
            topology.get("betti_2", 0),
            topology.get("total_persistence", 0.0),
            phi
        ])
    
    def distance(self,
                 state1: Tuple[Dict[str, Any], float],
                 state2: Tuple[Dict[str, Any], float]) -> float:
        """
        Compute distance between conscious states.
        """
        v1 = self.to_vector(state1[0], state1[1])
        v2 = self.to_vector(state2[0], state2[1])
        
        return np.linalg.norm(v1 - v2)


# =============================================================================
# INTENT DISTRIBUTION BRIDGE
# =============================================================================

class IntentDistributionBridge:
    """
    Distributes Intent Alignment to all components.
    
    Ensures consistent alignment across the entire system.
    """
    
    def __init__(self, intent: IntentConfiguration):
        self.intent = intent
        self.components: Dict[str, IntentAlignedOperator] = {}
    
    def register(self, name: str, component: IntentAlignedOperator):
        """Register a component for intent management."""
        self.components[name] = component
    
    def update_intent(self, new_intent: IntentConfiguration):
        """
        Update intent for all registered components.
        
        Note: Components may need to be re-initialized.
        """
        prev = self.intent
        self.intent = new_intent
        
        for component in self.components.values():
            if hasattr(component, "update_intent"):
                component.update_intent(new_intent)
            else:
                component.intent = new_intent
        
        # Log intent change (components need manual re-init)
        return {
            "previous_context": prev.context.value,
            "new_context": new_intent.context.value,
            "registered_components": list(self.components.keys())
        }
    def get_alignment_report(self) -> Dict[str, Any]:
        """Get alignment report for all components."""
        report = {
            "intent": {
                "context": self.intent.context.value,
                "scope": self.intent.scope,
                "value_intensity": self.intent.value_intensity,
                "agency_freedom": self.intent.agency_freedom
            },
            "components": {}
        }
        
        for name, component in self.components.items():
            report["components"][name] = {
                "type": type(component).__name__,
                "aligned": component.intent == self.intent
            }
        
        return report


# =============================================================================
# PIPELINE CONNECTOR
# =============================================================================

class PipelineConnector(IntentAlignedOperator):
    """
    Connects all pipeline stages with intent-aligned bridges.
    
    Provides a unified interface for data flow between:
        Stage 1 (Sensorimotor) → Stage 2 (Manifold) → ...
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # Initialize bridges
        self.moirai_to_tda = MoiraiToTDABridge(intent)
        self.value_to_search = ValueToSearchBridge(intent)
        self.conscious_io = ConsciousStateIOBridge(intent)
        self.intent_distribution = IntentDistributionBridge(intent)
        
        # Register bridges
        self.intent_distribution.register("moirai_tda", self.moirai_to_tda)
        self.intent_distribution.register("value_search", self.value_to_search)
        self.intent_distribution.register("conscious_io", self.conscious_io)
    
    def connect_forecast_to_topology(self,
                                      forecast: Dict[str, Any]) -> Dict[str, Any]:
        """
        Connect forecaster output to topology extractor input.
        """
        pointcloud = self.moirai_to_tda.forecast_to_pointcloud(forecast)
        features = self.moirai_to_tda.extract_topology_features(forecast)
        
        return {
            "pointcloud": pointcloud,
            "features": features
        }
    
    def connect_value_to_mcts(self,
                               value: float,
                               gradient: np.ndarray,
                               actions: List[Any]) -> Dict[str, Any]:
        """
        Connect value geometry to MCTS search.
        """
        reward = self.value_to_search.value_to_reward(value)
        priors = self.value_to_search.gradient_to_prior(gradient, actions)
        
        return {
            "reward": reward,
            "action_priors": priors
        }
    
    def serialize_conscious_state(self,
                                   topology: Dict[str, Any],
                                   phi: float) -> str:
        """Serialize conscious state for storage/transmission."""
        return self.conscious_io.serialize(topology, phi)
    
    def get_system_alignment(self) -> Dict[str, Any]:
        """Get alignment status for entire system."""
        return self.intent_distribution.get_alignment_report()


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'MoiraiToTDABridge',
    'ValueToSearchBridge',
    'ConsciousStateIOBridge',
    'IntentDistributionBridge',
    'PipelineConnector',
]
