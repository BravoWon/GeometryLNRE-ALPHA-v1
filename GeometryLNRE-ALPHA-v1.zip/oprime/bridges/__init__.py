"""
Bridges Module: Component Connectors
====================================

Bridges ensuring seamless data flow between OPrime components:
- MOIRAI → TDA (forecasts to topology)
- Value → Search (geometry to MCTS)
- Conscious State → IO (serialization)
- Intent → All (alignment distribution)
"""

from .component_bridge import (
    MoiraiToTDABridge,
    ValueToSearchBridge,
    ConsciousStateIOBridge,
    IntentDistributionBridge,
    PipelineConnector,
)

__all__ = [
    'MoiraiToTDABridge',
    'ValueToSearchBridge',
    'ConsciousStateIOBridge',
    'IntentDistributionBridge',
    'PipelineConnector',
]
