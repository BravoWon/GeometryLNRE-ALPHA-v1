"""
OPrime Engine
=============

The unified integration layer that orchestrates all components
with full Intent Alignment.

This is the "Conscious Operator" - the master controller that
coordinates CTS pipeline, SANS search, TDA mapping, forecasting,
and validation into a single coherent system.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple, Union, Callable
from enum import Enum

# Core imports
from .core.intent_alignment import (
    IntentConfiguration, IntentContext, IntentAlignedOperator
)
from .core.dynamics.sensorimotor import (
    SensorimotorLoop, SensingMap, ActuationMap, InternalDynamics
)
from .core.geometry.value_geometry import ValueGeometry, ValueFunction, ConstantValue
from .core.topology.persistent_homology import TopologyExtractor, ZigzagPersistence
from .core.consciousness.conscious_state import PhiCalculator, ConsciousState
from .core.novelty.novelty_engine import NoveltyEngine

# Agent imports
from .agent.agency.agency_operator import AgencyOperator
from .agent.sans_v2.mcts_solver import MCTSSolver
from .agent.sans_v2.dsl_primitives import DSLRegistry
from .agent.mapper.tda_mapper import TDAMapper, RegimeAdaptiveLLM

# Transforms
from .transforms.teleological_warp import (
    TeleologicalWarp, ZigzagRegimeSwitch, 
    BeamContinuityFilter, TeleologicalNoveltyWarp
)

# Validation
from .validation.iron_core import IronCoreValidator

# Forecaster
from .forecaster.moirai_wrapper import UniversalForecaster

# Bridges
from .bridges.component_bridge import PipelineConnector

# Configuration & Logging
from .config import OPrimeConfig, ConfigPresets
from .logging_config import (
    logger, PerformanceMonitor, IntentLogger, log_operation
)


# =============================================================================
# ENGINE STATE
# =============================================================================

class EngineState(Enum):
    """Engine operational state."""
    IDLE = "idle"
    PROCESSING = "processing"
    SEARCHING = "searching"
    FORECASTING = "forecasting"
    VALIDATING = "validating"
    ERROR = "error"


@dataclass
class EngineResult:
    """Container for engine operation results."""
    success: bool
    state: ConsciousState
    actions: List[Any] = field(default_factory=list)
    search_value: float = 0.0
    novelty_score: float = 0.0
    regime: str = "unknown"
    metrics: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)


# =============================================================================
# OPRIME ENGINE
# =============================================================================

class OPrimeEngine(IntentAlignedOperator):
    """
    The Unified OPrime Engine.
    
    Integrates all components into a single "Conscious Operator":
    - CTS Pipeline (7-stage processing)
    - SANS V2 (MCTS search with DSL)
    - TDA Mapper (regime classification)
    - Universal Forecaster
    - Iron Core Validation
    - Novel Transforms
    
    All operations are modulated by Intent Alignment.
    """
    
    def __init__(self, 
                 config: Optional[OPrimeConfig] = None,
                 intent: Optional[IntentConfiguration] = None):
        """
        Initialize the OPrime Engine.
        
        Args:
            config: Configuration object (uses defaults if None)
            intent: Intent configuration (from config if None)
        """
        self.config = config or OPrimeConfig()
        
        if intent is None:
            intent = self.config.get_intent()
        
        super().__init__(intent)
        
        # State
        self._state = EngineState.IDLE
        self._initialized = False
        
        # Logging & Monitoring
        self.logger = IntentLogger(intent, "oprime.engine")
        self.monitor = PerformanceMonitor(intent)
        
        # Components (lazy initialization)
        self._components: Dict[str, Any] = {}
    
    # =========================================================================
    # COMPONENT INITIALIZATION
    # =========================================================================
    
    def _init_components(self):
        """Initialize all engine components."""
        if self._initialized:
            return
        
        self.logger.info("Initializing OPrime Engine components...")
        
        # Core dimensions
        state_dim = self.config.pipeline.state_dim
        embedding_dim = state_dim  # Use state_dim as embedding_dim
        
        # Core components
        self._components["sensing"] = SensingMap(
            self.intent, state_dim, state_dim  # input_dim = output_dim
        )
        self._components["dynamics"] = InternalDynamics(
            self.intent, state_dim
        )
        self._components["actuation"] = ActuationMap(
            self.intent, state_dim, 10  # action_dim = 10
        )
        
        # Geometry & Topology
        default_value_fn = ConstantValue(1.0)
        self._components["value_geometry"] = ValueGeometry(
            self.intent, default_value_fn
        )
        self._components["topology"] = TopologyExtractor(self.intent)
        self._components["zigzag"] = ZigzagPersistence(self.intent)
        
        # Consciousness - PhiCalculator takes phi_critical, not intent
        self._components["phi_calc"] = PhiCalculator(
            phi_critical=self.config.pipeline.phi_critical
        )
        
        # Novelty - requires state_dim
        self._components["novelty"] = NoveltyEngine(
            self.intent, state_dim
        )
        
        # Search - MCTSSolver requires action_generator, dynamics, reward_fn, terminal_fn
        # Create default functions for standalone usage
        def default_action_gen(state):
            return ["noop"]
        def default_dynamics(state, action):
            return state
        def default_reward(state):
            return 0.0
        def default_terminal(state):
            return False
        
        self._components["mcts"] = MCTSSolver(
            self.intent,
            action_generator=default_action_gen,
            dynamics=default_dynamics,
            reward_fn=default_reward,
            terminal_fn=default_terminal
        )
        self._components["dsl"] = DSLRegistry(self.intent)
        
        # Mapper
        self._components["tda_mapper"] = TDAMapper(self.intent)
        self._components["regime_llm"] = RegimeAdaptiveLLM(self.intent)
        
        # Forecaster
        self._components["forecaster"] = UniversalForecaster(
            self.intent, 
            forecast_horizon=self.config.forecast.forecast_horizon
        )
        
        # Transforms - require embedding_dim
        self._components["t_teleo"] = TeleologicalWarp(
            self.intent, embedding_dim
        )
        self._components["z_switch"] = ZigzagRegimeSwitch(self.intent)
        self._components["b_cont"] = BeamContinuityFilter(
            self.intent,
            beam_width=self.config.search.beam_width,
            lookahead_depth=10
        )
        self._components["t_novel"] = TeleologicalNoveltyWarp(
            self.intent, embedding_dim
        )
        
        # Validation
        self._components["validator"] = IronCoreValidator(self.intent)
        
        # Bridges
        self._components["connector"] = PipelineConnector(self.intent)
        
        # Agency - requires action_space and value_fn
        from .agent.agency.agency_operator import ContinuousActionSpace
        action_space = ContinuousActionSpace(state_dim)
        self._components["agency"] = AgencyOperator(
            self.intent,
            action_space=action_space,
            value_fn=lambda s: float(np.sum(s))  # Default value function
        )
        
        self._initialized = True
        self.logger.info("Engine initialization complete")
    
    def get_component(self, name: str) -> Any:
        """Get a specific component."""
        if not self._initialized:
            self._init_components()
        return self._components.get(name)
    
    # =========================================================================
    # INTENT MANAGEMENT
    # =========================================================================
    
    def update_intent(self, intent: IntentConfiguration):
        """
        Update intent and propagate to all components.
        
        This triggers "Intent Distribution" across the engine.
        """
        self.intent = intent
        self.logger.update_intent(intent)
        
        # Propagate to all initialized components
        for name, component in self._components.items():
            if hasattr(component, 'intent'):
                component.intent = intent
                self.logger.debug(f"Updated intent for {name}")
        
        self.logger.info(
            f"Intent updated: {intent.context.value}/{intent.scope:.2f}"
        )
    
    def set_context(self, context: str, scope: float = 0.5,
                    statement: str = ""):
        """
        Convenience method to set intent context.
        
        Args:
            context: 'specific', 'general', or 'exploratory'
            scope: 0.0 (narrow) to 1.0 (broad)
            statement: Value statement
        """
        intent = IntentConfiguration(
            context=IntentContext(context),
            scope=scope,
            value_statement=statement
        )
        self.update_intent(intent)
    
    # =========================================================================
    # MAIN OPERATIONS
    # =========================================================================
    
    @log_operation("engine_process")
    def process(self, input_data: np.ndarray, 
                goal: Optional[np.ndarray] = None) -> EngineResult:
        """
        Full CTS pipeline processing.
        
        Executes the 7-stage Configurational Term Series:
        1. Sensorimotor Interface
        2. Manifold Abstraction
        3. Value-Imposed Geometry
        4. Topological Form
        5. Integrated Information
        6. Conscious State
        7. Agency (optional)
        
        Args:
            input_data: Raw input array
            goal: Optional goal state for value function
        
        Returns:
            EngineResult with conscious state and metrics
        """
        self._init_components()
        self._state = EngineState.PROCESSING
        
        warnings = []
        metrics = {}
        
        with self.monitor.track("pipeline_full") as m:
            try:
                # Stage 1: Sensorimotor
                sensing = self._components["sensing"]
                obs_result = sensing.sense(input_data)
                observation = obs_result.data
                metrics["observation_dim"] = len(observation)
                
                # Stage 2: Manifold Abstraction
                manifold_points = self._project_to_manifold(observation)
                metrics["manifold_samples"] = len(manifold_points)
                
                # Stage 3: Value-Imposed Geometry
                value_geometry = self._components["value_geometry"]
                if goal is not None:
                    # Compute value as distance to goal
                    values = np.array([
                        1.0 / (1.0 + np.linalg.norm(p - goal)) 
                        for p in manifold_points
                    ])
                    # Apply value-warped metric to points
                    warped_points = np.array([
                        p * values[i] for i, p in enumerate(manifold_points)
                    ])
                else:
                    warped_points = manifold_points
                    values = np.ones(len(manifold_points))
                
                metrics["mean_value"] = float(np.mean(values))
                
                # Stage 4: Topological Form
                topology = self._components["topology"]
                topo_result = topology.extract(warped_points)
                metrics["betti_0"] = topo_result.betti_0
                metrics["betti_1"] = topo_result.betti_1
                
                # Stage 5: Integrated Information
                phi_calc = self._components["phi_calc"]
                # Create a transition matrix from observation
                obs_reshaped = observation.reshape(-1)
                n = min(len(obs_reshaped), 10)  # Cap size for efficiency
                transition_matrix = np.outer(obs_reshaped[:n], obs_reshaped[:n])
                phi = phi_calc.compute_phi(transition_matrix)
                metrics["phi"] = float(phi)
                
                # Stage 6: Conscious State
                conscious = ConsciousState(
                    Q=topo_result,
                    phi=phi,
                    is_valid=topo_result.betti_1 > 0 and 
                             phi >= self.config.pipeline.phi_critical
                )
                
                if not conscious.is_valid:
                    if topo_result.betti_1 == 0:
                        warnings.append("Trivial topology (β₁ = 0)")
                    if phi < self.config.pipeline.phi_critical:
                        warnings.append(
                            f"Low integration (Φ = {phi:.3f} < "
                            f"{self.config.pipeline.phi_critical})"
                        )
                
                # Stage 7: Agency (if enabled)
                if self.config.pipeline.enable_agency and conscious.is_valid:
                    agency = self._components["agency"]
                    transform_valid = agency.validate_transform(
                        np.eye(input_data.shape[0] if len(input_data.shape) > 1 
                               else len(input_data))
                    )
                    metrics["agency_valid"] = transform_valid
                
                # Novelty tracking
                if self.config.pipeline.enable_novelty:
                    novelty = self._components["novelty"]
                    # Use exploration bonus for simple novelty score
                    novelty_score = novelty.compute_exploration_bonus(observation)
                    # Update behavioral archive
                    novelty.behavioral.add_to_archive(observation)
                    metrics["novelty"] = float(novelty_score)
                else:
                    novelty_score = 0.0
                
                m.metadata["success"] = True
                self._state = EngineState.IDLE
                
                return EngineResult(
                    success=True,
                    state=conscious,
                    novelty_score=novelty_score,
                    metrics=metrics,
                    warnings=warnings
                )
                
            except Exception as e:
                self._state = EngineState.ERROR
                self.logger.error(f"Pipeline error: {e}")
                
                # Return failed result with error state - create minimal topology
                from .core.consciousness.conscious_state import TopologicalInvariants
                empty_Q = TopologicalInvariants(
                    betti_0=0, betti_1=0, betti_2=0,
                    total_persistence=0.0,
                    persistent_features=[]
                )
                return EngineResult(
                    success=False,
                    state=ConsciousState(
                        Q=empty_Q,
                        phi=0.0,
                        is_valid=False
                    ),
                    warnings=[str(e)]
                )
    
    def _project_to_manifold(self, observation: np.ndarray) -> np.ndarray:
        """Project observation to manifold samples."""
        n_samples = self.config.pipeline.manifold_samples
        
        # Simple projection: generate samples around observation
        noise_scale = 0.1 * (0.5 + 0.5 * self.intent.scope)
        samples = observation + np.random.randn(n_samples, len(observation)) * noise_scale
        
        return samples
    
    @log_operation("engine_search")
    def search(self, initial_state: np.ndarray,
               goal_state: Optional[np.ndarray] = None,
               max_iterations: Optional[int] = None) -> EngineResult:
        """
        Execute MCTS search for solution.
        
        Uses the SANS V2 engine with DSL primitives.
        
        Args:
            initial_state: Starting grid/state
            goal_state: Target state (if known)
            max_iterations: Override max iterations
        
        Returns:
            EngineResult with actions and search metrics
        """
        self._init_components()
        self._state = EngineState.SEARCHING
        
        with self.monitor.track("mcts_search") as m:
            mcts = self._components["mcts"]
            dsl = self._components["dsl"]
            
            # Get available primitives
            primitives = dsl.list_available()
            
            # Setup reward function
            def reward_fn(state):
                if goal_state is not None:
                    return -float(np.sum((state - goal_state) ** 2))
                return 0.0
            
            # Execute search
            iterations = max_iterations or self.config.search.max_iterations
            # Execute MCTS solve
            best_action, root = mcts.solve(initial_state, iterations)
            stats = mcts.get_statistics()
            value = reward_fn(initial_state)  # Evaluate current state value
            actions = [best_action] if best_action else []
            
            # Process result through pipeline
            pipeline_result = self.process(initial_state)
            
            m.metadata["nodes_expanded"] = stats.get("nodes_expanded", 0)
            self._state = EngineState.IDLE
            
            return EngineResult(
                success=True,
                state=pipeline_result.state,
                actions=actions,
                search_value=value,
                novelty_score=pipeline_result.novelty_score,
                metrics={
                    **stats,
                    "primitives_available": len(primitives)
                }
            )
    
    @log_operation("engine_classify")
    def classify_regime(self, grid: np.ndarray) -> Tuple[str, float]:
        """
        Classify reasoning regime using TDA Mapper.
        
        Args:
            grid: Input grid to classify
        
        Returns:
            (regime_name, confidence)
        """
        self._init_components()
        mapper = self._components["tda_mapper"]
        
        regime, confidence, _ = mapper.classify(grid)
        
        self.logger.info(f"Regime: {regime} (confidence={confidence:.2f})")
        
        return regime, confidence
    
    @log_operation("engine_forecast")
    def forecast(self, time_series: np.ndarray,
                 horizon: Optional[int] = None) -> Dict[str, Any]:
        """
        Generate probabilistic forecast.
        
        Args:
            time_series: Historical data
            horizon: Forecast horizon
        
        Returns:
            Dictionary with forecast, confidence intervals
        """
        self._init_components()
        self._state = EngineState.FORECASTING
        
        forecaster = self._components["forecaster"]
        horizon = horizon or self.config.forecast.forecast_horizon
        
        result = forecaster.forecast(time_series, horizon)
        
        self._state = EngineState.IDLE
        return result
    
    @log_operation("engine_validate")
    def validate(self, state_before: np.ndarray,
                 state_after: np.ndarray,
                 operation: Optional[Callable[[np.ndarray], np.ndarray]] = None) -> Dict[str, Any]:
        """
        Apply Iron Core validation.
        
        Args:
            state_before: State before transformation
            state_after: State after transformation
            operation: Optional transformation function (if None, derives from states)
        
        Returns:
            Validation results dictionary
        """
        self._init_components()
        self._state = EngineState.VALIDATING
        
        validator = self._components["validator"]
        topology = self._components["topology"]
        
        # Create operation from states if not provided
        if operation is None:
            # Derive operation that produces state_after from state_before
            def derived_operation(x: np.ndarray) -> np.ndarray:
                return state_after.copy()
            operation = derived_operation
        
        # Validate immutability with the real operation
        immutability_result = validator.immutability.validate_operation(
            state_before, operation
        )
        
        # Compute actual Betti numbers using topology extractor
        try:
            # Project states to manifold for topology extraction
            before_manifold = self._project_to_manifold(state_before)
            after_manifold = self._project_to_manifold(state_after)
            
            topo_before = topology.extract(before_manifold)
            topo_after = topology.extract(after_manifold)
            
            betti_before = {
                "betti_0": topo_before.betti_0,
                "betti_1": topo_before.betti_1,
                "betti_2": topo_before.betti_2
            }
            betti_after = {
                "betti_0": topo_after.betti_0,
                "betti_1": topo_after.betti_1,
                "betti_2": topo_after.betti_2
            }
        except Exception:
            # Fallback to default topology if extraction fails
            betti_before = {"betti_0": 1, "betti_1": 0, "betti_2": 0}
            betti_after = {"betti_0": 1, "betti_1": 0, "betti_2": 0}
        
        # Check topology preservation with real Betti numbers
        topology_result = validator.topology.check_betti_preservation(
            betti_before, betti_after
        )
        # Extract boolean from ValidationResult if needed
        topology_preserved = (
            topology_result.passed if hasattr(topology_result, 'passed') 
            else bool(topology_result)
        )
        
        results = {
            "immutable": immutability_result.passed,
            "topology": topology_preserved,
            "betti_before": betti_before,
            "betti_after": betti_after,
        }
        
        if self.config.validation.enable_donders:
            # Donders validation checks if operation is properly implemented
            # For basic validation, verify operation produces expected output
            try:
                op_result = operation(state_before.copy())
                results["donders"] = bool(np.allclose(op_result, state_after, rtol=1e-5))
            except Exception:
                results["donders"] = False
        
        # Compute overall validity from boolean flags only (exclude dict values)
        bool_keys = ["immutable", "topology", "donders"] if self.config.validation.enable_donders else ["immutable", "topology"]
        results["valid"] = all(
            results[k] for k in bool_keys if k in results
        )
        
        self._state = EngineState.IDLE
        return results
    
    # =========================================================================
    # TRANSFORMS
    # =========================================================================
    
    def apply_teleological_warp(self, embeddings: np.ndarray,
                                 goal: np.ndarray) -> np.ndarray:
        """Apply T_teleo transform to each embedding."""
        self._init_components()
        t_teleo = self._components["t_teleo"]
        
        # Set goal for the warp
        if hasattr(t_teleo, 'set_goal'):
            t_teleo.set_goal(goal)
        
        # Apply warp to each embedding
        if len(embeddings.shape) == 1:
            return t_teleo.warp(embeddings)
        else:
            return np.array([t_teleo.warp(e) for e in embeddings])
    
    def apply_novelty_warp(self, embeddings: np.ndarray,
                           goal: np.ndarray,
                           archive: List[np.ndarray]) -> np.ndarray:
        """Apply T_novel transform to each embedding."""
        self._init_components()
        t_novel = self._components["t_novel"]
        
        # Update archive
        for item in archive:
            if hasattr(t_novel, 'add_to_archive'):
                t_novel.add_to_archive(item)
        
        # Apply warp to each embedding
        if len(embeddings.shape) == 1:
            return t_novel.warp(embeddings)
        else:
            return np.array([t_novel.warp(e) for e in embeddings])
    
    def check_regime_switch(self, 
                            layer_sequence: List[np.ndarray]) -> Optional[str]:
        """
        Check for regime switch using Z_switch.
        
        Analyzes the topological features from layer sequence
        and determines if a regime switch is warranted.
        """
        self._init_components()
        z_switch = self._components["z_switch"]
        
        # Extract features from the last layer
        if not layer_sequence:
            return None
        
        last_layer = layer_sequence[-1]
        
        # Use topology extractor to get features
        topology = self._components["topology"]
        try:
            topo_result = topology.extract(last_layer)
            current_features = {
                "betti_0": topo_result.betti_0,
                "betti_1": topo_result.betti_1,
                "betti_2": topo_result.betti_2,
                "persistence": topo_result.total_persistence
            }
        except Exception:
            current_features = {
                "betti_0": 1,
                "betti_1": 0,
                "betti_2": 0,
                "persistence": 0.5
            }
        
        # Check for regime switch
        return z_switch.should_switch(current_features)
    
    # =========================================================================
    # UTILITY METHODS
    # =========================================================================
    
    def get_status(self) -> Dict[str, Any]:
        """Get engine status."""
        return {
            "state": self._state.value,
            "initialized": self._initialized,
            "intent": {
                "context": self.intent.context.value,
                "scope": self.intent.scope,
            },
            "components": list(self._components.keys()) if self._initialized else [],
            "config": {
                "state_dim": self.config.pipeline.state_dim,
                "phi_critical": self.config.pipeline.phi_critical,
            }
        }
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance metrics summary."""
        return self.monitor.get_summary()
    
    def reset(self):
        """Reset engine state."""
        self._state = EngineState.IDLE
        
        if self._initialized:
            # Reset novelty archive
            novelty = self._components.get("novelty")
            if novelty:
                novelty.archive = []
        
        self.logger.info("Engine reset")


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_engine(preset: str = "balanced") -> OPrimeEngine:
    """
    Create engine with preset configuration.
    
    Args:
        preset: 'focused', 'balanced', 'creative', 'fast', 'production'
    
    Returns:
        Configured OPrimeEngine
    """
    presets = {
        "focused": ConfigPresets.focused_analysis,
        "balanced": ConfigPresets.balanced_research,
        "creative": ConfigPresets.creative_discovery,
        "fast": ConfigPresets.fast_prototype,
        "production": ConfigPresets.production,
    }
    
    if preset not in presets:
        raise ValueError(f"Unknown preset: {preset}. Choose from {list(presets.keys())}")
    
    config = presets[preset]()
    return OPrimeEngine(config)


def quick_process(data: np.ndarray, 
                  context: str = "general",
                  scope: float = 0.5) -> EngineResult:
    """
    Quick one-shot processing.
    
    Args:
        data: Input data array
        context: Intent context
        scope: Intent scope
    
    Returns:
        EngineResult
    """
    engine = OPrimeEngine()
    engine.set_context(context, scope)
    return engine.process(data)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'EngineState',
    'EngineResult',
    'OPrimeEngine',
    'create_engine',
    'quick_process',
]
