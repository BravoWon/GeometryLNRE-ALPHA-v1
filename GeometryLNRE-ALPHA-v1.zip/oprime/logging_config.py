"""
OPrime Logging & Monitoring
===========================

Structured logging with Intent Alignment context
and performance monitoring.
"""

import logging
import time
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from contextlib import contextmanager
from functools import wraps

from .core.intent_alignment import IntentConfiguration


# =============================================================================
# LOGGING SETUP
# =============================================================================

def setup_logging(level: str = "INFO", 
                  format_string: Optional[str] = None) -> logging.Logger:
    """
    Setup OPrime logging.
    
    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)
        format_string: Custom format string
    
    Returns:
        Configured logger
    """
    logger = logging.getLogger("oprime")
    
    if format_string is None:
        format_string = (
            "%(asctime)s | %(levelname)-8s | "
            "%(name)s.%(funcName)s:%(lineno)d | %(message)s"
        )
    
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(format_string))
    
    logger.addHandler(handler)
    logger.setLevel(getattr(logging, level.upper()))
    
    return logger


# Global logger
logger = setup_logging()


# =============================================================================
# PERFORMANCE METRICS
# =============================================================================

@dataclass
class PerformanceMetrics:
    """Container for performance metrics."""
    operation: str
    start_time: float = 0.0
    end_time: float = 0.0
    duration_ms: float = 0.0
    memory_mb: float = 0.0
    success: bool = True
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def finalize(self):
        """Calculate final metrics."""
        self.duration_ms = (self.end_time - self.start_time) * 1000


class PerformanceMonitor:
    """
    Monitor performance of OPrime operations.
    
    Tracks timing, memory usage, and success rates.
    """
    
    def __init__(self, intent: Optional[IntentConfiguration] = None):
        self.intent = intent
        self.metrics_history: List[PerformanceMetrics] = []
        self.operation_counts: Dict[str, int] = {}
        self.operation_times: Dict[str, List[float]] = {}
    
    @contextmanager
    def track(self, operation: str, **metadata):
        """
        Context manager for tracking operation performance.
        
        Usage:
            with monitor.track("pipeline_process"):
                result = pipeline.process(data)
        """
        metrics = PerformanceMetrics(
            operation=operation,
            start_time=time.time(),
            metadata=metadata
        )
        
        if self.intent:
            metrics.metadata["intent_context"] = self.intent.context.value
            metrics.metadata["intent_scope"] = self.intent.scope
        
        try:
            yield metrics
            metrics.success = True
        except Exception as e:
            metrics.success = False
            metrics.error = str(e)
            raise
        finally:
            metrics.end_time = time.time()
            metrics.finalize()
            self._record(metrics)
    
    def _record(self, metrics: PerformanceMetrics):
        """Record metrics."""
        self.metrics_history.append(metrics)
        
        op = metrics.operation
        self.operation_counts[op] = self.operation_counts.get(op, 0) + 1
        
        if op not in self.operation_times:
            self.operation_times[op] = []
        self.operation_times[op].append(metrics.duration_ms)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get performance summary."""
        import numpy as np
        
        summary = {
            "total_operations": len(self.metrics_history),
            "success_rate": sum(1 for m in self.metrics_history if m.success) / 
                           max(1, len(self.metrics_history)),
            "operations": {}
        }
        
        for op, times in self.operation_times.items():
            if times:
                summary["operations"][op] = {
                    "count": self.operation_counts[op],
                    "mean_ms": float(np.mean(times)),
                    "std_ms": float(np.std(times)),
                    "min_ms": float(np.min(times)),
                    "max_ms": float(np.max(times)),
                }
        
        return summary
    
    def log_summary(self):
        """Log performance summary."""
        summary = self.get_summary()
        
        logger.info("=" * 50)
        logger.info("Performance Summary")
        logger.info("=" * 50)
        logger.info(f"Total operations: {summary['total_operations']}")
        logger.info(f"Success rate: {summary['success_rate']:.1%}")
        
        for op, stats in summary.get("operations", {}).items():
            logger.info(
                f"  {op}: {stats['count']} calls, "
                f"{stats['mean_ms']:.2f}ms ± {stats['std_ms']:.2f}ms"
            )


# =============================================================================
# INTENT-AWARE LOGGING
# =============================================================================

class IntentLogger:
    """
    Logger that includes Intent Alignment context.
    
    All log messages include current intent state.
    """
    
    def __init__(self, intent: IntentConfiguration, name: str = "oprime"):
        self.intent = intent
        self.logger = logging.getLogger(name)
        self._prefix = self._compute_prefix()
    
    def _compute_prefix(self) -> str:
        """Compute log prefix from intent."""
        return f"[{self.intent.context.value.upper()}/{self.intent.scope:.1f}]"
    
    def update_intent(self, intent: IntentConfiguration):
        """Update intent and recompute prefix."""
        self.intent = intent
        self._prefix = self._compute_prefix()
    
    def debug(self, message: str, **kwargs):
        self.logger.debug(f"{self._prefix} {message}", **kwargs)
    
    def info(self, message: str, **kwargs):
        self.logger.info(f"{self._prefix} {message}", **kwargs)
    
    def warning(self, message: str, **kwargs):
        self.logger.warning(f"{self._prefix} {message}", **kwargs)
    
    def error(self, message: str, **kwargs):
        self.logger.error(f"{self._prefix} {message}", **kwargs)
    
    def log_pipeline_result(self, result: Any):
        """Log pipeline result summary."""
        self.info(
            f"Pipeline: valid={result.is_valid}, "
            f"β₁={result.topology.betti_1}, "
            f"Φ={result.phi:.3f}, "
            f"time={result.processing_time*1000:.1f}ms"
        )
    
    def log_search_result(self, actions: List, value: float, stats: Dict):
        """Log search result summary."""
        self.info(
            f"Search: {len(actions)} actions, "
            f"value={value:.3f}, "
            f"nodes={stats.get('nodes_expanded', 0)}"
        )
    
    def log_regime_switch(self, old_regime: str, new_regime: str, confidence: float):
        """Log regime switch."""
        self.info(
            f"Regime switch: {old_regime} → {new_regime} "
            f"(confidence={confidence:.2f})"
        )


# =============================================================================
# DECORATORS
# =============================================================================

def log_operation(operation_name: Optional[str] = None):
    """
    Decorator to log operation timing.
    
    Usage:
        @log_operation("process_data")
        def process_data(self, data):
            ...
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            name = operation_name or func.__name__
            start = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration = (time.time() - start) * 1000
                logger.debug(f"{name}: completed in {duration:.2f}ms")
                return result
            except Exception as e:
                duration = (time.time() - start) * 1000
                logger.error(f"{name}: failed after {duration:.2f}ms - {e}")
                raise
        
        return wrapper
    return decorator


def log_intent_aligned(func):
    """
    Decorator for intent-aligned operations.
    
    Logs intent context before and after operation.
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if hasattr(self, 'intent'):
            intent = self.intent
            logger.debug(
                f"[{intent.context.value}/{intent.scope:.1f}] "
                f"Starting {func.__name__}"
            )
        
        result = func(self, *args, **kwargs)
        
        if hasattr(self, 'intent'):
            logger.debug(
                f"[{intent.context.value}/{intent.scope:.1f}] "
                f"Completed {func.__name__}"
            )
        
        return result
    
    return wrapper


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'setup_logging',
    'logger',
    'PerformanceMetrics',
    'PerformanceMonitor',
    'IntentLogger',
    'log_operation',
    'log_intent_aligned',
]
