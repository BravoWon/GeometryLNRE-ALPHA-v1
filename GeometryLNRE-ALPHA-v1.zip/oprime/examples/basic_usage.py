#!/usr/bin/env python3
"""
Basic OPrime Usage Examples
===========================

This script demonstrates the core functionality of OPrime
with Intent Alignment (Context × Scope).
"""

import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.intent_alignment import (
    IntentConfiguration, 
    IntentContext, 
    IntentPresets,
    parse_intent
)
from pipeline import OPrimePipeline


def example_1_basic_pipeline():
    """Example 1: Basic pipeline usage."""
    print("\n" + "=" * 50)
    print("Example 1: Basic Pipeline Usage")
    print("=" * 50)
    
    # Create intent
    intent = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=0.5,
        value_statement="Analyze the data structure"
    )
    
    # Create pipeline
    pipeline = OPrimePipeline(intent, state_dim=30)
    
    # Process input
    input_data = np.random.randn(30)
    result = pipeline.process(input_data)
    
    # Print results
    print(f"\nInput shape: {input_data.shape}")
    print(f"Manifold embedding shape: {result.manifold_embedding.shape}")
    print(f"Topology: β₀={result.topology.betti_0}, β₁={result.topology.betti_1}")
    print(f"Integration (Φ): {result.phi:.4f}")
    print(f"Conscious state valid: {result.is_valid}")
    print(f"Processing time: {result.processing_time*1000:.2f} ms")


def example_2_intent_from_prompt():
    """Example 2: Parse intent from natural language."""
    print("\n" + "=" * 50)
    print("Example 2: Intent from Natural Language")
    print("=" * 50)
    
    prompts = [
        "Solve this equation precisely",  # SPECIFIC
        "Explore mathematical structures broadly",  # GENERAL + broad
        "Discover novel patterns in the data",  # EXPLORATORY
    ]
    
    for prompt in prompts:
        intent = parse_intent(prompt)
        print(f"\nPrompt: '{prompt}'")
        print(f"  Context: {intent.context.value}")
        print(f"  Scope: {intent.scope:.2f}")
        print(f"  Value Intensity: {intent.value_intensity:.2f}")


def example_3_presets():
    """Example 3: Using intent presets."""
    print("\n" + "=" * 50)
    print("Example 3: Intent Presets")
    print("=" * 50)
    
    presets = [
        ("Focused Goal", IntentPresets.focused_goal("Solve x² = 4")),
        ("Conceptual Exploration", IntentPresets.conceptual_exploration("topology")),
        ("Pure Discovery", IntentPresets.pure_discovery()),
        ("Balanced Research", IntentPresets.balanced_research("consciousness")),
    ]
    
    for name, intent in presets:
        print(f"\n{name}:")
        print(f"  Context: {intent.context.value}")
        print(f"  Scope: {intent.scope:.2f}")
        print(f"  Novelty weights: {intent.novelty_weights}")


def example_4_comparing_intents():
    """Example 4: Compare results with different intents."""
    print("\n" + "=" * 50)
    print("Example 4: Comparing Intent Effects")
    print("=" * 50)
    
    # Same input, different intents
    input_data = np.random.randn(20)
    
    intents = [
        ("SPECIFIC/Narrow", IntentContext.SPECIFIC, 0.2),
        ("GENERAL/Balanced", IntentContext.GENERAL, 0.5),
        ("EXPLORATORY/Broad", IntentContext.EXPLORATORY, 0.9),
    ]
    
    print(f"\n{'Intent':<25} {'Novelty B':<12} {'Novelty T':<12} {'Novelty S':<12}")
    print("-" * 60)
    
    for name, context, scope in intents:
        intent = IntentConfiguration(context=context, scope=scope)
        pipeline = OPrimePipeline(intent, state_dim=20)
        result = pipeline.process(input_data.copy())
        
        ns = result.novelty_scores
        print(f"{name:<25} {ns['behavioral']:<12.4f} "
              f"{ns['topological']:<12.4f} {ns['semantic']:<12.4f}")


def example_5_novelty_tracking():
    """Example 5: Track novelty over multiple inputs."""
    print("\n" + "=" * 50)
    print("Example 5: Novelty Tracking Over Time")
    print("=" * 50)
    
    intent = IntentPresets.pure_discovery()
    pipeline = OPrimePipeline(intent, state_dim=20)
    
    print("\nProcessing sequence of inputs:")
    print(f"{'Step':<8} {'Behavioral':<15} {'Exploration Bonus':<15}")
    print("-" * 40)
    
    for i in range(5):
        input_data = np.random.randn(20) + i * 0.1
        result = pipeline.process(input_data)
        
        b = result.novelty_scores['behavioral']
        e = result.exploration_bonus
        
        b_str = f"{b:.4f}" if b != float('inf') else "inf"
        print(f"{i+1:<8} {b_str:<15} {e:<15.4f}")


def main():
    print("\n" + "=" * 50)
    print("  OPRIME BASIC USAGE EXAMPLES")
    print("=" * 50)
    
    example_1_basic_pipeline()
    example_2_intent_from_prompt()
    example_3_presets()
    example_4_comparing_intents()
    example_5_novelty_tracking()
    
    print("\n" + "=" * 50)
    print("  Examples Complete")
    print("=" * 50 + "\n")


if __name__ == "__main__":
    main()
