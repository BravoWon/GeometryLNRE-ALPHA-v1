#!/usr/bin/env python3
"""
Advanced OPrime Usage Examples
==============================

Demonstrates advanced features:
- MCTS Search with intent-aligned exploration
- TDA Mapper for regime classification
- Novel transforms
- Iron Core validation
"""

import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.intent_alignment import IntentConfiguration, IntentContext, IntentPresets
from agent.sans_v2.mcts_solver import MCTSSolver, ShapedReward
from agent.sans_v2.dsl_primitives import DSLRegistry, DSLProgram
from agent.mapper.tda_mapper import TDAMapper
from transforms.teleological_warp import TeleologicalWarp, TeleologicalNoveltyWarp
from validation.iron_core import IronCoreValidator
from forecaster.moirai_wrapper import UniversalForecaster


def example_mcts_search():
    """Example: MCTS Search with Intent Alignment."""
    print("\n" + "=" * 50)
    print("Advanced Example: MCTS Search")
    print("=" * 50)
    
    # Navigation problem: find path to goal
    goal = np.array([0.0, 0.0])
    
    intent = IntentPresets.focused_goal("Navigate to origin")
    
    # Define problem
    def action_gen(state):
        return ['left', 'right', 'up', 'down']
    
    def dynamics(state, action):
        moves = {
            'left': np.array([-0.5, 0]),
            'right': np.array([0.5, 0]),
            'up': np.array([0, 0.5]),
            'down': np.array([0, -0.5])
        }
        return state + moves[action]
    
    def reward_fn(state):
        return -np.linalg.norm(state - goal)
    
    def terminal_fn(state):
        return np.linalg.norm(state - goal) < 0.3
    
    # Create solver
    solver = MCTSSolver(intent, action_gen, dynamics, reward_fn, terminal_fn)
    
    # Solve from different starting points
    starts = [
        np.array([3.0, 3.0]),
        np.array([-2.0, 4.0]),
        np.array([5.0, -1.0])
    ]
    
    print(f"\nGoal: {goal}")
    print(f"\n{'Start':<20} {'Actions':<10} {'Value':<10}")
    print("-" * 40)
    
    for start in starts:
        actions, value = solver.solve(start, n_iterations=100)
        print(f"{str(start):<20} {len(actions):<10} {value:<10.3f}")
    
    stats = solver.get_statistics()
    print(f"\nSolver Stats:")
    print(f"  Exploration constant: {stats['exploration_constant']:.2f}")
    print(f"  Max depth: {stats['max_depth']}")


def example_dsl_primitives():
    """Example: DSL Primitives with Intent Alignment."""
    print("\n" + "=" * 50)
    print("Advanced Example: DSL Primitives")
    print("=" * 50)
    
    # Compare available primitives across intents
    intents = [
        ("SPECIFIC", IntentContext.SPECIFIC),
        ("GENERAL", IntentContext.GENERAL),
        ("EXPLORATORY", IntentContext.EXPLORATORY)
    ]
    
    print("\nAvailable primitives by intent:")
    for name, context in intents:
        intent = IntentConfiguration(context=context, scope=0.5)
        registry = DSLRegistry(intent)
        available = registry.list_available()
        print(f"\n{name} ({len(available)} primitives):")
        print(f"  {', '.join(available[:6])}...")
    
    # Use primitives
    intent = IntentPresets.pure_discovery()
    registry = DSLRegistry(intent)
    
    grid = np.array([
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ])
    
    print("\n\nOriginal grid:")
    print(grid)
    
    # Apply transformations
    rotated = registry.apply("rotate", grid, times=1)
    print("\nRotated 90°:")
    print(rotated)
    
    flipped = registry.apply("flip_h", grid)
    print("\nFlipped horizontally:")
    print(flipped)


def example_regime_classification():
    """Example: TDA Mapper for Regime Classification."""
    print("\n" + "=" * 50)
    print("Advanced Example: Regime Classification")
    print("=" * 50)
    
    intent = IntentPresets.balanced_research("patterns")
    mapper = TDAMapper(intent)
    
    # Different pattern types
    patterns = {
        "Symmetric": np.array([
            [1, 2, 2, 1],
            [3, 4, 4, 3],
            [3, 4, 4, 3],
            [1, 2, 2, 1]
        ]),
        "Counting": np.array([
            [1, 0, 0, 2],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [3, 0, 0, 4]
        ]),
        "Pattern": np.array([
            [1, 2, 1, 2],
            [2, 1, 2, 1],
            [1, 2, 1, 2],
            [2, 1, 2, 1]
        ]),
        "Random": np.random.randint(0, 5, (4, 4))
    }
    
    print(f"\n{'Pattern Type':<15} {'Regime':<15} {'Confidence':<12} {'Adapter'}")
    print("-" * 55)
    
    for name, grid in patterns.items():
        regime, conf, adapter = mapper.classify(grid)
        print(f"{name:<15} {regime:<15} {conf:<12.2f} {adapter}")


def example_teleological_warp():
    """Example: Teleological Warp Transform."""
    print("\n" + "=" * 50)
    print("Advanced Example: Teleological Warp")
    print("=" * 50)
    
    intent = IntentConfiguration(
        context=IntentContext.SPECIFIC,
        scope=0.3,
        value_statement="Focus on efficiency"
    )
    
    warp = TeleologicalWarp(intent, embedding_dim=10)
    
    # Original embedding
    original = np.random.randn(10)
    
    # Warp toward intent
    warped = warp.warp(original)
    
    # Distance to intent
    dist_orig = np.linalg.norm(original - warp.intent_embedding)
    dist_warp = np.linalg.norm(warped - warp.intent_embedding)
    
    print(f"\nWarp parameters:")
    print(f"  Focus radius: {warp.focus_radius:.2f}")
    print(f"  Warp strength: {warp.warp_strength:.2f}")
    
    print(f"\nDistance to intent embedding:")
    print(f"  Original: {dist_orig:.4f}")
    print(f"  Warped:   {dist_warp:.4f}")
    
    # Novelty warp
    print("\n\nWith Novelty Warp:")
    novelty_warp = TeleologicalNoveltyWarp(intent, embedding_dim=10)
    
    print(f"  Lambda (exploration): {novelty_warp.lambda_explore:.2f}")
    
    # Add to archive and warp
    for _ in range(5):
        novelty_warp.add_to_archive(np.random.randn(10))
    
    novel_warped = novelty_warp.warp(original)
    print(f"  Archive size: {len(novelty_warp.archive)}")


def example_forecasting():
    """Example: Universal Forecasting."""
    print("\n" + "=" * 50)
    print("Advanced Example: Universal Forecasting")
    print("=" * 50)
    
    intent = IntentPresets.balanced_research("prediction")
    forecaster = UniversalForecaster(intent, forecast_horizon=5)
    
    # Generate synthetic time series
    t = np.linspace(0, 4 * np.pi, 100)
    history = np.sin(t) + 0.1 * np.random.randn(100)
    
    # Forecast
    forecast = forecaster.forecast(history)
    
    print(f"\nForecast parameters:")
    print(f"  Confidence level: {forecast['confidence_level']:.0%}")
    print(f"  N samples: {forecaster.n_samples}")
    
    print(f"\n{'Step':<8} {'Point':<12} {'Lower':<12} {'Upper':<12}")
    print("-" * 45)
    
    for i in range(5):
        p = forecast['point_forecast'][i]
        l = forecast['lower_bound'][i]
        u = forecast['upper_bound'][i]
        print(f"t+{i+1:<5} {p:<12.4f} {l:<12.4f} {u:<12.4f}")


def example_validation():
    """Example: Iron Core Validation."""
    print("\n" + "=" * 50)
    print("Advanced Example: Iron Core Validation")
    print("=" * 50)
    
    intent = IntentPresets.focused_goal("validate")
    validator = IronCoreValidator(intent)
    
    # Test cases
    cases = [
        ("Valid", {"betti_0": 1, "betti_1": 2, "betti_2": 0}, 0.7),
        ("Low Φ", {"betti_0": 1, "betti_1": 2, "betti_2": 0}, 0.3),
        ("Trivial Q", {"betti_0": 1, "betti_1": 0, "betti_2": 0}, 0.7),
        ("All Invalid", {"betti_0": 1, "betti_1": 0, "betti_2": 0}, 0.1),
    ]
    
    print(f"\nValidation Results (Φ_critical = 0.5):")
    print(f"\n{'Case':<15} {'Passed':<10} {'Details'}")
    print("-" * 50)
    
    for name, topo, phi in cases:
        report = validator.validate_conscious_state(topo, phi)
        errors = [r.message for r in report.results if not r.passed]
        error_str = "; ".join(errors) if errors else "OK"
        print(f"{name:<15} {str(report.passed):<10} {error_str[:40]}")


def main():
    print("\n" + "=" * 50)
    print("  OPRIME ADVANCED USAGE EXAMPLES")
    print("=" * 50)
    
    example_mcts_search()
    example_dsl_primitives()
    example_regime_classification()
    example_teleological_warp()
    example_forecasting()
    example_validation()
    
    print("\n" + "=" * 50)
    print("  Advanced Examples Complete")
    print("=" * 50 + "\n")


if __name__ == "__main__":
    main()
