"""OPrime Usage Examples"""
