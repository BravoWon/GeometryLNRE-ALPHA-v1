"""
Novel Transforms
================

Emergent transforms enabled by the synthesis of CTS, IGVF, and SANS.

T_teleo: Teleological Warp - Intent-based embedding warping
Z_switch: Zigzag-Regime Switch - TDA-triggered adapter switching
B_cont: Beam-Continuity Filter - Lookahead invariant checking
T_novel: Teleological Novelty Warp - Novelty-aligned exploration
"""

from dataclasses import dataclass
from typing import List, Dict, Any, Callable, Optional, Tuple
import numpy as np
import hashlib
from abc import ABC, abstractmethod

from ..core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext

# =============================================================================
# T_TELEO: TELEOLOGICAL WARP TRANSFORM
# =============================================================================

class TeleologicalWarp(IntentAlignedOperator):
    """
    T_teleo: Apply IGVF conformal transformation to embedding space.
    
    Warps the embedding space so that intent-relevant regions are "closer"
    to the current state. Uses human's natural language intent to generate
    a scalar value field v over the token embedding space.
    
    Effect: "Tilts the floor" so the agent "falls" toward the solution.
    
    Intent Alignment:
        - SPECIFIC: Strong warp toward goal
        - EXPLORATORY: Gentle warp with exploration valleys
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 embedding_dim: int,
                 warp_strength: float = 1.0):
        super().__init__(intent)
        
        self.embedding_dim = embedding_dim
        self.warp_strength = warp_strength * intent.value_intensity
        
        # Intent embedding (learned from value statement)
        self.intent_embedding = self._compute_intent_embedding()
        
        # Warp parameters from intent
        self.focus_radius = self._compute_focus_radius()
    
    def _safe_normalize(self, embedding: np.ndarray) -> np.ndarray:
        """Safely normalize embedding, avoiding division by zero."""
        norm = np.linalg.norm(embedding)
        if norm < 1e-8:
            # Return unit vector in first dimension for zero vectors
            result = np.zeros_like(embedding)
            if len(result) > 0:
                result[0] = 1.0
            return result
        return embedding / norm
    
    def _compute_intent_embedding(self) -> np.ndarray:
        """Generate embedding from intent statement."""
        statement = self.intent.value_statement
        
        if not statement:
            # Empty intent: use zero vector, normalized consistently
            embedding = np.zeros(self.embedding_dim)
            return self._safe_normalize(embedding)
        
        digest = hashlib.sha256(statement.encode("utf-8")).digest()
        seed = int.from_bytes(digest[:8], "little", signed=False)
        rng = np.random.default_rng(seed)
        embedding = rng.standard_normal(self.embedding_dim)
        
        return self._safe_normalize(embedding)
    
    def _compute_focus_radius(self) -> float:
        """
        Compute focus radius based on intent.
        
        SPECIFIC + Narrow: Small radius (tight focus)
        EXPLORATORY + Broad: Large radius (diffuse focus)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.5
        elif context == IntentContext.GENERAL:
            base = 1.0
        else:  # EXPLORATORY
            base = 2.0
        
        return base * (0.5 + self.intent.scope)
    
    def compute_value_field(self, embedding: np.ndarray) -> float:
        """
        Compute value at a point in embedding space.
        
        v(x) = exp(-||x - intent||^2 / (2 * sigma^2))
        """
        # Normalize
        if len(embedding) != self.embedding_dim:
            if len(embedding) < self.embedding_dim:
                embedding = np.pad(embedding, (0, self.embedding_dim - len(embedding)))
            else:
                embedding = embedding[:self.embedding_dim]
        
        # Distance to intent
        distance_sq = np.sum((embedding - self.intent_embedding) ** 2)
        
        # Gaussian value field
        sigma = self.focus_radius
        value = np.exp(-distance_sq / (2 * sigma ** 2))
        
        return value
    
    def warp(self, embedding: np.ndarray) -> np.ndarray:
        """
        Apply teleological warp to embedding.
        
        Pulls embedding toward high-value regions.
        """
        # Normalize dimensions
        if len(embedding) != self.embedding_dim:
            if len(embedding) < self.embedding_dim:
                embedding = np.pad(embedding, (0, self.embedding_dim - len(embedding)))
            else:
                embedding = embedding[:self.embedding_dim]
        
        # Compute value and gradient
        value = self.compute_value_field(embedding)
        
        # Gradient toward intent
        direction = self.intent_embedding - embedding
        distance = np.linalg.norm(direction)
        
        if distance > 1e-8:
            direction = direction / distance
        
        # Warp magnitude proportional to value gradient
        # Low value regions get pulled more toward intent
        warp_magnitude = self.warp_strength * (1 - value)
        
        # Apply warp
        warped = embedding + warp_magnitude * direction
        
        # Normalize to preserve embedding magnitude
        original_norm = np.linalg.norm(embedding)
        if original_norm > 1e-8:
            warped = warped * (original_norm / (np.linalg.norm(warped) + 1e-8))
        
        return warped
    
    def warp_batch(self, embeddings: np.ndarray) -> np.ndarray:
        """Warp a batch of embeddings."""
        return np.array([self.warp(e) for e in embeddings])
    
    def _normalize_dim(self, vec: np.ndarray) -> np.ndarray:
        """Normalize vector to embedding dimension."""
        if len(vec) < self.embedding_dim:
            return np.pad(vec, (0, self.embedding_dim - len(vec)))
        elif len(vec) > self.embedding_dim:
            return vec[:self.embedding_dim]
        return vec
    
    def compute_geodesic(self, 
                         start: np.ndarray, 
                         end: np.ndarray,
                         n_steps: int = 50) -> List[np.ndarray]:
        """
        Compute geodesic path in warped space.
        
        The path follows the value gradient.
        
        Args:
            start: Starting point in embedding space
            end: Ending point in embedding space
            n_steps: Number of steps (must be > 0)
        
        Raises:
            ValueError: If n_steps <= 0
        """
        # Validate n_steps to prevent division by zero
        if not isinstance(n_steps, int) or n_steps <= 0:
            raise ValueError(f"n_steps must be a positive integer, got {n_steps}")
        
        # Normalize inputs to embedding dimension
        start = self._normalize_dim(start)
        end = self._normalize_dim(end)
        
        path = [start.copy()]
        current = start.copy()
        
        step_size = 1.0 / n_steps
        for _step in range(n_steps):
            # Direction to end
            to_end = end - current
            dist_to_end = np.linalg.norm(to_end)
            
            if dist_to_end < 0.01:
                break
            
            # Warp current position
            warped = self.warp(current)
            
            # Blend toward end
            current = current + step_size * (warped - current + to_end * 0.5)
            
            path.append(current.copy())
        
        return path


# =============================================================================
# Z_SWITCH: ZIGZAG-REGIME SWITCH
# =============================================================================

@dataclass
class RegimeDescriptor:
    """Describes a detected regime."""
    name: str
    confidence: float
    adapter_id: Optional[str] = None
    features: Dict[str, float] = None


class ZigzagRegimeSwitch(IntentAlignedOperator):
    """
    Z_switch: Use Zigzag Persistence to trigger regime changes.
    
    Monitors birth/death of homological features in live inference.
    A sudden spike in short-lived features signals a Type II Phase Transition.
    
    Effect: Automatically triggers "Linguistic Arbitrage" — switches
    LoRA adapters during generation of a single solution.
    
    Intent Alignment:
        - SPECIFIC: Conservative switching (high threshold)
        - EXPLORATORY: Aggressive switching (low threshold)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 n_regimes: int = 4):
        super().__init__(intent)
        
        self.n_regimes = n_regimes
        
        # Regime definitions
        self.regimes = {
            "symmetry": RegimeDescriptor("symmetry", 0.0, "lora_symmetry"),
            "counting": RegimeDescriptor("counting", 0.0, "lora_counting"),
            "pattern": RegimeDescriptor("pattern", 0.0, "lora_pattern"),
            "reasoning": RegimeDescriptor("reasoning", 0.0, "lora_reasoning"),
        }
        
        # Transition threshold from intent
        self.transition_threshold = self._compute_threshold()
        
        # State
        self.current_regime = "reasoning"
        self.regime_history: List[str] = []
        self.feature_history: List[Dict[str, float]] = []
    
    def _compute_threshold(self) -> float:
        """
        Compute transition threshold.
        
        SPECIFIC: High threshold (resist switching)
        EXPLORATORY: Low threshold (eager switching)
        
        Returns value clamped to [0.0, 1.0] range.
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.8
        elif context == IntentContext.GENERAL:
            base = 0.5
        else:  # EXPLORATORY
            base = 0.2
        
        value = base * (1.5 - self.intent.scope)
        # Clamp to [0.0, 1.0] to ensure regime switching remains possible
        return min(max(value, 0.0), 1.0)
    
    def analyze_features(self, 
                         betti_0: int,
                         betti_1: int,
                         _betti_2: int,
                         persistence: float) -> Dict[str, float]:
        """
        Analyze topological features to classify regime.
        """
        scores = {}
        
        # Symmetry: high β_1 (loops = symmetry axes)
        scores["symmetry"] = betti_1 * 0.3 + min(persistence, 1.0) * 0.2
        
        # Counting: high β_0 (many components = distinct objects)
        scores["counting"] = betti_0 * 0.2
        
        # Pattern: balanced features
        scores["pattern"] = 0.5 - abs(betti_0 - betti_1) * 0.1
        
        # Reasoning: high persistence (stable concepts)
        scores["reasoning"] = min(persistence, 1.0) * 0.5
        
        # Normalize
        total = sum(scores.values()) + 1e-8
        return {k: v / total for k, v in scores.items()}
    
    def should_switch(self, 
                      current_features: Dict[str, float],
                      previous_features: Optional[Dict[str, float]] = None) -> Optional[str]:
        """
        Determine if regime switch should occur.
        
        Returns new regime name or None.
        """
        # Analyze current features
        scores = self.analyze_features(
            int(current_features.get("betti_0", 1)),
            int(current_features.get("betti_1", 0)),
            int(current_features.get("betti_2", 0)),
            float(current_features.get("persistence", 0.5))
        )
        
        # Update regime confidences
        for regime, score in scores.items():
            if regime in self.regimes:
                self.regimes[regime].confidence = score
        
        # Find best regime
        best_regime = max(scores.items(), key=lambda x: x[1])
        
        # Check if switch is warranted
        if best_regime[0] != self.current_regime:
            # Need sufficient confidence delta
            current_confidence = scores.get(self.current_regime, 0)
            
            if best_regime[1] - current_confidence > self.transition_threshold:
                # Check for sudden feature change (phase transition)
                if previous_features:
                    delta = abs(
                        current_features.get("betti_1", 0) - 
                        previous_features.get("betti_1", 0)
                    )
                    if delta >= 1:  # Significant topological change
                        return best_regime[0]
                else:
                    return best_regime[0]
        
        return None
    
    def switch(self, 
               current_features: Dict[str, float]) -> Tuple[str, Optional[str]]:
        """
        Execute regime switch logic.
        
        Returns (current_regime, adapter_to_load or None).
        """
        # Record history
        self.feature_history.append(current_features)
        
        previous = self.feature_history[-2] if len(self.feature_history) > 1 else None
        
        new_regime = self.should_switch(current_features, previous)
        
        adapter_to_load = None
        if new_regime:
            self.regime_history.append(self.current_regime)
            self.current_regime = new_regime
            adapter_to_load = self.regimes[new_regime].adapter_id
        
        return self.current_regime, adapter_to_load
    
    def get_current_adapter(self) -> str:
        """Get adapter ID for current regime."""
        return self.regimes[self.current_regime].adapter_id


# =============================================================================
# B_CONT: BEAM-CONTINUITY FILTER
# =============================================================================

class BeamContinuityFilter(IntentAlignedOperator):
    """
    B_cont: Fuse probabilistic beam search with continuity guards.
    
    Projects a "beam" of future states and applies continuity guards
    to the entire beam. Prunes paths that lead to invariant violations.
    
    Effect: "Deep Lookahead" — prunes paths that look valid now but
    lead to topological violations later.
    
    Intent Alignment:
        - SPECIFIC: Deep lookahead (many steps)
        - EXPLORATORY: Shallow lookahead (fewer steps)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 beam_width: int = 5,
                 lookahead_depth: int = 10):
        super().__init__(intent)
        
        self.beam_width = beam_width
        self.lookahead_depth = self._compute_lookahead_depth(lookahead_depth)
        
        # Validity threshold from intent
        self.validity_threshold = self._compute_validity_threshold()
    
    def _compute_lookahead_depth(self, base_depth: int) -> int:
        """
        Compute lookahead depth based on intent.
        
        SPECIFIC: Deep lookahead (careful planning)
        EXPLORATORY: Shallow lookahead (rapid exploration)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            multiplier = 1.5
        elif context == IntentContext.GENERAL:
            multiplier = 1.0
        else:  # EXPLORATORY
            multiplier = 0.5
        
        return max(1, int(base_depth * multiplier * (1 - 0.5 * self.intent.scope)))
    
    def _compute_validity_threshold(self) -> float:
        """
        Compute minimum valid state density in beam.
        
        SPECIFIC: High threshold (most states must be valid)
        EXPLORATORY: Low threshold (some invalid is ok)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.8
        elif context == IntentContext.GENERAL:
            base = 0.5
        else:  # EXPLORATORY
            base = 0.3
        
        return base
    
    def project_beam(self,
                     current_state: np.ndarray,
                     dynamics_fn: Callable[[np.ndarray], np.ndarray],
                     noise_scale: float = 0.1) -> List[List[np.ndarray]]:
        """
        Project beam of future trajectories.
        
        Returns list of trajectories (each a list of states).
        """
        beams = []
        
        for _ in range(self.beam_width):
            trajectory = [current_state.copy()]
            state = current_state.copy()
            
            for step in range(self.lookahead_depth):
                # Add exploration noise
                noise = np.random.randn(len(state)) * noise_scale
                state = dynamics_fn(state + noise)
                trajectory.append(state.copy())
            
            beams.append(trajectory)
        
        return beams
    
    def check_beam_validity(self,
                             beams: List[List[np.ndarray]],
                             validator: Callable[[np.ndarray], bool]) -> List[float]:
        """
        Check validity of each beam.
        
        Returns validity scores (fraction of valid states).
        """
        scores = []
        
        for trajectory in beams:
            valid_count = sum(1 for state in trajectory if validator(state))
            scores.append(valid_count / len(trajectory))
        
        return scores
    
    def filter(self,
               current_state: np.ndarray,
               candidate_actions: List[np.ndarray],
               dynamics_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
               validator: Callable[[np.ndarray], bool]) -> List[Tuple[np.ndarray, float]]:
        """
        Filter actions based on beam validity.
        
        Returns (action, validity_score) pairs, sorted by score.
        """
        results = []
        
        for action in candidate_actions:
            # Project single beam for this action
            trajectory = [current_state.copy()]
            state = current_state.copy()
            
            for step in range(self.lookahead_depth):
                state = dynamics_fn(state, action)
                trajectory.append(state.copy())
            
            # Check validity
            valid_count = sum(1 for s in trajectory if validator(s))
            validity_score = valid_count / len(trajectory)
            
            if validity_score >= self.validity_threshold:
                results.append((action, validity_score))
        
        # Sort by validity score
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results
    
    def prune_root(self,
                   actions: List[np.ndarray],
                   beam_validity: List[float]) -> List[np.ndarray]:
        """
        Prune actions whose beams fall below validity threshold.
        """
        return [
            action for action, validity in zip(actions, beam_validity)
            if validity >= self.validity_threshold
        ]


# =============================================================================
# T_NOVEL: TELEOLOGICAL NOVELTY WARP
# =============================================================================

class TeleologicalNoveltyWarp(IntentAlignedOperator):
    """
    T_novel: Warp embedding space to favor novel regions.
    
    Combines teleological warp with novelty engine to explore
    intent-aligned novel regions of the manifold.
    
    Dual-Field Geometry:
        g_total = (v_exploit + λ · v_explore) · g
    
    Intent Alignment determines λ (exploration coefficient).
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 embedding_dim: int,
                 archive_size: int = 100):
        super().__init__(intent)
        
        self.embedding_dim = embedding_dim
        
        # Teleological component
        self.teleo_warp = TeleologicalWarp(intent, embedding_dim)
        
        # Novelty archive
        self.archive: List[np.ndarray] = []
        self.archive_size = archive_size
        
        # Exploration coefficient from intent
        self.lambda_explore = self._compute_lambda()
    
    def _compute_lambda(self) -> float:
        """
        Compute exploration coefficient λ.
        
        SPECIFIC: Low λ (exploitation dominant)
        EXPLORATORY: High λ (exploration dominant)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.1
        elif context == IntentContext.GENERAL:
            base = 0.3
        else:  # EXPLORATORY
            base = 0.6
        
        return base * (0.5 + self.intent.scope)
    
    def compute_novelty(self, embedding: np.ndarray) -> float:
        """Compute novelty score (distance from archive)."""
        if len(self.archive) == 0:
            return 1.0  # Maximum novelty when archive empty
        
        # Normalize
        if len(embedding) != self.embedding_dim:
            if len(embedding) < self.embedding_dim:
                embedding = np.pad(embedding, (0, self.embedding_dim - len(embedding)))
            else:
                embedding = embedding[:self.embedding_dim]
        
        # Distance to nearest archived points
        distances = [np.linalg.norm(embedding - a) for a in self.archive]
        
        # Average of k nearest
        k = min(5, len(distances))
        k_nearest = sorted(distances)[:k]
        
        return np.mean(k_nearest)
    
    def compute_exploitation_value(self, embedding: np.ndarray) -> float:
        """Compute exploitation (intent-alignment) value."""
        return self.teleo_warp.compute_value_field(embedding)
    
    def compute_total_value(self, embedding: np.ndarray) -> float:
        """
        Compute total value using dual-field geometry.
        
        v_total = v_exploit + λ · v_explore
        """
        v_exploit = self.compute_exploitation_value(embedding)
        v_explore = self.compute_novelty(embedding)
        
        return v_exploit + self.lambda_explore * v_explore
    
    def warp(self, embedding: np.ndarray) -> np.ndarray:
        """
        Apply novelty-aware teleological warp.
        
        Pulls toward high value AND novel regions.
        """
        # Normalize
        if len(embedding) != self.embedding_dim:
            if len(embedding) < self.embedding_dim:
                embedding = np.pad(embedding, (0, self.embedding_dim - len(embedding)))
            else:
                embedding = embedding[:self.embedding_dim]
        
        # Teleological pull
        teleo_warped = self.teleo_warp.warp(embedding)
        
        # Novelty gradient (away from archive)
        if len(self.archive) > 0:
            nearest_idx = np.argmin([
                np.linalg.norm(embedding - a) for a in self.archive
            ])
            novelty_direction = embedding - self.archive[nearest_idx]
            novelty_direction /= np.linalg.norm(novelty_direction) + 1e-8
        else:
            novelty_direction = np.zeros(self.embedding_dim)
        
        # Combine with lambda weighting
        combined = (
            (1 - self.lambda_explore) * teleo_warped +
            self.lambda_explore * (embedding + 0.1 * novelty_direction)
        )
        
        # Normalize
        original_norm = np.linalg.norm(embedding)
        if original_norm > 1e-8:
            combined = combined * (original_norm / (np.linalg.norm(combined) + 1e-8))
        
        return combined
    
    def add_to_archive(self, embedding: np.ndarray):
        """Add embedding to novelty archive."""
        if len(embedding) != self.embedding_dim:
            if len(embedding) < self.embedding_dim:
                embedding = np.pad(embedding, (0, self.embedding_dim - len(embedding)))
            else:
                embedding = embedding[:self.embedding_dim]
        
        self.archive.append(embedding.copy())
        
        if len(self.archive) > self.archive_size:
            self.archive.pop(0)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'BeamContinuityFilter',
    'RegimeDescriptor',
    'TeleologicalNoveltyWarp',
    'TeleologicalWarp',
    'ZigzagRegimeSwitch',
]
