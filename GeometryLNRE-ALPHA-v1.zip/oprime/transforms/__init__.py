"""
Transforms Module - Novel OPrime Transforms
============================================

Emergent transforms from the synthesis of CTS, IGVF, and SANS:

- T_teleo: Teleological Warp (intent-based embedding warping)
- Z_switch: Zigzag-Regime Switch (TDA-triggered adapter switching)
- B_cont: Beam-Continuity Filter (lookahead invariant checking)
- T_novel: Teleological Novelty Warp (novelty-aligned exploration)
"""

from .teleological_warp import (
    TeleologicalWarp,
    RegimeDescriptor,
    ZigzagRegimeSwitch,
    BeamContinuityFilter,
    TeleologicalNoveltyWarp,
)

__all__ = [
    'TeleologicalWarp',
    'RegimeDescriptor',
    'ZigzagRegimeSwitch',
    'BeamContinuityFilter',
    'TeleologicalNoveltyWarp',
]
