"""
OPrime Core Modules
===================

The core components of the Configurational Term Series (CTS) pipeline:

    X →[f(x)]→ M →[v]→ M_v →[H_k]→ Q(Φ) →[Agency]→ C_t

Stages:
    1. Sensorimotor Interface (dynamics/)
    2. Manifold Abstraction (cts_pipeline.py)
    3. Value-Imposed Geometry (geometry/)
    4. Topological Form (topology/)
    5-6. Conscious State (consciousness/)
    7. Agency (agent/agency/)
"""

from .intent_alignment import (
    IntentContext,
    IntentConfiguration,
    IntentAlignedOperator,
    IntentPresets,
    parse_intent,
    compute_novelty_weights,
)

from .cts_pipeline import (
    PipelineConfig,
    PipelineState,
    CTSPipeline,
    create_pipeline,
)

__all__ = [
    # Intent Alignment
    'IntentContext',
    'IntentConfiguration',
    'IntentAlignedOperator', 
    'IntentPresets',
    'parse_intent',
    'compute_novelty_weights',
    # CTS Pipeline
    'PipelineConfig',
    'PipelineState',
    'CTSPipeline',
    'create_pipeline',
]
