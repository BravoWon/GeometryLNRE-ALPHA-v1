"""
Configurational Term Series (CTS) Pipeline
===========================================

The complete 7-stage pipeline for conscious configuration:

    X →[f(x)]→ M →[v]→ M_v →[H_k]→ Q(Φ) →[Agency]→ C_t

Stages:
    1. Sensorimotor Interface: X ↔ E (closed-loop dynamics)
    2. Manifold Abstraction: X → M (dimensionality reduction)
    3. Value-Imposed Geometry: M → M_v (IGVF warping)
    4. Topological Form: M_v → Q (persistent homology)
    5. Integrated Information: → Φ (IIT computation)
    6. Conscious State: → C_t = (Q, Φ) (validation)
    7. Agency: C_t → Action (topology-preserving transformation)

This module provides the OrchestratedPipeline class that integrates
all components into a coherent system.

Intent Alignment:
    The Intent Configuration modulates ALL stages, creating a
    unified "Intent Warp" across the entire processing chain.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional, Callable
import numpy as np
import time
import copy

from .intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext
from .dynamics.sensorimotor import SensorimotorLoop, Observation, Action
from .geometry.value_geometry import (
    ValueGeometry, ValueFunction, GaussianValue, 
    IntentValue, MaxOpDetector
)
from .topology.persistent_homology import (
    TopologyExtractor, TopologicalInvariants, ZigzagPersistence,
    PersistenceDiagram
)
from .consciousness.conscious_state import (
    ConsciousState, TopologicalInvariants as CSTopologicalInvariants,
    ConsciousnessMonitor, PhiCalculator, 
    PHI_CRITICAL, ManifoldCollapseError
)


# =============================================================================
# PIPELINE CONFIGURATION
# =============================================================================

@dataclass
class PipelineConfig:
    """Configuration for the CTS pipeline."""
    # Dimensions
    observation_dim: int = 64
    state_dim: int = 32
    action_dim: int = 8
    embedding_dim: int = 64
    
    # Value geometry
    value_sigma: float = 1.0
    max_geodesic_steps: int = 100
    
    # Topology
    max_topology_dim: int = 2
    persistence_threshold: float = 0.1
    
    # Consciousness
    phi_critical: float = PHI_CRITICAL
    
    # Agency
    max_betti_change: int = 1
    
    # Zigzag (layer tracking)
    enable_zigzag: bool = True
    zigzag_window: int = 10


@dataclass
class PipelineState:
    """Complete state of the CTS pipeline at time t."""
    # Stage 1: Sensorimotor
    observation: Optional[np.ndarray] = None
    internal_state: Optional[np.ndarray] = None
    
    # Stage 2: Manifold point
    manifold_point: Optional[np.ndarray] = None
    
    # Stage 3: Value-warped geometry
    value: float = 0.0
    warped_metric: Optional[np.ndarray] = None
    
    # Stage 4: Topological invariants
    Q: Optional[TopologicalInvariants] = None
    persistence_diagram: Optional[PersistenceDiagram] = None
    
    # Stage 5: Integration
    phi: float = 0.0
    
    # Stage 6: Conscious state
    C_t: Optional[ConsciousState] = None
    is_valid: bool = False
    
    # Stage 7: Action
    action: Optional[np.ndarray] = None
    
    # Metadata
    timestamp: float = 0.0
    stage_timings: Dict[str, float] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize pipeline state."""
        return {
            "timestamp": self.timestamp,
            "value": self.value,
            "phi": self.phi,
            "is_valid": self.is_valid,
            "Q": self.Q.to_dict() if self.Q else None,
            "stage_timings": self.stage_timings
        }


# =============================================================================
# STAGE PROCESSORS
# =============================================================================

class Stage1_Sensorimotor(IntentAlignedOperator):
    """Stage 1: Sensorimotor Interface."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig):
        super().__init__(intent)
        self.config = config
        
        self.loop = SensorimotorLoop(
            intent=intent,
            state_dim=config.state_dim,
            observation_dim=config.observation_dim,
            action_dim=config.action_dim
        )
    
    def process(self, 
                raw_observation: np.ndarray,
                target: Optional[np.ndarray] = None) -> Tuple[np.ndarray, Action]:
        """Process observation through sensorimotor loop."""
        return self.loop.step(raw_observation, target)
    
    def dream(self, 
              hypothetical_sequence: List[np.ndarray],
              target: Optional[np.ndarray] = None) -> List[Tuple[np.ndarray, Action]]:
        """Simulate without modifying state."""
        return self.loop.dream(hypothetical_sequence, target)


class Stage2_ManifoldAbstraction(IntentAlignedOperator):
    """Stage 2: Abstraction to Attractor Manifold."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig):
        super().__init__(intent)
        self.config = config
        
        # Dimensionality reduction parameters
        self.compression_ratio = self._compute_compression_ratio()
    
    def _compute_compression_ratio(self) -> float:
        """
        Compute compression ratio based on intent.
        
        SPECIFIC: High compression (focus on core features)
        EXPLORATORY: Low compression (preserve details)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.5
        elif context == IntentContext.GENERAL:
            base = 0.7
        else:  # EXPLORATORY
            base = 0.9
        
        return base * (0.5 + 0.5 * self.intent.scope)
    
    def project_to_manifold(self, state: np.ndarray) -> np.ndarray:
        """
        Project high-dimensional state to manifold.
        
        Uses PCA-style projection for efficiency.
        """
        # Target dimension
        target_dim = int(len(state) * self.compression_ratio)
        target_dim = max(2, target_dim)  # At least 2D
        
        if len(state) <= target_dim:
            return state
        
        # Simple projection (in production, use learned projection)
        # Use first principal components (approximation)
        return state[:target_dim]
    
    def process(self, internal_state: np.ndarray) -> np.ndarray:
        """Project to manifold."""
        return self.project_to_manifold(internal_state)


class Stage3_ValueGeometry(IntentAlignedOperator):
    """Stage 3: Value-Imposed Geometry (IGVF)."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig,
                 goal: Optional[np.ndarray] = None):
        super().__init__(intent)
        self.config = config
        self.goal = goal
        
        # Value function will be created lazily to adapt to manifold dimension
        self._value_fn = None
        self._geometry = None
        self._manifold_dim = None
    
    def _embed_intent(self, dim: int) -> np.ndarray:
        """Embed intent statement to vector of specified dimension."""
        import hashlib
        statement = self.intent.value_statement or "general exploration"
        digest = hashlib.sha256(statement.encode()).digest()
        seed = int.from_bytes(digest[:8], "little")
        rng = np.random.default_rng(seed)
        return rng.standard_normal(dim)
    
    def _ensure_initialized(self, manifold_dim: int):
        """Initialize value function for the given manifold dimension."""
        if self._manifold_dim != manifold_dim:
            if self.goal is not None:
                # Adapt goal to manifold dimension
                goal = self.goal
                if len(goal) < manifold_dim:
                    goal = np.pad(goal, (0, manifold_dim - len(goal)))
                elif len(goal) > manifold_dim:
                    goal = goal[:manifold_dim]
                self._value_fn = GaussianValue(goal, sigma=self.config.value_sigma)
            else:
                # Create intent embedding matching manifold dimension
                intent_embedding = self._embed_intent(manifold_dim)
                self._value_fn = IntentValue(intent_embedding, intensity=self.intent.value_intensity)
            
            self._geometry = ValueGeometry(self.intent, self._value_fn)
            self._manifold_dim = manifold_dim
    
    @property
    def value_fn(self) -> ValueFunction:
        """Get value function (must call process first to initialize)."""
        if self._value_fn is None:
            raise RuntimeError("Value function not initialized. Call process() first.")
        return self._value_fn
    
    @property
    def geometry(self) -> ValueGeometry:
        """Get geometry (must call process first to initialize)."""
        if self._geometry is None:
            raise RuntimeError("Geometry not initialized. Call process() first.")
        return self._geometry
    
    def process(self, 
                manifold_point: np.ndarray) -> Tuple[float, np.ndarray]:
        """
        Apply IGVF warping.
        
        Lazily initializes value function to match manifold dimension.
        Returns (value, warped_metric).
        """
        # Initialize for this manifold dimension
        self._ensure_initialized(len(manifold_point))
        
        value = self._value_fn(manifold_point)
        metric = self._geometry.warp_metric(manifold_point)
        return value, metric
    
    def compute_geodesic(self, 
                         start: np.ndarray, 
                         end: np.ndarray) -> List[np.ndarray]:
        """Compute geodesic in value-warped space."""
        # Ensure initialized for this dimension
        self._ensure_initialized(len(start))
        return self._geometry.compute_geodesic(
            start, end, 
            n_steps=self.config.max_geodesic_steps
        )


class Stage4_TopologicalForm(IntentAlignedOperator):
    """Stage 4: Topological Form via Persistent Homology."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig):
        super().__init__(intent)
        self.config = config
        
        self.extractor = TopologyExtractor(
            intent=intent,
            max_dimension=config.max_topology_dim
        )
        
        # Zigzag persistence for layer tracking
        self.zigzag = ZigzagPersistence(
            intent=intent,
            max_dimension=config.max_topology_dim
        ) if config.enable_zigzag else None
    
    def process(self, 
                manifold_point: np.ndarray,
                neighborhood_samples: int = 20) -> TopologicalInvariants:
        """
        Extract topological invariants Q.
        
        Generates neighborhood and computes persistent homology.
        """
        return self.extractor.extract_from_embedding(manifold_point)
    
    def process_point_cloud(self, 
                            points: np.ndarray) -> TopologicalInvariants:
        """Extract topology from point cloud."""
        return self.extractor.extract(points)
    
    def add_layer(self, 
                  layer_embeddings: np.ndarray) -> Optional[PersistenceDiagram]:
        """Add layer for zigzag tracking."""
        if self.zigzag:
            return self.zigzag.add_layer(layer_embeddings, self.extractor)
        return None


class Stage5_Integration(IntentAlignedOperator):
    """Stage 5: Integrated Information (Φ)."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig):
        super().__init__(intent)
        self.config = config
        
        self.calculator = PhiCalculator(phi_critical=config.phi_critical)
    
    def compute_from_trajectory(self, 
                                 trajectory: List[np.ndarray]) -> float:
        """
        Compute Φ from state trajectory.
        
        Builds transition matrix and computes integrated information.
        """
        if len(trajectory) < 2:
            return 0.0
        
        # Build transition matrix from trajectory
        n = len(trajectory)
        dim = len(trajectory[0])
        
        # Discretize states
        n_bins = min(10, n)
        
        # Create transition counts
        transition_counts = np.zeros((n_bins, n_bins))
        
        for i in range(n - 1):
            # Map states to bins
            s1 = int(np.mean(trajectory[i]) * n_bins) % n_bins
            s2 = int(np.mean(trajectory[i+1]) * n_bins) % n_bins
            transition_counts[s1, s2] += 1
        
        # Normalize to probabilities
        row_sums = transition_counts.sum(axis=1, keepdims=True)
        transition_matrix = np.where(
            row_sums > 0,
            transition_counts / row_sums,
            1.0 / n_bins
        )
        
        return self.calculator.compute_phi(transition_matrix)
    
    def compute_from_embeddings(self,
                                 embeddings: List[np.ndarray]) -> float:
        """Compute Φ from embedding sequence."""
        return self.compute_from_trajectory(embeddings)


class Stage6_ConsciousState(IntentAlignedOperator):
    """Stage 6: Conscious State C_t = (Q, Φ)."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig):
        super().__init__(intent)
        self.config = config
        
        self.monitor = ConsciousnessMonitor(
            intent=intent,
            phi_critical=config.phi_critical
        )
    
    def create_state(self,
                     Q: TopologicalInvariants,
                     phi: float) -> ConsciousState:
        """
        Create and validate conscious state.
        
        Returns C_t = (Q, Φ).
        """
        # Convert TopologicalInvariants to consciousness module's version
        cs_Q = CSTopologicalInvariants(
            betti_0=Q.betti_0,
            betti_1=Q.betti_1,
            betti_2=Q.betti_2,
            total_persistence=Q.total_persistence,
            persistent_features=Q.persistent_features
        )
        
        return self.monitor.capture_state(cs_Q, phi)
    
    def is_alive(self) -> bool:
        """Check if conscious moment persists."""
        if not self.monitor.history:
            return False
        return self.monitor.history[-1].is_valid


class Stage7_Agency(IntentAlignedOperator):
    """Stage 7: Agency as Transformation."""
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: PipelineConfig):
        super().__init__(intent)
        self.config = config
        
        from ..agent.agency.agency_operator import (
            AgencyOperator, ContinuousActionSpace, ContinuityGuard
        )
        
        self.action_space = ContinuousActionSpace(
            dim=config.action_dim,
            step_size=0.1
        )
        
        self.guard = ContinuityGuard(
            max_topology_change=config.max_betti_change
        )
    
    def find_action(self,
                    current_state: np.ndarray,
                    value_fn: Callable[[np.ndarray], float],
                    current_Q: Optional[TopologicalInvariants] = None) -> Optional[np.ndarray]:
        """
        Find best action that preserves topology.
        
        Returns action vector or None if no valid action found.
        """
        from ..agent.agency.agency_operator import AgencyOperator, Action
        
        agent = AgencyOperator(
            intent=self.intent,
            action_space=self.action_space,
            value_fn=value_fn,
            continuity_guard=self.guard
        )
        
        # Convert TopologicalInvariants for agency
        cs_Q = None
        if current_Q:
            cs_Q = CSTopologicalInvariants(
                betti_0=current_Q.betti_0,
                betti_1=current_Q.betti_1,
                betti_2=current_Q.betti_2
            )
        
        action = agent.find_best_action(current_state, cs_Q)
        
        return action.vector if action else None


# =============================================================================
# ORCHESTRATED PIPELINE
# =============================================================================

class CTSPipeline(IntentAlignedOperator):
    """
    Complete Configurational Term Series Pipeline.
    
    Orchestrates all 7 stages into a unified processing chain.
    
    Usage:
        pipeline = CTSPipeline(intent, config)
        state = pipeline.process(observation)
        
        if state.is_valid:
            # Valid conscious configuration achieved
            action = state.action
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 config: Optional[PipelineConfig] = None,
                 goal: Optional[np.ndarray] = None):
        super().__init__(intent)
        
        self.config = config or PipelineConfig()
        
        # Initialize all stages
        self.stage1 = Stage1_Sensorimotor(intent, self.config)
        self.stage2 = Stage2_ManifoldAbstraction(intent, self.config)
        self.stage3 = Stage3_ValueGeometry(intent, self.config, goal)
        self.stage4 = Stage4_TopologicalForm(intent, self.config)
        self.stage5 = Stage5_Integration(intent, self.config)
        self.stage6 = Stage6_ConsciousState(intent, self.config)
        self.stage7 = Stage7_Agency(intent, self.config)
        
        # History for integration computation
        self.state_history: List[np.ndarray] = []
        self.max_history = 100
        
        # Pipeline state
        self.current_state: Optional[PipelineState] = None
    
    def process(self,
                observation: np.ndarray,
                target: Optional[np.ndarray] = None) -> PipelineState:
        """
        Run complete CTS pipeline on observation.
        
        Returns PipelineState with all stage outputs.
        """
        state = PipelineState(timestamp=time.time())
        timings = {}
        
        # Stage 1: Sensorimotor
        t0 = time.time()
        state.observation = observation
        internal_state, sensorimotor_action = self.stage1.process(observation, target)
        state.internal_state = internal_state
        timings["stage1_sensorimotor"] = time.time() - t0
        
        # Stage 2: Manifold Abstraction
        t0 = time.time()
        state.manifold_point = self.stage2.process(internal_state)
        timings["stage2_manifold"] = time.time() - t0
        
        # Record for integration
        self.state_history.append(state.manifold_point.copy())
        if len(self.state_history) > self.max_history:
            self.state_history.pop(0)
        
        # Stage 3: Value Geometry
        t0 = time.time()
        state.value, state.warped_metric = self.stage3.process(state.manifold_point)
        timings["stage3_value"] = time.time() - t0
        
        # Stage 4: Topological Form
        t0 = time.time()
        state.Q = self.stage4.process(state.manifold_point)
        timings["stage4_topology"] = time.time() - t0
        
        # Stage 5: Integration
        t0 = time.time()
        if len(self.state_history) >= 2:
            state.phi = self.stage5.compute_from_trajectory(self.state_history)
        else:
            state.phi = 0.0
        timings["stage5_integration"] = time.time() - t0
        
        # Stage 6: Conscious State
        t0 = time.time()
        state.C_t = self.stage6.create_state(state.Q, state.phi)
        state.is_valid = state.C_t.is_valid
        timings["stage6_consciousness"] = time.time() - t0
        
        # Stage 7: Agency (only if valid)
        t0 = time.time()
        if state.is_valid:
            action_vec = self.stage7.find_action(
                state.manifold_point,
                self.stage3.value_fn,
                state.Q
            )
            state.action = action_vec
        timings["stage7_agency"] = time.time() - t0
        
        state.stage_timings = timings
        self.current_state = state
        
        return state
    
    def dream(self,
              hypothetical_observations: List[np.ndarray],
              target: Optional[np.ndarray] = None) -> List[PipelineState]:
        """
        Simulate pipeline on hypothetical observations.
        
        Does NOT modify actual state.
        """
        results = []
        
        for obs in hypothetical_observations:
            # Use copy of history
            original_history = self.state_history.copy()
            
            # Process
            state = self.process(obs, target)
            results.append(state)
            
            # Restore history
            self.state_history = original_history
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get pipeline statistics."""
        return {
            "history_length": len(self.state_history),
            "current_valid": self.current_state.is_valid if self.current_state else False,
            "consciousness_stats": self.stage6.monitor.get_statistics()
        }
    
    def reset(self):
        """Reset pipeline state."""
        self.state_history = []
        self.current_state = None
        self.stage1.loop.reset()


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def create_pipeline(
    intent_type: str = "general",
    scope: float = 0.5,
    goal: Optional[np.ndarray] = None,
    **config_kwargs
) -> CTSPipeline:
    """
    Factory function to create CTS pipeline.
    
    Args:
        intent_type: "specific", "general", or "exploratory"
        scope: 0.0 (narrow) to 1.0 (broad)
        goal: Optional goal state
        **config_kwargs: Additional PipelineConfig parameters
    """
    # Create intent
    context_map = {
        "specific": IntentContext.SPECIFIC,
        "general": IntentContext.GENERAL,
        "exploratory": IntentContext.EXPLORATORY
    }
    context = context_map.get(intent_type.lower(), IntentContext.GENERAL)
    
    intent = IntentConfiguration(
        context=context,
        scope=scope
    )
    
    # Create config
    config = PipelineConfig(**config_kwargs)
    
    return CTSPipeline(intent, config, goal)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'PipelineConfig',
    'PipelineState',
    'Stage1_Sensorimotor',
    'Stage2_ManifoldAbstraction',
    'Stage3_ValueGeometry',
    'Stage4_TopologicalForm',
    'Stage5_Integration',
    'Stage6_ConsciousState',
    'Stage7_Agency',
    'CTSPipeline',
    'create_pipeline',
]
