"""
Intent Alignment Framework
==========================

The core module that maps the two dimensions of intent (Context × Scope)
to system behavior across all OPrime components.

Mathematical Foundation:
    Intent is a 2D manifold parameterized by:
    - Context: {specific, general, exploratory} — categorical
    - Scope: [0.0, 1.0] — continuous (narrow → broad)
    
    The Intent Alignment Matrix defines how these dimensions modulate:
    - Value geometry (IGVF warping intensity)
    - Novelty weights (exploration vs exploitation)
    - Topological constraints (non-triviality thresholds)
    - Agency freedom (action space filtering)
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Callable, Any, Tuple, Optional
import numpy as np


class IntentContext(Enum):
    """
    The Context dimension of intent.
    
    SPECIFIC: Narrow, well-defined goal (e.g., "solve this equation")
        - High semantic novelty weight
        - Tight value function focus
        - Strict topology preservation
    
    GENERAL: Broad conceptual goal (e.g., "explore mathematical structures")
        - High topological novelty weight
        - Diffuse value function
        - Flexible topology evolution
    
    EXPLORATORY: Pure discovery mode (e.g., "find something interesting")
        - Balanced novelty weights
        - Minimal value bias
        - Maximum agency freedom
    """
    SPECIFIC = "specific"
    GENERAL = "general"
    EXPLORATORY = "exploratory"


@dataclass
class IntentConfiguration:
    """
    Complete intent specification for OPrime operation.
    
    The Intent Configuration is the mathematical embodiment of user purpose.
    It warps all downstream computations.
    """
    context: IntentContext
    scope: float  # 0.0 (narrow) to 1.0 (broad)
    
    # Optional refinements
    value_statement: str = ""  # Natural language intent
    priority_keywords: list = field(default_factory=list)
    exclusion_keywords: list = field(default_factory=list)
    
    # Computed properties (set by align())
    _novelty_weights: Dict[str, float] = field(default_factory=dict)
    _value_intensity: float = 1.0
    _topology_threshold: float = 0.5
    _agency_freedom: float = 0.5
    
    def __post_init__(self):
        self.scope = max(0.0, min(1.0, self.scope))  # Clamp to [0, 1]
        self.align()
    
    def align(self):
        """
        Compute all derived parameters from context and scope.
        
        This is THE core alignment operation.
        """
        self._novelty_weights = compute_novelty_weights(
            self.context.value, 
            self.scope
        )
        self._value_intensity = compute_value_intensity(
            self.context, 
            self.scope
        )
        self._topology_threshold = compute_topology_threshold(
            self.context, 
            self.scope
        )
        self._agency_freedom = compute_agency_freedom(
            self.context, 
            self.scope
        )
    
    @property
    def novelty_weights(self) -> Dict[str, float]:
        """Weights for behavioral, topological, semantic novelty."""
        return self._novelty_weights
    
    @property
    def value_intensity(self) -> float:
        """How strongly the value function warps the manifold."""
        return self._value_intensity
    
    @property
    def topology_threshold(self) -> float:
        """Minimum persistence for topological features."""
        return self._topology_threshold
    
    @property
    def agency_freedom(self) -> float:
        """How much action space filtering is applied."""
        return self._agency_freedom
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize for logging/storage."""
        return {
            "context": self.context.value,
            "scope": self.scope,
            "value_statement": self.value_statement,
            "novelty_weights": self._novelty_weights,
            "value_intensity": self._value_intensity,
            "topology_threshold": self._topology_threshold,
            "agency_freedom": self._agency_freedom
        }


# =============================================================================
# ALIGNMENT FUNCTIONS
# =============================================================================

def compute_novelty_weights(context: str, scope: float) -> Dict[str, float]:
    """
    Map intent dimensions to novelty dimension weights.
    
    The Intent Alignment Matrix:
    
                        SCOPE
                Narrow (0.0) ──────► Broad (1.0)
                    │                     │
    CONTEXT         │                     │
    ───────         │                     │
    SPECIFIC   N_S dominates ────► N_T increases
                    │                     │
    GENERAL    N_T moderate  ────► N_T dominates
                    │                     │
    EXPLORATORY  All balanced ────► N_B + N_T high
    
    Returns:
        Normalized weights summing to 1.0
    """
    weights = {
        "behavioral": 0.3,  # N_B: Always present as baseline anti-repetition
        "topological": 0.0,  # N_T: Structural novelty
        "semantic": 0.0      # N_S: Intent-aligned discovery
    }
    
    if context == "specific":
        # Specific intent: semantic novelty helps refine understanding
        # Narrow scope = high semantic, broad scope = more topological
        weights["semantic"] = 0.5 * (1 - scope)
        weights["topological"] = 0.2 * scope
        
    elif context == "general":
        # General intent: topological novelty discovers new structures
        # Scope increases topological weight
        weights["topological"] = 0.5 * scope
        weights["semantic"] = 0.2 * (1 - scope)
        
    elif context == "exploratory":
        # Exploratory: maximize diversity, all dimensions active
        weights["behavioral"] = 0.4
        weights["topological"] = 0.4
        weights["semantic"] = 0.2
    
    # Normalize to sum = 1.0
    total = sum(weights.values())
    return {k: v / total for k, v in weights.items()}


def compute_value_intensity(context: IntentContext, scope: float) -> float:
    """
    Compute how strongly the value function warps the manifold.
    
    In the IGVF framework: g_v = v^α · g, where α is the intensity.
    
    - SPECIFIC + Narrow: High intensity (strong focus on goal)
    - EXPLORATORY + Broad: Low intensity (minimal value bias)
    """
    base_intensity = {
        IntentContext.SPECIFIC: 2.0,
        IntentContext.GENERAL: 1.0,
        IntentContext.EXPLORATORY: 0.5
    }[context]
    
    # Scope modulates: narrow = higher, broad = lower
    scope_modifier = 1.5 - scope  # 1.5 at narrow, 0.5 at broad
    
    return base_intensity * scope_modifier


def compute_topology_threshold(context: IntentContext, scope: float) -> float:
    """
    Compute minimum persistence for topological features to be considered.
    
    Higher threshold = only robust features count
    Lower threshold = more features considered (including transient ones)
    
    - SPECIFIC: High threshold (only stable structures matter)
    - EXPLORATORY: Low threshold (capture fleeting patterns)
    """
    base_threshold = {
        IntentContext.SPECIFIC: 0.7,
        IntentContext.GENERAL: 0.5,
        IntentContext.EXPLORATORY: 0.3
    }[context]
    
    # Narrow scope = higher threshold, broad = lower
    scope_modifier = 0.2 * (1 - scope)  # +0.2 at narrow, 0 at broad
    
    return min(0.9, base_threshold + scope_modifier)


def compute_agency_freedom(context: IntentContext, scope: float) -> float:
    """
    Compute how much action space filtering is applied.
    
    High freedom = more actions allowed (less filtering)
    Low freedom = stricter action constraints
    
    - SPECIFIC + Narrow: Low freedom (constrained to goal-relevant actions)
    - EXPLORATORY + Broad: High freedom (most actions allowed)
    """
    base_freedom = {
        IntentContext.SPECIFIC: 0.3,
        IntentContext.GENERAL: 0.6,
        IntentContext.EXPLORATORY: 0.9
    }[context]
    
    # Broad scope increases freedom
    scope_modifier = 0.3 * scope
    
    return min(1.0, base_freedom + scope_modifier)


# =============================================================================
# INTENT-ALIGNED OPERATORS
# =============================================================================

class IntentAlignedOperator:
    """
    Base class for operators that adapt behavior based on intent.
    
    All OPrime components should inherit from this to respect intent alignment.
    """
    
    def __init__(self, intent: IntentConfiguration):
        self.intent = intent
    
    def align_value_function(self, base_value_fn: Callable) -> Callable:
        """
        Wrap a value function with intent-based intensity modulation.
        
        v_aligned(x) = base_v(x)^intensity
        """
        intensity = self.intent.value_intensity
        
        def aligned_v(x):
            base_v = base_value_fn(x)
            # Apply intensity as exponent (warps the gradient)
            return np.power(np.abs(base_v) + 1e-8, intensity) * np.sign(base_v)
        
        return aligned_v
    
    def align_novelty_scoring(self, 
                               n_behavioral: float,
                               n_topological: float,
                               n_semantic: float) -> float:
        """
        Compute weighted novelty score based on intent alignment.
        """
        w = self.intent.novelty_weights
        return (
            w["behavioral"] * n_behavioral +
            w["topological"] * n_topological +
            w["semantic"] * n_semantic
        )
    
    def filter_actions_by_intent(self, 
                                  actions: list,
                                  action_scores: Dict[Any, float]) -> list:
        """
        Filter action space based on agency freedom.
        
        Low freedom = keep only high-scoring actions
        High freedom = keep most actions
        """
        freedom = self.intent.agency_freedom
        
        if freedom >= 0.9:
            return actions  # Maximum freedom: no filtering
        
        # Sort by score, keep top fraction based on freedom
        sorted_actions = sorted(
            actions, 
            key=lambda a: action_scores.get(a, 0), 
            reverse=True
        )
        
        n_keep = max(1, int(len(sorted_actions) * freedom))
        return sorted_actions[:n_keep]
    
    def should_preserve_topology(self, 
                                  Q_current: Any, 
                                  Q_proposed: Any) -> bool:
        """
        Check if topological change is acceptable given intent.
        
        SPECIFIC intent: Strict preservation (small changes only)
        EXPLORATORY intent: Flexible (larger changes allowed)
        """
        # Placeholder: actual implementation depends on topology representation
        # Returns True if change is within acceptable bounds
        freedom = self.intent.agency_freedom
        
        # Higher freedom = more topological change allowed
        max_betti_change = int(1 + freedom * 3)  # 1-4 based on freedom
        
        # Actual comparison would go here
        return True  # Placeholder


# =============================================================================
# INTENT CONFIGURATION PRESETS
# =============================================================================

class IntentPresets:
    """
    Common intent configurations for quick initialization.
    """
    
    @staticmethod
    def focused_goal(goal_statement: str) -> IntentConfiguration:
        """For solving a specific, well-defined problem."""
        return IntentConfiguration(
            context=IntentContext.SPECIFIC,
            scope=0.2,
            value_statement=goal_statement
        )
    
    @staticmethod
    def conceptual_exploration(domain: str) -> IntentConfiguration:
        """For exploring a conceptual domain broadly."""
        return IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.7,
            value_statement=f"Explore the structure of {domain}"
        )
    
    @staticmethod
    def pure_discovery() -> IntentConfiguration:
        """For maximum novelty-seeking behavior."""
        return IntentConfiguration(
            context=IntentContext.EXPLORATORY,
            scope=1.0,
            value_statement="Discover novel structures and patterns"
        )
    
    @staticmethod
    def balanced_research(topic: str) -> IntentConfiguration:
        """For research balancing depth and breadth."""
        return IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5,
            value_statement=f"Research {topic} comprehensively"
        )
    
    @staticmethod
    def creative_synthesis(elements: list) -> IntentConfiguration:
        """For creatively combining diverse elements."""
        return IntentConfiguration(
            context=IntentContext.EXPLORATORY,
            scope=0.6,
            value_statement=f"Synthesize connections between: {', '.join(elements)}"
        )


# =============================================================================
# INTENT PARSER (Natural Language → Configuration)
# =============================================================================

def parse_intent(natural_language: str) -> IntentConfiguration:
    """
    Parse natural language intent into IntentConfiguration.
    
    Heuristics:
    - Words like "find", "solve", "compute" → SPECIFIC
    - Words like "explore", "understand", "learn" → GENERAL
    - Words like "discover", "create", "invent" → EXPLORATORY
    - Qualifiers like "deeply", "focused" → narrow scope
    - Qualifiers like "broadly", "widely" → broad scope
    """
    text = natural_language.lower()
    
    # Context detection
    specific_keywords = ["solve", "find", "compute", "calculate", "determine", "fix"]
    general_keywords = ["explore", "understand", "learn", "study", "analyze", "research"]
    exploratory_keywords = ["discover", "create", "invent", "generate", "imagine", "novel"]
    
    context = IntentContext.GENERAL  # Default
    
    for kw in specific_keywords:
        if kw in text:
            context = IntentContext.SPECIFIC
            break
    
    for kw in exploratory_keywords:
        if kw in text:
            context = IntentContext.EXPLORATORY
            break
    
    for kw in general_keywords:
        if kw in text and context != IntentContext.EXPLORATORY:
            context = IntentContext.GENERAL
            break
    
    # Scope detection
    narrow_keywords = ["deeply", "focused", "specific", "precisely", "exactly", "narrow"]
    broad_keywords = ["broadly", "widely", "comprehensive", "extensive", "all", "any"]
    
    scope = 0.5  # Default: balanced
    
    for kw in narrow_keywords:
        if kw in text:
            scope = max(0.1, scope - 0.2)
    
    for kw in broad_keywords:
        if kw in text:
            scope = min(0.9, scope + 0.2)
    
    return IntentConfiguration(
        context=context,
        scope=scope,
        value_statement=natural_language
    )


# =============================================================================
# INTENT-AWARE MANIFOLD WARPING
# =============================================================================

def warp_manifold_by_intent(
    base_metric: np.ndarray,
    value_function: Callable[[np.ndarray], float],
    intent: IntentConfiguration,
    point: np.ndarray
) -> np.ndarray:
    """
    Apply IGVF warping modulated by intent.
    
    g_v = v^α · g
    
    Where α is determined by intent intensity.
    """
    v = value_function(point)
    intensity = intent.value_intensity
    
    # Apply warping with intent-modulated intensity
    warp_factor = np.power(np.abs(v) + 1e-8, intensity)
    
    return warp_factor * base_metric


def compute_geodesic_with_intent(
    start: np.ndarray,
    end: np.ndarray,
    manifold: Any,
    intent: IntentConfiguration,
    n_steps: int = 100
) -> list:
    """
    Compute geodesic path with intent-aligned exploration.
    
    Adds exploration noise proportional to agency freedom.
    """
    path = [start.copy()]
    current = start.copy()
    
    freedom = intent.agency_freedom
    exploration_noise = 0.1 * freedom  # Higher freedom = more exploration
    
    for step in range(n_steps):
        # Direction to goal
        direction = end - current
        direction_norm = np.linalg.norm(direction)
        
        if direction_norm < 0.01:
            break
        
        # Normalize
        direction = direction / direction_norm
        
        # Add intent-aligned exploration noise
        if freedom > 0.3:
            noise = np.random.randn(*direction.shape) * exploration_noise
            direction = direction + noise
            direction = direction / np.linalg.norm(direction)
        
        # Step
        step_size = 0.01 * (1 + freedom)  # Larger steps with more freedom
        current = current + step_size * direction
        path.append(current.copy())
    
    return path


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'IntentContext',
    'IntentConfiguration',
    'IntentAlignedOperator',
    'IntentPresets',
    'parse_intent',
    'compute_novelty_weights',
    'compute_value_intensity',
    'compute_topology_threshold',
    'compute_agency_freedom',
    'warp_manifold_by_intent',
    'compute_geodesic_with_intent',
]
