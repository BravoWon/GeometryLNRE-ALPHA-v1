"""
Universal Tensor Indexing (UTI)
===============================

Cross-domain signal mapping framework based on the Universal Tensor Space.
From the knowledge library (Mathematical Foundations of Universal Tensor Index):

    T = P × T × M × F

Where:
    - P (Pattern): Spatial/structural patterns
    - T (Time): Temporal dynamics
    - M (Magnitude): Intensity/amplitude
    - F (Frequency): Spectral characteristics

This framework enables:
    1. Cross-domain signal integration
    2. Multi-modal feature alignment
    3. Temporal-spectral analysis
    4. Pattern-magnitude correlation

The Universal Tensor provides a unified representation for signals from
diverse domains (sensor data, neural activations, market data, etc.)
enabling domain-agnostic processing and analysis.

Architecture:
    ┌─────────────────────────────────────────────────────────────────┐
    │              UNIVERSAL TENSOR SPACE T = P × T × M × F           │
    ├─────────────────────────────────────────────────────────────────┤
    │  Pattern (P)   │ Spatial structure, shape, topology            │
    │  Time (T)      │ Temporal evolution, dynamics, sequences       │
    │  Magnitude (M) │ Intensity, amplitude, energy                  │
    │  Frequency (F) │ Spectral content, harmonics, bandwidth        │
    └─────────────────────────────────────────────────────────────────┘

Intent Alignment:
    - SPECIFIC: Focus on primary domain (e.g., time for forecasting)
    - GENERAL: Balance all domains equally
    - EXPLORATORY: Emphasize cross-domain correlations
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple, Callable, Union
from enum import Enum
import numpy as np
from abc import ABC, abstractmethod

from ..intent_alignment import (
    IntentConfiguration,
    IntentAlignedOperator,
    IntentContext,
)


class TensorDomain(Enum):
    """The four domains of the Universal Tensor Space."""
    PATTERN = "pattern"      # P: Spatial/structural
    TIME = "time"           # T: Temporal
    MAGNITUDE = "magnitude"  # M: Intensity
    FREQUENCY = "frequency"  # F: Spectral


@dataclass
class DomainProjection:
    """
    A projection of data into one domain of the Universal Tensor Space.
    """
    domain: TensorDomain
    data: np.ndarray
    resolution: int
    bounds: Tuple[float, float]
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def shape(self) -> Tuple[int, ...]:
        return self.data.shape
    
    def normalize(self) -> 'DomainProjection':
        """Return normalized copy."""
        min_val = np.min(self.data)
        max_val = np.max(self.data)
        range_val = max_val - min_val
        
        if range_val > 1e-10:
            normalized_data = (self.data - min_val) / range_val
        else:
            normalized_data = np.zeros_like(self.data)
        
        return DomainProjection(
            domain=self.domain,
            data=normalized_data,
            resolution=self.resolution,
            bounds=(0.0, 1.0),
            metadata={**self.metadata, "normalized": True}
        )


@dataclass
class UniversalTensor:
    """
    Universal Tensor representation in T = P × T × M × F space.
    
    This is the core data structure for cross-domain signal mapping.
    Each signal is represented as projections across all four domains.
    """
    tensor_id: str
    
    # Domain projections
    pattern: Optional[DomainProjection] = None
    time: Optional[DomainProjection] = None
    magnitude: Optional[DomainProjection] = None
    frequency: Optional[DomainProjection] = None
    
    # Metadata
    source_domain: str = "unknown"
    timestamp: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_projection(self, domain: TensorDomain) -> Optional[DomainProjection]:
        """Get projection for a specific domain."""
        mapping = {
            TensorDomain.PATTERN: self.pattern,
            TensorDomain.TIME: self.time,
            TensorDomain.MAGNITUDE: self.magnitude,
            TensorDomain.FREQUENCY: self.frequency,
        }
        return mapping.get(domain)
    
    def set_projection(self, projection: DomainProjection):
        """Set projection for a domain."""
        if projection.domain == TensorDomain.PATTERN:
            self.pattern = projection
        elif projection.domain == TensorDomain.TIME:
            self.time = projection
        elif projection.domain == TensorDomain.MAGNITUDE:
            self.magnitude = projection
        elif projection.domain == TensorDomain.FREQUENCY:
            self.frequency = projection
    
    @property
    def domains_populated(self) -> List[TensorDomain]:
        """List of domains that have data."""
        populated = []
        if self.pattern is not None:
            populated.append(TensorDomain.PATTERN)
        if self.time is not None:
            populated.append(TensorDomain.TIME)
        if self.magnitude is not None:
            populated.append(TensorDomain.MAGNITUDE)
        if self.frequency is not None:
            populated.append(TensorDomain.FREQUENCY)
        return populated
    
    @property
    def completeness(self) -> float:
        """Fraction of domains populated."""
        return len(self.domains_populated) / 4.0
    
    def to_flat_vector(self, 
                       domains: Optional[List[TensorDomain]] = None,
                       normalize: bool = True) -> np.ndarray:
        """
        Flatten all domain projections into a single vector.
        
        Useful for downstream ML processing.
        """
        if domains is None:
            domains = self.domains_populated
        
        vectors = []
        for domain in domains:
            proj = self.get_projection(domain)
            if proj is not None:
                if normalize:
                    proj = proj.normalize()
                vectors.append(proj.data.flatten())
        
        if not vectors:
            return np.array([])
        
        return np.concatenate(vectors)
    
    def compute_cross_correlation(self,
                                   domain1: TensorDomain,
                                   domain2: TensorDomain) -> float:
        """
        Compute correlation between two domain projections.
        
        This reveals cross-domain structure in the data.
        """
        proj1 = self.get_projection(domain1)
        proj2 = self.get_projection(domain2)
        
        if proj1 is None or proj2 is None:
            return 0.0
        
        # Normalize both
        v1 = proj1.normalize().data.flatten()
        v2 = proj2.normalize().data.flatten()
        
        # Align lengths
        min_len = min(len(v1), len(v2))
        v1 = v1[:min_len]
        v2 = v2[:min_len]
        
        # Pearson correlation
        if len(v1) < 2:
            return 0.0
        
        return float(np.corrcoef(v1, v2)[0, 1])


class DomainProjector(ABC):
    """Abstract base class for domain-specific projectors."""
    
    @abstractmethod
    def project(self, 
                data: np.ndarray,
                resolution: int = 64) -> DomainProjection:
        """Project data into this domain."""
        pass


class PatternProjector(DomainProjector):
    """
    Projects data into Pattern (P) domain.
    
    Extracts spatial/structural features:
    - Shape descriptors
    - Topological features
    - Connectivity patterns
    """
    
    def __init__(self, method: str = "histogram"):
        self.method = method
    
    def project(self, 
                data: np.ndarray, 
                resolution: int = 64) -> DomainProjection:
        """Project data to pattern domain."""
        flat_data = data.flatten()
        
        if self.method == "histogram":
            # Histogram of values
            hist, bin_edges = np.histogram(flat_data, bins=resolution)
            pattern_data = hist.astype(float)
            bounds = (float(bin_edges[0]), float(bin_edges[-1]))
        elif self.method == "gradient":
            # Gradient distribution
            if len(flat_data) > 1:
                gradients = np.diff(flat_data)
                hist, bin_edges = np.histogram(gradients, bins=resolution)
                pattern_data = hist.astype(float)
                bounds = (float(bin_edges[0]), float(bin_edges[-1]))
            else:
                pattern_data = np.zeros(resolution)
                bounds = (0.0, 1.0)
        else:
            # Default: direct resampling
            pattern_data = np.interp(
                np.linspace(0, len(flat_data), resolution),
                np.arange(len(flat_data)),
                flat_data
            )
            bounds = (float(np.min(flat_data)), float(np.max(flat_data)))
        
        return DomainProjection(
            domain=TensorDomain.PATTERN,
            data=pattern_data,
            resolution=resolution,
            bounds=bounds,
            metadata={"method": self.method}
        )


class TimeProjector(DomainProjector):
    """
    Projects data into Time (T) domain.
    
    Extracts temporal features:
    - Trend
    - Seasonality
    - Change points
    """
    
    def __init__(self, window_size: int = 10):
        self.window_size = window_size
    
    def project(self, 
                data: np.ndarray, 
                resolution: int = 64) -> DomainProjection:
        """Project data to time domain."""
        flat_data = data.flatten()
        
        # Resample to resolution
        if len(flat_data) >= resolution:
            indices = np.linspace(0, len(flat_data) - 1, resolution).astype(int)
            time_data = flat_data[indices]
        else:
            time_data = np.interp(
                np.linspace(0, len(flat_data) - 1, resolution),
                np.arange(len(flat_data)),
                flat_data
            )
        
        bounds = (0.0, float(len(flat_data) - 1))
        
        return DomainProjection(
            domain=TensorDomain.TIME,
            data=time_data,
            resolution=resolution,
            bounds=bounds,
            metadata={"original_length": len(flat_data)}
        )


class MagnitudeProjector(DomainProjector):
    """
    Projects data into Magnitude (M) domain.
    
    Extracts intensity/amplitude features:
    - Distribution statistics
    - Peak analysis
    - Energy levels
    """
    
    def project(self, 
                data: np.ndarray, 
                resolution: int = 64) -> DomainProjection:
        """Project data to magnitude domain."""
        flat_data = data.flatten()
        
        # Sorted magnitudes (CDF-like)
        sorted_data = np.sort(np.abs(flat_data))
        
        # Resample to resolution
        indices = np.linspace(0, len(sorted_data) - 1, resolution).astype(int)
        mag_data = sorted_data[indices]
        
        bounds = (float(np.min(np.abs(flat_data))), 
                  float(np.max(np.abs(flat_data))))
        
        return DomainProjection(
            domain=TensorDomain.MAGNITUDE,
            data=mag_data,
            resolution=resolution,
            bounds=bounds,
            metadata={
                "mean": float(np.mean(flat_data)),
                "std": float(np.std(flat_data)),
                "max": float(np.max(np.abs(flat_data)))
            }
        )


class FrequencyProjector(DomainProjector):
    """
    Projects data into Frequency (F) domain.
    
    Extracts spectral features:
    - Power spectrum
    - Dominant frequencies
    - Bandwidth
    """
    
    def project(self, 
                data: np.ndarray, 
                resolution: int = 64) -> DomainProjection:
        """Project data to frequency domain via FFT."""
        flat_data = data.flatten()
        
        # Compute FFT
        fft_result = np.fft.fft(flat_data)
        power_spectrum = np.abs(fft_result[:len(fft_result)//2])
        
        # Resample to resolution
        if len(power_spectrum) >= resolution:
            indices = np.linspace(0, len(power_spectrum) - 1, resolution).astype(int)
            freq_data = power_spectrum[indices]
        else:
            freq_data = np.interp(
                np.linspace(0, len(power_spectrum) - 1, resolution),
                np.arange(len(power_spectrum)),
                power_spectrum
            )
        
        # Frequency bounds (normalized)
        bounds = (0.0, 0.5)  # Nyquist
        
        return DomainProjection(
            domain=TensorDomain.FREQUENCY,
            data=freq_data,
            resolution=resolution,
            bounds=bounds,
            metadata={
                "dominant_freq_idx": int(np.argmax(power_spectrum)),
                "total_power": float(np.sum(power_spectrum))
            }
        )


class UniversalTensorIndexer(IntentAlignedOperator):
    """
    Universal Tensor Indexer: Main interface for cross-domain signal mapping.
    
    Provides:
        - Signal-to-tensor conversion
        - Cross-domain analysis
        - Multi-modal feature extraction
        - Domain correlation analysis
    
    Usage:
        indexer = UniversalTensorIndexer(intent)
        
        # Index a signal
        tensor = indexer.index(signal_data, source_domain="sensor")
        
        # Analyze cross-domain correlations
        correlations = indexer.analyze_correlations(tensor)
        
        # Extract unified features
        features = indexer.extract_features(tensor)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 resolution: int = 64):
        super().__init__(intent)
        
        self.resolution = resolution
        
        # Initialize projectors
        self.projectors: Dict[TensorDomain, DomainProjector] = {
            TensorDomain.PATTERN: PatternProjector(),
            TensorDomain.TIME: TimeProjector(),
            TensorDomain.MAGNITUDE: MagnitudeProjector(),
            TensorDomain.FREQUENCY: FrequencyProjector(),
        }
        
        # Domain weights based on intent
        self.domain_weights = self._compute_domain_weights()
        
        # Statistics
        self.tensors_indexed = 0
    
    def _compute_domain_weights(self) -> Dict[TensorDomain, float]:
        """Compute domain weights based on intent."""
        if self.intent.context == IntentContext.SPECIFIC:
            # Focus on time and magnitude (typical for focused analysis)
            return {
                TensorDomain.PATTERN: 0.15,
                TensorDomain.TIME: 0.4,
                TensorDomain.MAGNITUDE: 0.3,
                TensorDomain.FREQUENCY: 0.15,
            }
        elif self.intent.context == IntentContext.GENERAL:
            # Balanced weights
            return {
                TensorDomain.PATTERN: 0.25,
                TensorDomain.TIME: 0.25,
                TensorDomain.MAGNITUDE: 0.25,
                TensorDomain.FREQUENCY: 0.25,
            }
        else:  # EXPLORATORY
            # Emphasize pattern and frequency (discovery mode)
            return {
                TensorDomain.PATTERN: 0.35,
                TensorDomain.TIME: 0.15,
                TensorDomain.MAGNITUDE: 0.15,
                TensorDomain.FREQUENCY: 0.35,
            }
    
    def index(self,
              data: np.ndarray,
              source_domain: str = "unknown",
              tensor_id: Optional[str] = None,
              domains: Optional[List[TensorDomain]] = None
              ) -> UniversalTensor:
        """
        Index a signal into the Universal Tensor Space.
        
        Projects the data across all (or specified) domains.
        """
        self.tensors_indexed += 1
        
        if tensor_id is None:
            tensor_id = f"ut_{self.tensors_indexed}_{hash(data.tobytes()) % 10000}"
        
        tensor = UniversalTensor(
            tensor_id=tensor_id,
            source_domain=source_domain,
            timestamp=float(self.tensors_indexed)
        )
        
        # Project to all domains (or specified subset)
        target_domains = domains or list(TensorDomain)
        
        for domain in target_domains:
            projector = self.projectors[domain]
            projection = projector.project(data, self.resolution)
            tensor.set_projection(projection)
        
        return tensor
    
    def analyze_correlations(self,
                              tensor: UniversalTensor
                              ) -> Dict[str, float]:
        """
        Analyze cross-domain correlations in a tensor.
        
        Reveals how domains co-vary, useful for identifying
        multi-modal patterns.
        """
        correlations = {}
        
        domains = tensor.domains_populated
        for i, d1 in enumerate(domains):
            for d2 in domains[i+1:]:
                key = f"{d1.value}_x_{d2.value}"
                corr = tensor.compute_cross_correlation(d1, d2)
                correlations[key] = corr
        
        return correlations
    
    def extract_features(self,
                          tensor: UniversalTensor,
                          normalize: bool = True
                          ) -> np.ndarray:
        """
        Extract unified feature vector from tensor.
        
        Weights domains according to intent alignment.
        """
        features = []
        
        for domain, weight in self.domain_weights.items():
            proj = tensor.get_projection(domain)
            if proj is not None:
                if normalize:
                    proj = proj.normalize()
                weighted = weight * proj.data.flatten()
                features.append(weighted)
        
        if not features:
            return np.array([])
        
        return np.concatenate(features)
    
    def compute_similarity(self,
                            tensor1: UniversalTensor,
                            tensor2: UniversalTensor,
                            domains: Optional[List[TensorDomain]] = None
                            ) -> float:
        """
        Compute similarity between two tensors.
        
        Uses weighted cosine similarity across domains.
        """
        if domains is None:
            domains = list(TensorDomain)
        
        similarities = []
        weights = []
        
        for domain in domains:
            proj1 = tensor1.get_projection(domain)
            proj2 = tensor2.get_projection(domain)
            
            if proj1 is not None and proj2 is not None:
                v1 = proj1.normalize().data.flatten()
                v2 = proj2.normalize().data.flatten()
                
                # Align lengths
                min_len = min(len(v1), len(v2))
                v1 = v1[:min_len]
                v2 = v2[:min_len]
                
                # Cosine similarity
                norm1 = np.linalg.norm(v1)
                norm2 = np.linalg.norm(v2)
                
                if norm1 > 1e-10 and norm2 > 1e-10:
                    sim = np.dot(v1, v2) / (norm1 * norm2)
                    similarities.append(sim)
                    weights.append(self.domain_weights.get(domain, 0.25))
        
        if not similarities:
            return 0.0
        
        # Weighted average
        total_weight = sum(weights)
        if total_weight < 1e-10:
            return np.mean(similarities)
        
        return sum(s * w for s, w in zip(similarities, weights)) / total_weight
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get indexer statistics."""
        return {
            "tensors_indexed": self.tensors_indexed,
            "resolution": self.resolution,
            "domain_weights": {d.value: w for d, w in self.domain_weights.items()}
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'TensorDomain',
    'DomainProjection',
    'UniversalTensor',
    'DomainProjector',
    'PatternProjector',
    'TimeProjector',
    'MagnitudeProjector',
    'FrequencyProjector',
    'UniversalTensorIndexer',
]
