"""
Universal Tensor Indexing (UTI)
===============================

Cross-domain signal mapping framework: T = P × T × M × F

Domains:
    - P (Pattern): Spatial/structural patterns
    - T (Time): Temporal dynamics  
    - M (Magnitude): Intensity/amplitude
    - F (Frequency): Spectral characteristics
"""

from .universal_tensor import (
    TensorDomain,
    DomainProjection,
    UniversalTensor,
    DomainProjector,
    PatternProjector,
    TimeProjector,
    MagnitudeProjector,
    FrequencyProjector,
    UniversalTensorIndexer,
)

__all__ = [
    'TensorDomain',
    'DomainProjection',
    'UniversalTensor',
    'DomainProjector',
    'PatternProjector',
    'TimeProjector',
    'MagnitudeProjector',
    'FrequencyProjector',
    'UniversalTensorIndexer',
]
