"""
Sensorimotor Interface (Stage 1 of CTS)
=======================================

The closed-loop dynamical system connecting internal state X with environment E.

    Sensing: s: E → O (observations from environment)
    Actuation: a: X → A (actions on environment)
    
Critical constraint: Conceptual separation between internal update F_x
and actuation map a — allows "dreaming" (simulation) before acting.

Intent Alignment:
    - SPECIFIC: Tight sensing focus, minimal exploration
    - GENERAL: Balanced sensing across domains
    - EXPLORATORY: Wide sensing, active probing
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple
from abc import ABC, abstractmethod
import numpy as np

from ..intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# ENVIRONMENT INTERFACE
# =============================================================================

@dataclass
class Observation:
    """Observation from environment."""
    data: np.ndarray
    timestamp: float
    source: str = "environment"
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Action:
    """Action to execute on environment."""
    vector: np.ndarray
    name: str = "default"
    parameters: Dict[str, Any] = field(default_factory=dict)


class Environment(ABC):
    """Abstract environment interface."""
    
    @abstractmethod
    def observe(self) -> Observation:
        """Get current observation."""
        pass
    
    @abstractmethod
    def act(self, action: Action) -> Tuple[Observation, float]:
        """Execute action, return (next_obs, reward)."""
        pass
    
    @abstractmethod
    def reset(self) -> Observation:
        """Reset environment."""
        pass


class SimulatedEnvironment(Environment):
    """
    Simulated environment for "dreaming" / lookahead.
    
    Allows testing actions before committing.
    """
    
    def __init__(self, state_dim: int, dynamics_fn: Optional[Callable] = None):
        self.state_dim = state_dim
        self.state = np.zeros(state_dim)
        self.dynamics = dynamics_fn or self._default_dynamics
        self.t = 0.0
    
    def _default_dynamics(self, state: np.ndarray, action: np.ndarray) -> np.ndarray:
        """Default linear dynamics with noise."""
        return state + 0.1 * action + 0.01 * np.random.randn(len(state))
    
    def observe(self) -> Observation:
        return Observation(
            data=self.state.copy(),
            timestamp=self.t,
            source="simulated"
        )
    
    def act(self, action: Action) -> Tuple[Observation, float]:
        self.state = self.dynamics(self.state, action.vector)
        self.t += 1.0
        reward = -np.linalg.norm(self.state)  # Reward for being near origin
        return self.observe(), reward
    
    def reset(self) -> Observation:
        self.state = np.random.randn(self.state_dim) * 0.1
        self.t = 0.0
        return self.observe()
    
    def set_state(self, state: np.ndarray):
        """Set state for simulation."""
        self.state = state.copy()


# =============================================================================
# SENSING MAP (s: E → O)
# =============================================================================

class SensingMap(IntentAlignedOperator):
    """
    Sensing map: transforms raw environment data to observations.
    
    Intent Alignment:
        - SPECIFIC: Focused sensing, filters irrelevant channels
        - GENERAL: Balanced multi-channel sensing
        - EXPLORATORY: Wide-band sensing, includes noise channels
    """
    
    def __init__(self, 
                 intent: IntentConfiguration,
                 input_dim: int,
                 output_dim: int):
        super().__init__(intent)
        
        self.input_dim = input_dim
        self.output_dim = output_dim
        
        # Intent-aligned sensing parameters
        self.focus_mask = self._compute_focus_mask()
        self.noise_sensitivity = self._compute_noise_sensitivity()
    
    def _compute_focus_mask(self) -> np.ndarray:
        """
        Compute attention mask based on intent.
        
        SPECIFIC: Sharp focus on subset of inputs
        EXPLORATORY: Uniform attention
        """
        mask = np.ones(self.input_dim)
        context = self.intent.context
        
        if context == IntentContext.SPECIFIC:
            # Focus on first half (goal-relevant)
            focus_size = max(1, self.input_dim // 2)
            mask[focus_size:] = 0.1 * (1 - self.intent.scope)
        
        elif context == IntentContext.EXPLORATORY:
            # Uniform with scope-based broadening
            mask = np.ones(self.input_dim) * (0.5 + 0.5 * self.intent.scope)
        
        return mask / (mask.sum() + 1e-8)
    
    def _compute_noise_sensitivity(self) -> float:
        """
        Compute noise sensitivity based on intent.
        
        EXPLORATORY: High sensitivity (picks up weak signals)
        SPECIFIC: Low sensitivity (filters noise)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.1
        elif context == IntentContext.GENERAL:
            base = 0.5
        else:  # EXPLORATORY
            base = 0.9
        
        return base * (0.5 + 0.5 * self.intent.scope)
    
    def sense(self, raw_input: np.ndarray) -> Observation:
        """
        Transform raw input to observation.
        """
        # Pad/truncate
        if len(raw_input) < self.input_dim:
            raw_input = np.pad(raw_input, (0, self.input_dim - len(raw_input)))
        elif len(raw_input) > self.input_dim:
            raw_input = raw_input[:self.input_dim]
        
        # Apply focus mask
        focused = raw_input * self.focus_mask
        
        # Add noise based on sensitivity (for exploration)
        if self.noise_sensitivity > 0.5:
            noise = np.random.randn(len(focused)) * 0.1 * self.noise_sensitivity
            focused = focused + noise
        
        # Project to output dimension
        if self.output_dim != self.input_dim:
            # Simple projection
            if self.output_dim < self.input_dim:
                focused = focused[:self.output_dim]
            else:
                focused = np.pad(focused, (0, self.output_dim - self.input_dim))
        
        return Observation(
            data=focused,
            timestamp=0.0,
            metadata={
                "focus_applied": True,
                "noise_sensitivity": self.noise_sensitivity
            }
        )


# =============================================================================
# ACTUATION MAP (a: X → A)
# =============================================================================

class ActuationMap(IntentAlignedOperator):
    """
    Actuation map: transforms internal state to actions.
    
    Intent Alignment:
        - SPECIFIC: Precise, goal-directed actions
        - EXPLORATORY: Diverse, exploratory actions
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 state_dim: int,
                 action_dim: int):
        super().__init__(intent)
        
        self.state_dim = state_dim
        self.action_dim = action_dim
        
        # Intent-aligned actuation parameters
        self.precision = self._compute_precision()
        self.exploration_noise = self._compute_exploration_noise()
    
    def _compute_precision(self) -> float:
        """
        Compute action precision based on intent.
        
        SPECIFIC: High precision (small, accurate actions)
        EXPLORATORY: Low precision (larger, varied actions)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.9
        elif context == IntentContext.GENERAL:
            base = 0.5
        else:  # EXPLORATORY
            base = 0.2
        
        # Narrow scope = higher precision
        return base * (1.5 - self.intent.scope)
    
    def _compute_exploration_noise(self) -> float:
        """Compute exploration noise magnitude."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.01
        elif context == IntentContext.GENERAL:
            base = 0.1
        else:  # EXPLORATORY
            base = 0.3
        
        return base * (0.5 + self.intent.scope)
    
    def actuate(self, 
                internal_state: np.ndarray,
                target: Optional[np.ndarray] = None) -> Action:
        """
        Generate action from internal state.
        """
        # Pad/truncate state
        if len(internal_state) < self.state_dim:
            internal_state = np.pad(internal_state, (0, self.state_dim - len(internal_state)))
        elif len(internal_state) > self.state_dim:
            internal_state = internal_state[:self.state_dim]
        
        # Compute base action
        if target is not None:
            # Goal-directed action
            direction = target[:self.action_dim] - internal_state[:self.action_dim]
            base_action = direction * self.precision
        else:
            # State-based action
            base_action = internal_state[:self.action_dim] * 0.1
        
        # Add exploration noise
        if self.exploration_noise > 0:
            noise = np.random.randn(self.action_dim) * self.exploration_noise
            base_action = base_action + noise
        
        # Clip action magnitude
        max_magnitude = 1.0 / self.precision
        magnitude = np.linalg.norm(base_action)
        if magnitude > max_magnitude:
            base_action = base_action * (max_magnitude / magnitude)
        
        return Action(
            vector=base_action,
            name="actuated",
            parameters={
                "precision": self.precision,
                "exploration_noise": self.exploration_noise
            }
        )


# =============================================================================
# INTERNAL UPDATE FUNCTION (F_x)
# =============================================================================

class InternalDynamics(IntentAlignedOperator):
    """
    Internal update function F_x: X × O → X
    
    Updates internal state based on observations.
    
    Critical: This is SEPARATE from actuation, allowing
    the system to simulate/dream before acting.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 state_dim: int,
                 memory_horizon: int = 10):
        super().__init__(intent)
        
        self.state_dim = state_dim
        self.memory_horizon = memory_horizon
        
        # Internal state
        self.state = np.zeros(state_dim)
        self.observation_buffer: List[np.ndarray] = []
        
        # Intent-aligned parameters
        self.integration_rate = self._compute_integration_rate()
        self.memory_decay = self._compute_memory_decay()
    
    def _compute_integration_rate(self) -> float:
        """
        How quickly to integrate new observations.
        
        SPECIFIC: Slow integration (stable state)
        EXPLORATORY: Fast integration (responsive)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.1
        elif context == IntentContext.GENERAL:
            base = 0.3
        else:  # EXPLORATORY
            base = 0.5
        
        return base * (0.5 + 0.5 * self.intent.scope)
    
    def _compute_memory_decay(self) -> float:
        """
        How quickly old observations decay.
        
        SPECIFIC: Slow decay (long memory)
        EXPLORATORY: Fast decay (short memory)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.95
        elif context == IntentContext.GENERAL:
            base = 0.9
        else:  # EXPLORATORY
            base = 0.8
        
        return base
    
    def update(self, observation: Observation) -> np.ndarray:
        """
        Update internal state based on observation.
        
        Returns updated state.
        """
        obs = observation.data
        
        # Pad/truncate
        if len(obs) < self.state_dim:
            obs = np.pad(obs, (0, self.state_dim - len(obs)))
        elif len(obs) > self.state_dim:
            obs = obs[:self.state_dim]
        
        # Integrate observation
        self.state = (
            self.memory_decay * self.state + 
            self.integration_rate * obs
        )
        
        # Store in buffer
        self.observation_buffer.append(obs.copy())
        if len(self.observation_buffer) > self.memory_horizon:
            self.observation_buffer.pop(0)
        
        return self.state.copy()
    
    def get_state(self) -> np.ndarray:
        """Get current internal state."""
        return self.state.copy()
    
    def reset(self):
        """Reset internal state."""
        self.state = np.zeros(self.state_dim)
        self.observation_buffer = []
    
    def simulate(self, 
                 hypothetical_obs: Observation,
                 n_steps: int = 1) -> np.ndarray:
        """
        Simulate state update WITHOUT modifying actual state.
        
        This is the "dreaming" capability.
        """
        simulated_state = self.state.copy()
        obs = hypothetical_obs.data
        
        # Pad/truncate
        if len(obs) < self.state_dim:
            obs = np.pad(obs, (0, self.state_dim - len(obs)))
        elif len(obs) > self.state_dim:
            obs = obs[:self.state_dim]
        
        for _ in range(n_steps):
            simulated_state = (
                self.memory_decay * simulated_state + 
                self.integration_rate * obs
            )
        
        return simulated_state


# =============================================================================
# SENSORIMOTOR LOOP (Complete Stage 1)
# =============================================================================

class SensorimotorLoop(IntentAlignedOperator):
    """
    Complete Stage 1: Sensorimotor Interface.
    
    Integrates sensing, internal dynamics, and actuation
    into a closed-loop system with intent alignment.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 state_dim: int,
                 observation_dim: int,
                 action_dim: int):
        super().__init__(intent)
        
        self.state_dim = state_dim
        
        # Components
        self.sensing = SensingMap(intent, observation_dim, state_dim)
        self.dynamics = InternalDynamics(intent, state_dim)
        self.actuation = ActuationMap(intent, state_dim, action_dim)
        
        # Simulation environment for dreaming
        self.dream_env = SimulatedEnvironment(state_dim)
        
        # History
        self.trajectory: List[np.ndarray] = []
        self.action_history: List[Action] = []
    
    def step(self, 
             raw_observation: np.ndarray,
             target: Optional[np.ndarray] = None) -> Tuple[np.ndarray, Action]:
        """
        Execute one step of the sensorimotor loop.
        
        Returns (internal_state, action).
        """
        # Sense
        observation = self.sensing.sense(raw_observation)
        
        # Update internal state
        internal_state = self.dynamics.update(observation)
        
        # Generate action
        action = self.actuation.actuate(internal_state, target)
        
        # Record
        self.trajectory.append(internal_state.copy())
        self.action_history.append(action)
        
        return internal_state, action
    
    def dream(self,
              hypothetical_sequence: List[np.ndarray],
              target: Optional[np.ndarray] = None) -> List[Tuple[np.ndarray, Action]]:
        """
        Simulate (dream) through a sequence of hypothetical observations.
        
        Does NOT modify actual state.
        """
        results = []
        simulated_state = self.dynamics.get_state()
        
        for hyp_obs in hypothetical_sequence:
            # Simulate sensing
            obs = self.sensing.sense(hyp_obs)
            
            # Simulate dynamics
            simulated_state = (
                self.dynamics.memory_decay * simulated_state +
                self.dynamics.integration_rate * obs.data
            )
            
            # Simulate actuation
            action = self.actuation.actuate(simulated_state, target)
            
            results.append((simulated_state.copy(), action))
        
        return results
    
    def get_trajectory(self) -> np.ndarray:
        """Get trajectory as array."""
        if not self.trajectory:
            return np.array([])
        return np.array(self.trajectory)
    
    def reset(self):
        """Reset the loop."""
        self.dynamics.reset()
        self.trajectory = []
        self.action_history = []


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'Observation',
    'Action',
    'Environment',
    'SimulatedEnvironment',
    'SensingMap',
    'ActuationMap',
    'InternalDynamics',
    'SensorimotorLoop',
]
