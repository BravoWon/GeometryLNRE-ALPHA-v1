"""
Persistent Homology (Stage 4 of CTS)
====================================

Extracts robust topological invariants Q from the value-warped manifold M_v.

    M_v →[H_k]→ Q

Key concepts:
    - Betti numbers (β_0, β_1, β_2): Connected components, loops, voids
    - Persistence diagrams: Birth/death of features across filtration
    - Topological non-triviality constraint: Q must have rich structure

Intent Alignment:
    - SPECIFIC: High persistence threshold (only robust features)
    - EXPLORATORY: Low threshold (capture transient patterns)
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import numpy as np
from abc import ABC, abstractmethod

from ..intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# PERSISTENCE DIAGRAM
# =============================================================================

@dataclass
class PersistencePoint:
    """A point in a persistence diagram."""
    dimension: int  # Homology dimension (0, 1, 2, ...)
    birth: float    # Filtration value at birth
    death: float    # Filtration value at death (inf for essential)
    
    @property
    def persistence(self) -> float:
        """Lifetime of the feature."""
        if np.isinf(self.death):
            return float('inf')
        return self.death - self.birth
    
    @property
    def midlife(self) -> float:
        """Midpoint of lifetime."""
        if np.isinf(self.death):
            return self.birth + 1.0  # Arbitrary for essential
        return (self.birth + self.death) / 2
    
    def is_essential(self) -> bool:
        """Check if feature persists forever."""
        return np.isinf(self.death)


@dataclass
class PersistenceDiagram:
    """Complete persistence diagram across all dimensions."""
    points: List[PersistencePoint] = field(default_factory=list)
    
    def get_dimension(self, dim: int) -> List[PersistencePoint]:
        """Get points for specific dimension."""
        return [p for p in self.points if p.dimension == dim]
    
    def get_betti_number(self, dim: int, threshold: float = 0.0) -> int:
        """
        Compute Betti number at given persistence threshold.
        
        Only counts features with persistence > threshold.
        """
        return len([
            p for p in self.points 
            if p.dimension == dim and p.persistence > threshold
        ])
    
    def total_persistence(self, dim: Optional[int] = None) -> float:
        """Sum of all finite persistences."""
        points = self.points if dim is None else self.get_dimension(dim)
        return sum(
            p.persistence for p in points 
            if not np.isinf(p.persistence)
        )
    
    def bottleneck_distance(self, other: 'PersistenceDiagram') -> float:
        """
        Compute bottleneck distance to another diagram.
        
        Uses TDA library (persim, gudhi) if available, otherwise falls back
        to a heuristic based on Betti number differences.
        
        The bottleneck distance is the maximum over all dimensions of the
        infimum cost of matching points between diagrams.
        """
        # Try to use proper TDA library
        try:
            import persim
            # Convert to diagram format: list of (birth, death) tuples
            dgm1 = np.array([[p.birth, p.death] for p in self.points 
                            if not np.isinf(p.death)])
            dgm2 = np.array([[p.birth, p.death] for p in other.points 
                            if not np.isinf(p.death)])
            if len(dgm1) == 0:
                dgm1 = np.empty((0, 2))
            if len(dgm2) == 0:
                dgm2 = np.empty((0, 2))
            return persim.bottleneck(dgm1, dgm2)
        except ImportError:
            pass
        
        try:
            import gudhi
            dgm1 = [(p.birth, p.death) for p in self.points if not np.isinf(p.death)]
            dgm2 = [(p.birth, p.death) for p in other.points if not np.isinf(p.death)]
            return gudhi.bottleneck_distance(dgm1, dgm2)
        except ImportError:
            pass
        
        # Fallback: heuristic based on Betti numbers and total persistence
        max_diff = 0.0
        for dim in range(3):
            b1 = self.get_betti_number(dim)
            b2 = other.get_betti_number(dim)
            max_diff = max(max_diff, abs(b1 - b2))
        
        # Also consider persistence difference
        p1 = self.total_persistence()
        p2 = other.total_persistence()
        max_diff = max(max_diff, abs(p1 - p2) / max(p1, p2, 1.0))
        
        return float(max_diff)
    
    def wasserstein_distance(self, other: 'PersistenceDiagram', p: int = 1) -> float:
        """
        Compute Wasserstein distance to another diagram.
        
        Uses TDA library (persim, gudhi) if available, otherwise falls back
        to a heuristic based on Betti number differences.
        
        Args:
            other: Another persistence diagram
            p: Order of the Wasserstein distance (must be >= 1)
        
        Raises:
            ValueError: If p < 1
        """
        if p < 1:
            raise ValueError(f"Wasserstein order p must be >= 1, got {p}")
        
        # Try to use proper TDA library
        try:
            import persim
            dgm1 = np.array([[pt.birth, pt.death] for pt in self.points 
                            if not np.isinf(pt.death)])
            dgm2 = np.array([[pt.birth, pt.death] for pt in other.points 
                            if not np.isinf(pt.death)])
            if len(dgm1) == 0:
                dgm1 = np.empty((0, 2))
            if len(dgm2) == 0:
                dgm2 = np.empty((0, 2))
            return persim.wasserstein(dgm1, dgm2, order=p)
        except ImportError:
            pass
        
        try:
            import gudhi
            dgm1 = [(pt.birth, pt.death) for pt in self.points if not np.isinf(pt.death)]
            dgm2 = [(pt.birth, pt.death) for pt in other.points if not np.isinf(pt.death)]
            return gudhi.wasserstein_distance(dgm1, dgm2, order=p)
        except ImportError:
            pass
        
        # Fallback: L_p norm of Betti number and persistence differences
        diffs = []
        for dim in range(3):
            b1 = self.get_betti_number(dim)
            b2 = other.get_betti_number(dim)
            diffs.append(abs(b1 - b2) ** p)
        
        # Include persistence difference
        p1 = self.total_persistence()
        p2 = other.total_persistence()
        diffs.append(abs(p1 - p2) ** p)
        
        return float(sum(diffs) ** (1.0 / p))


# =============================================================================
# FILTRATION BUILDERS
# =============================================================================

class Filtration(ABC):
    """Abstract base for building filtrations."""
    
    @abstractmethod
    def build(self, points: np.ndarray) -> List[Tuple[float, np.ndarray]]:
        """
        Build filtration from point cloud.
        
        Returns list of (filtration_value, simplex_indices).
        """
        pass


class VietorisRipsFiltration(Filtration):
    """
    Vietoris-Rips filtration based on distance.
    
    Connects points within distance ε, varying ε.
    """
    
    def __init__(self, max_dimension: int = 2, max_epsilon: float = 2.0, n_steps: int = 20):
        self.max_dim = max_dimension
        self.max_eps = max_epsilon
        self.n_steps = n_steps
    
    def build(self, points: np.ndarray) -> List[Tuple[float, np.ndarray]]:
        """Build VR filtration."""
        n = len(points)
        
        # Compute distance matrix
        dist_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(i + 1, n):
                d = np.linalg.norm(points[i] - points[j])
                dist_matrix[i, j] = d
                dist_matrix[j, i] = d
        
        # Build simplices at each epsilon
        filtration = []
        epsilons = np.linspace(0, self.max_eps, self.n_steps)
        
        for eps in epsilons:
            # 0-simplices (vertices) appear at eps=0
            if eps == 0:
                for i in range(n):
                    filtration.append((0.0, np.array([i])))
            
            # 1-simplices (edges)
            for i in range(n):
                for j in range(i + 1, n):
                    if dist_matrix[i, j] <= eps:
                        filtration.append((dist_matrix[i, j], np.array([i, j])))
            
            # 2-simplices (triangles) - simplified
            if self.max_dim >= 2:
                for i in range(n):
                    for j in range(i + 1, n):
                        for k in range(j + 1, n):
                            max_d = max(
                                dist_matrix[i, j],
                                dist_matrix[j, k],
                                dist_matrix[i, k]
                            )
                            if max_d <= eps:
                                filtration.append((max_d, np.array([i, j, k])))
        
        # Remove duplicates and sort
        seen = set()
        unique_filtration = []
        for eps, simplex in sorted(filtration, key=lambda x: x[0]):
            key = tuple(sorted(simplex))
            if key not in seen:
                seen.add(key)
                unique_filtration.append((eps, simplex))
        
        return unique_filtration


class KNNFiltration(Filtration):
    """
    k-Nearest Neighbors filtration.
    
    Adapts to local density, better for high dimensions.
    """
    
    def __init__(self, k: int = 5, max_dimension: int = 2):
        self.k = k
        self.max_dim = max_dimension
    
    def build(self, points: np.ndarray) -> List[Tuple[float, np.ndarray]]:
        """Build k-NN filtration."""
        n = len(points)
        k = min(self.k, n - 1)
        
        # Compute k-NN distances
        dist_matrix = np.zeros((n, n))
        for i in range(n):
            for j in range(n):
                if i != j:
                    dist_matrix[i, j] = np.linalg.norm(points[i] - points[j])
        
        # k-NN radius for each point
        knn_radii = []
        for i in range(n):
            distances = sorted(dist_matrix[i, :])
            knn_radii.append(distances[k] if k < len(distances) else distances[-1])
        
        # Build filtration
        filtration = []
        
        # Vertices
        for i in range(n):
            filtration.append((0.0, np.array([i])))
        
        # Edges: connect if within k-NN radius
        for i in range(n):
            for j in range(i + 1, n):
                eps = max(knn_radii[i], knn_radii[j])
                if dist_matrix[i, j] <= eps:
                    filtration.append((dist_matrix[i, j], np.array([i, j])))
        
        return sorted(filtration, key=lambda x: x[0])


# =============================================================================
# HOMOLOGY COMPUTER
# =============================================================================

class HomologyComputer:
    """
    Computes persistent homology from filtration.
    
    Simplified implementation using matrix reduction.
    """
    
    def __init__(self, max_dimension: int = 2):
        self.max_dim = max_dimension
    
    def compute(self, filtration: List[Tuple[float, np.ndarray]]) -> PersistenceDiagram:
        """
        Compute persistence diagram from filtration.
        
        Simplified: heuristic-based for efficiency.
        """
        points = []
        
        # Count simplices by dimension
        dim_counts = {0: 0, 1: 0, 2: 0}
        births = {0: [], 1: [], 2: []}
        
        for eps, simplex in filtration:
            dim = len(simplex) - 1
            if dim <= self.max_dim:
                dim_counts[dim] = dim_counts.get(dim, 0) + 1
                births[dim].append(eps)
        
        # Generate persistence points heuristically
        # H_0: connected components
        n_components = dim_counts.get(0, 1)
        n_edges = dim_counts.get(1, 0)
        
        # All vertices are born, most die when edges connect them
        vertex_births = births.get(0, [])[:n_components]
        edge_births_list = births.get(1, [])
        
        for i, birth in enumerate(vertex_births):
            if i == 0:
                # One essential component
                points.append(PersistencePoint(0, birth, float('inf')))
            else:
                # Others die when merged
                if edge_births_list and i - 1 < len(edge_births_list):
                    death = edge_births_list[i - 1]
                else:
                    death = birth + 0.1
                points.append(PersistencePoint(0, birth, death))
        
        # H_1: loops
        n_triangles = dim_counts.get(2, 0)
        n_loops = max(0, n_edges - n_components + 1 - n_triangles)
        
        edge_births = births.get(1, [])
        triangle_births = births.get(2, [])
        
        for i in range(min(n_loops, len(edge_births))):
            birth = edge_births[i] if i < len(edge_births) else 0.0
            if i < len(triangle_births):
                death = triangle_births[i]
            else:
                death = birth + 0.5
            if death > birth:
                points.append(PersistencePoint(1, birth, death))
        
        # H_2: voids (simplified - rare in point clouds)
        if n_triangles >= 4:
            points.append(PersistencePoint(
                2, 
                triangle_births[0] if triangle_births else 0.0,
                float('inf')
            ))
        
        return PersistenceDiagram(points=points)


# =============================================================================
# TOPOLOGICAL INVARIANTS EXTRACTOR
# =============================================================================

@dataclass
class TopologicalInvariants:
    """Container for topological invariants (the Quale Q)."""
    betti_0: int = 1
    betti_1: int = 0
    betti_2: int = 0
    total_persistence: float = 0.0
    persistent_features: List[Tuple[int, float, float]] = field(default_factory=list)
    diagram: Optional[PersistenceDiagram] = None
    
    def is_non_trivial(self) -> bool:
        """
        Check if topology is non-trivial.
        
        NON-TRIVIALITY CONSTRAINT: Essential for valid conscious state.
        """
        return (
            self.betti_1 > 0 or 
            self.betti_2 > 0 or 
            self.betti_0 > 1 or
            len(self.persistent_features) >= 3
        )
    
    def complexity(self) -> float:
        """Compute topological complexity score."""
        return (
            1.0 * self.betti_0 +
            2.0 * self.betti_1 +
            3.0 * self.betti_2 +
            0.5 * len(self.persistent_features)
        )
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "betti_0": self.betti_0,
            "betti_1": self.betti_1,
            "betti_2": self.betti_2,
            "total_persistence": self.total_persistence,
            "n_persistent_features": len(self.persistent_features),
            "is_non_trivial": self.is_non_trivial(),
            "complexity": self.complexity()
        }


class TopologyExtractor(IntentAlignedOperator):
    """
    Stage 4: Extract topological invariants from manifold.
    
    Intent Alignment:
        - SPECIFIC: High persistence threshold (robust features only)
        - EXPLORATORY: Low threshold (all features)
        - Scope: Affects filtration scale
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 max_dimension: int = 2,
                 filtration_type: str = "vr"):
        super().__init__(intent)
        
        self.max_dim = max_dimension
        
        # Create filtration based on type
        if filtration_type == "knn":
            self.filtration = KNNFiltration(k=5, max_dimension=max_dimension)
        else:
            self.filtration = VietorisRipsFiltration(max_dimension=max_dimension)
        
        self.homology = HomologyComputer(max_dimension=max_dimension)
        
        # Intent-aligned threshold
        self.persistence_threshold = self._compute_threshold()
    
    def _compute_threshold(self) -> float:
        """
        Compute persistence threshold based on intent.
        
        SPECIFIC: High threshold (only robust)
        EXPLORATORY: Low threshold (all features)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.5
        elif context == IntentContext.GENERAL:
            base = 0.2
        else:  # EXPLORATORY
            base = 0.05
        
        # Narrow scope = higher threshold
        return base * (1.5 - self.intent.scope)
    
    def extract(self, 
                points: np.ndarray,
                sample_size: Optional[int] = None) -> TopologicalInvariants:
        """
        Extract topological invariants from point cloud.
        """
        # Subsample if needed
        if sample_size and len(points) > sample_size:
            indices = np.random.choice(len(points), sample_size, replace=False)
            points = points[indices]
        
        # Ensure 2D
        if points.ndim == 1:
            points = points.reshape(-1, 1)
        
        # Build filtration
        filtration = self.filtration.build(points)
        
        # Compute homology
        diagram = self.homology.compute(filtration)
        
        # Extract Betti numbers at threshold
        betti_0 = diagram.get_betti_number(0, self.persistence_threshold)
        betti_1 = diagram.get_betti_number(1, self.persistence_threshold)
        betti_2 = diagram.get_betti_number(2, self.persistence_threshold)
        
        # Ensure at least one connected component
        betti_0 = max(1, betti_0)
        
        # Extract persistent features above threshold
        persistent_features = [
            (p.dimension, p.birth, p.death)
            for p in diagram.points
            if p.persistence > self.persistence_threshold
        ]
        
        return TopologicalInvariants(
            betti_0=betti_0,
            betti_1=betti_1,
            betti_2=betti_2,
            total_persistence=diagram.total_persistence(),
            persistent_features=persistent_features,
            diagram=diagram
        )
    
    def extract_from_embedding(self, embedding: np.ndarray) -> TopologicalInvariants:
        """
        Extract topology from a single embedding vector.
        
        Generates synthetic point cloud around the embedding.
        """
        # Generate neighborhood
        n_samples = 20
        noise_scale = 0.1 * (0.5 + self.intent.scope)
        
        points = np.array([
            embedding + np.random.randn(len(embedding)) * noise_scale
            for _ in range(n_samples)
        ])
        
        return self.extract(points)


# =============================================================================
# ZIGZAG PERSISTENCE (Layer-as-Time)
# =============================================================================

class ZigzagPersistence(IntentAlignedOperator):
    """
    Zigzag persistence for tracking features across layers/time.
    
    Treats LLM layers (or time steps) as discrete time parameter.
    
    Filtration: K_1 ↔ K_2 ↔ ... ↔ K_n (bidirectional)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 max_dimension: int = 1):
        super().__init__(intent)
        self.max_dim = max_dimension
        self.layer_diagrams: List[PersistenceDiagram] = []
    
    def add_layer(self, 
                  layer_embeddings: np.ndarray,
                  extractor: TopologyExtractor) -> PersistenceDiagram:
        """
        Add a layer and compute its topology.
        """
        invariants = extractor.extract(layer_embeddings)
        self.layer_diagrams.append(invariants.diagram)
        return invariants.diagram
    
    def compute_feature_lifespan(self) -> Dict[str, List[int]]:
        """
        Track which features persist across layers.
        
        Returns: dict mapping feature type to layer indices where present.
        """
        lifespans = {
            "components": [],  # β_0
            "loops": [],       # β_1
            "voids": []        # β_2
        }
        
        for i, diag in enumerate(self.layer_diagrams):
            if diag is None:
                continue
                
            if diag.get_betti_number(0) > 1:
                lifespans["components"].append(i)
            if diag.get_betti_number(1) > 0:
                lifespans["loops"].append(i)
            if diag.get_betti_number(2) > 0:
                lifespans["voids"].append(i)
        
        return lifespans
    
    def detect_phase_transitions(self) -> List[int]:
        """
        Detect layers where topology changes significantly.
        
        These are Type II Phase Transitions in the layer sequence.
        """
        transitions = []
        
        for i in range(1, len(self.layer_diagrams)):
            prev = self.layer_diagrams[i - 1]
            curr = self.layer_diagrams[i]
            
            if prev is None or curr is None:
                continue
            
            # Compute bottleneck distance
            distance = prev.bottleneck_distance(curr)
            
            # High distance = phase transition
            if distance >= 1.0:
                transitions.append(i)
        
        return transitions
    
    def get_cognitive_phase(self, layer_idx: int) -> str:
        """
        Identify cognitive phase at given layer.
        
        Based on feature lifespan analysis:
        - Early: High rearrangement (short-lived features)
        - Middle: Stable concepts (long-lived features)
        - Late: Output collapse (feature reduction)
        """
        n_layers = len(self.layer_diagrams)
        
        if n_layers == 0:
            return "unknown"
        
        relative_pos = layer_idx / max(1, n_layers - 1)
        
        if relative_pos < 0.3:
            return "contextualization"
        elif relative_pos < 0.7:
            return "abstraction"
        else:
            return "actuation"
    
    def reset(self):
        """Reset layer diagrams."""
        self.layer_diagrams = []


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'PersistencePoint',
    'PersistenceDiagram',
    'Filtration',
    'VietorisRipsFiltration',
    'KNNFiltration',
    'HomologyComputer',
    'TopologicalInvariants',
    'TopologyExtractor',
    'ZigzagPersistence',
]
