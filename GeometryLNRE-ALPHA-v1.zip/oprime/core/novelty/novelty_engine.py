"""
Novelty Engine (N)
==================

The sixth core module of OPrime, providing exploration via optimization
pathways aligned with the dimensions of context and scope for intent.

Mathematical Foundation:
    Total Novelty Field: N_total = w_B·N_B + w_T·N_T + w_S·N_S
    
    Where weights w are determined by the Intent Alignment Matrix:
    - Context (specific/general/exploratory)
    - Scope (narrow/broad)

The Novelty Engine enables:
    1. Quality-Diversity optimization (MAP-Elites)
    2. Curiosity-driven exploration (intrinsic motivation)
    3. Information-geometric exploration (Fisher novelty)
"""

from dataclasses import dataclass, field
from collections import deque
from typing import Dict, List, Tuple, Callable, Any, Optional
import numpy as np
from abc import ABC, abstractmethod

# Import intent alignment
from ..intent_alignment import (
    IntentConfiguration, 
    IntentAlignedOperator,
    compute_novelty_weights
)


# =============================================================================
# NOVELTY DIMENSION 1: BEHAVIORAL NOVELTY (N_B)
# =============================================================================

class BehavioralNovelty:
    """
    N_B: Distance from archive of previously executed behaviors.
    
    Rewards doing things DIFFERENTLY, not just finding different answers.
    
    Scope Alignment:
        - Narrow scope: Small archive, local novelty
        - Broad scope: Large archive, global novelty
    """
    
    def __init__(self, 
                 archive_size: int = 1000, 
                 k_neighbors: int = 15,
                 scope: float = 0.5):
        # Scope modulates archive size
        adjusted_size = int(archive_size * (0.5 + scope))
        self.archive: deque = deque(maxlen=adjusted_size)
        self.k = k_neighbors
        self.scope = scope
    
    def compute(self, behavior: np.ndarray) -> float:
        """
        Compute behavioral novelty score.
        
        N_B(x) = (1/k) * Σ d(x, archive_i)
        
        Higher score = more novel behavior.
        """
        if len(self.archive) < self.k:
            return float('inf')  # Maximum novelty when archive is sparse
        
        # Compute distances to all archived behaviors
        distances = [
            np.linalg.norm(behavior - b) 
            for b in self.archive
        ]
        
        # Average distance to k nearest neighbors
        k_nearest = sorted(distances)[:self.k]
        return np.mean(k_nearest)
    
    def add_to_archive(self, behavior: np.ndarray):
        """Add behavior to archive."""
        self.archive.append(behavior.copy())
    
    def compute_gradient(self, behavior: np.ndarray) -> np.ndarray:
        """
        Compute gradient pointing AWAY from archive (toward novelty).
        
        This is the direction of maximum behavioral novelty increase.
        """
        if len(self.archive) < self.k:
            return np.zeros_like(behavior)
        
        # Find k nearest neighbors
        distances_with_idx = [
            (np.linalg.norm(behavior - b), i, b) 
            for i, b in enumerate(self.archive)
        ]
        k_nearest = sorted(distances_with_idx, key=lambda x: x[0])[:self.k]
        
        # Gradient: average direction away from neighbors
        gradient = np.zeros_like(behavior)
        for dist, _idx, neighbor in k_nearest:
            if dist > 1e-8:
                direction = (behavior - neighbor) / dist
                gradient += direction
        
        gradient /= self.k
        
        # Normalize
        norm = np.linalg.norm(gradient)
        if norm > 1e-8:
            gradient /= norm
        
        return gradient


# =============================================================================
# NOVELTY DIMENSION 2: TOPOLOGICAL NOVELTY (N_T)
# =============================================================================

@dataclass
class TopologicalInvariants:
    """Container for topological invariants (Betti numbers, etc.)"""
    betti_0: int = 1  # Connected components
    betti_1: int = 0  # Loops/holes
    betti_2: int = 0  # Voids
    total_persistence: float = 0.0
    persistent_features: List[Tuple[int, float, float]] = field(default_factory=list)


class TopologicalNovelty:
    """
    N_T: Detection of new homological features.
    
    Rewards discovering NEW SHAPES in the solution space.
    
    Context Alignment:
        - SPECIFIC: Expect particular topology, reward deviation
        - GENERAL: Reward any non-trivial structure
        - EXPLORATORY: Reward topological complexity
    """
    
    def __init__(self, 
                 expected_topology: Optional[Dict[int, int]] = None,
                 context: str = "general"):
        # Default expectation: single connected blob (trivial)
        self.expected = expected_topology or {0: 1, 1: 0, 2: 0}
        self.context = context
        
        # Weights by dimension (higher dim = more novel)
        self.weights = {0: 1.0, 1: 2.0, 2: 3.0}
    
    def compute(self, invariants: TopologicalInvariants) -> float:
        """
        Compute topological novelty score.
        
        N_T = Σ w_k · |β_k(observed) - β_k(expected)|
        """
        observed = {
            0: invariants.betti_0,
            1: invariants.betti_1,
            2: invariants.betti_2
        }
        
        novelty = 0.0
        for dim in [0, 1, 2]:
            expected = self.expected.get(dim, 0)
            actual = observed.get(dim, 0)
            novelty += self.weights[dim] * abs(actual - expected)
        
        # Bonus for persistent features (context-dependent)
        if self.context == "exploratory":
            novelty += 0.5 * len(invariants.persistent_features)
        
        return novelty
    
    def is_non_trivial(self, invariants: TopologicalInvariants) -> bool:
        """
        Check if topology is non-trivial (CRITICAL CONSTRAINT).
        
        Non-trivial = has loops OR voids OR multiple components.
        """
        return (
            invariants.betti_1 > 0 or 
            invariants.betti_2 > 0 or 
            invariants.betti_0 > 1
        )
    
    def update_expectation(self, invariants: TopologicalInvariants):
        """Update expected topology based on observations."""
        # Exponential moving average
        alpha = 0.1
        self.expected[0] = (1 - alpha) * self.expected[0] + alpha * invariants.betti_0
        self.expected[1] = (1 - alpha) * self.expected[1] + alpha * invariants.betti_1
        self.expected[2] = (1 - alpha) * self.expected[2] + alpha * invariants.betti_2


# =============================================================================
# NOVELTY DIMENSION 3: SEMANTIC NOVELTY (N_S)
# =============================================================================

class SemanticNovelty:
    """
    N_S: Information gain relative to current intent context.
    
    Rewards discoveries that MATTER for the stated intent.
    
    Scope Alignment:
        - Narrow scope: High likelihood near stated intent
        - Broad scope: Diffuse likelihood, more exploration
    """
    
    def __init__(self, 
                 intent_embedding: np.ndarray,
                 scope: float = 0.5):
        self.prior = intent_embedding.copy()
        self.scope = scope
        self.observation_history: List[np.ndarray] = []
    
    def compute(self, 
                observation_embedding: np.ndarray, 
                context: Dict[str, Any]) -> float:
        """
        Compute semantic novelty as KL divergence.
        
        N_S = D_KL(P(intent|observation) || P(intent))
        
        Measures how much the observation updates our understanding.
        """
        # Compute posterior (simplified: distance-based)
        posterior = self.compute_posterior(observation_embedding, context)
        
        # KL divergence (using simplified form)
        kl_div = self.kl_divergence(posterior, self.prior)
        
        return kl_div
    
    def compute_posterior(self, 
                          observation: np.ndarray, 
                          context: Dict[str, Any]) -> np.ndarray:
        """
        Update intent distribution based on observation.
        
        Uses scope to modulate likelihood sharpness.
        """
        # Likelihood: how consistent is observation with intent?
        scope = context.get("scope", self.scope)
        
        # Narrow scope = sharp likelihood (peaked near prior)
        # Broad scope = diffuse likelihood (flat)
        sharpness = 1.0 / (scope + 0.1)
        
        distance = np.linalg.norm(observation - self.prior)
        likelihood = np.exp(-sharpness * distance)
        
        # Posterior (simplified: weighted average)
        posterior = (1 - likelihood) * observation + likelihood * self.prior
        
        return posterior
    
    def kl_divergence(self, p: np.ndarray, q: np.ndarray) -> float:
        """
        Compute KL divergence between two distributions.
        
        Simplified: use squared distance in embedding space.
        """
        # Treat embeddings as means of Gaussians
        return 0.5 * np.sum((p - q) ** 2)
    
    def update_prior(self, observation: np.ndarray, learning_rate: float = 0.1):
        """Update prior based on significant observation."""
        self.prior = (1 - learning_rate) * self.prior + learning_rate * observation
        self.observation_history.append(observation.copy())


# =============================================================================
# CURIOSITY MODULE (Intrinsic Motivation)
# =============================================================================

class CuriosityModule:
    """
    Intrinsic motivation via prediction error.
    
    Curiosity = how surprising is this state?
    
    Uses Random Network Distillation (RND) principle:
    - Fixed random network (target)
    - Trainable predictor
    - Curiosity = prediction error
    """
    
    def __init__(self, state_dim: int, hidden_dim: int = 256):
        self.state_dim = state_dim
        self.hidden_dim = hidden_dim
        
        # Fixed random projection (target)
        np.random.seed(42)  # Reproducible
        self.target_weights = np.random.randn(state_dim, hidden_dim) * 0.1
        
        # Trainable predictor
        self.predictor_weights = np.random.randn(state_dim, hidden_dim) * 0.1
        
        # Training history
        self.visited_states: List[np.ndarray] = []
    
    def compute_curiosity(self, state: np.ndarray) -> float:
        """
        Compute curiosity score for a state.
        
        High curiosity = unfamiliar state = worth exploring.
        """
        # Target features (fixed)
        target_features = np.tanh(state @ self.target_weights)
        
        # Predicted features (trainable)
        predicted_features = np.tanh(state @ self.predictor_weights)
        
        # Curiosity = prediction error
        error = np.mean((target_features - predicted_features) ** 2)
        
        return error
    
    def update_predictor(self, states: List[np.ndarray], learning_rate: float = 0.01):
        """
        Train predictor on visited states.
        
        Reduces curiosity for known states.
        """
        for state in states:
            target = np.tanh(state @ self.target_weights)
            predicted = np.tanh(state @ self.predictor_weights)
            
            # Gradient descent on prediction error
            error = predicted - target
            gradient = np.outer(state, error * (1 - predicted ** 2))
            
            self.predictor_weights -= learning_rate * gradient
        
        self.visited_states.extend(states)


# =============================================================================
# FISHER NOVELTY EXPLORER (Information-Geometric)
# =============================================================================

class FisherNoveltyExplorer:
    """
    Information-geometric exploration using Fisher Information.
    
    Fisher Information Metric defines directions of maximum information gain.
    
    N_Fisher(x, δx) = δx^T · g_Fisher(x) · δx
    """
    
    def __init__(self, epsilon: float = 1e-4):
        self.epsilon = epsilon
    
    def compute_fisher_metric(self, 
                               point: np.ndarray, 
                               log_likelihood_fn: Callable) -> np.ndarray:
        """
        Estimate Fisher Information Matrix at a point.
        
        FIM_ij = E[∂log p/∂θ_i · ∂log p/∂θ_j]
        
        Uses finite differences.
        """
        dim = len(point)
        fim = np.zeros((dim, dim))
        
        for i in range(dim):
            for j in range(dim):
                fim[i, j] = self._fim_entry(point, i, j, log_likelihood_fn)
        
        return fim
    
    def _fim_entry(self, point: np.ndarray, i: int, j: int, 
                   log_likelihood_fn: Callable) -> float:
        """Compute single FIM entry via finite differences."""
        eps = self.epsilon
        
        # Points for finite difference
        p_pp = point.copy(); p_pp[i] += eps; p_pp[j] += eps
        p_pm = point.copy(); p_pm[i] += eps; p_pm[j] -= eps
        p_mp = point.copy(); p_mp[i] -= eps; p_mp[j] += eps
        p_mm = point.copy(); p_mm[i] -= eps; p_mm[j] -= eps
        
        # Second derivative of log-likelihood
        ll_pp = log_likelihood_fn(p_pp)
        ll_pm = log_likelihood_fn(p_pm)
        ll_mp = log_likelihood_fn(p_mp)
        ll_mm = log_likelihood_fn(p_mm)
        
        return -(ll_pp - ll_pm - ll_mp + ll_mm) / (4 * eps * eps)
    
    def find_high_information_direction(self, 
                                          point: np.ndarray,
                                          fim: np.ndarray) -> np.ndarray:
        """
        Find direction of maximum information gain.
        
        This is the eigenvector with largest eigenvalue.
        """
        eigenvalues, eigenvectors = np.linalg.eigh(fim)
        
        # Direction of maximum information
        max_idx = np.argmax(eigenvalues)
        return eigenvectors[:, max_idx]
    
    def explore_step(self, 
                     point: np.ndarray, 
                     fim: np.ndarray,
                     step_size: float = 0.1) -> np.ndarray:
        """Take a step in the direction of maximum information gain."""
        direction = self.find_high_information_direction(point, fim)
        return point + step_size * direction


# =============================================================================
# INTEGRATED NOVELTY ENGINE
# =============================================================================

class NoveltyEngine(IntentAlignedOperator):
    """
    The integrated Novelty Engine (N).
    
    Combines all three novelty dimensions with intent alignment
    to provide exploration via optimization pathways.
    
    Components:
        - N_B: Behavioral novelty (anti-repetition)
        - N_T: Topological novelty (structural discovery)
        - N_S: Semantic novelty (intent-aligned discovery)
        - Curiosity: Intrinsic motivation
        - Fisher: Information-geometric exploration
    """
    
    def __init__(self, 
                 intent: IntentConfiguration,
                 state_dim: int,
                 intent_embedding: Optional[np.ndarray] = None):
        super().__init__(intent)
        
        self.state_dim = state_dim
        
        # Initialize novelty dimensions
        self.behavioral = BehavioralNovelty(
            archive_size=1000,
            scope=intent.scope
        )
        
        self.topological = TopologicalNovelty(
            context=intent.context.value
        )
        
        # Intent embedding (default: random)
        if intent_embedding is None:
            intent_embedding = np.random.randn(state_dim)
        
        self.semantic = SemanticNovelty(
            intent_embedding=intent_embedding,
            scope=intent.scope
        )
        
        # Auxiliary modules
        self.curiosity = CuriosityModule(state_dim)
        self.fisher = FisherNoveltyExplorer()
        
        # Exploration-exploitation balance
        self.exploration_weight = 0.3  # λ in the dual-field equation
        self.t = 0  # Time step for annealing
        
        # Annealing parameters
        self.alpha_0 = 0.5  # Initial exploration
        self.alpha_min = 0.05  # Minimum exploration
        self.tau = 100  # Annealing time constant
    
    def compute_total_novelty(self,
                               _state: np.ndarray,
                               behavior: np.ndarray,
                               topology: TopologicalInvariants,
                               observation: np.ndarray) -> float:
        """
        Compute weighted novelty score across all dimensions.
        
        Uses intent alignment to weight dimensions.
        """
        # Get intent-aligned weights
        weights = self.intent.novelty_weights
        
        # Compute each novelty dimension
        n_behavioral = self.behavioral.compute(behavior)
        n_topological = self.topological.compute(topology)
        n_semantic = self.semantic.compute(
            observation, 
            {"scope": self.intent.scope}
        )
        
        # Normalize unbounded novelty scores
        n_behavioral = np.tanh(n_behavioral / 10)  # Normalize to [0, 1]
        n_topological = np.tanh(n_topological / 5)
        n_semantic = np.tanh(n_semantic / 5)
        
        # Weighted combination
        total = (
            weights["behavioral"] * n_behavioral +
            weights["topological"] * n_topological +
            weights["semantic"] * n_semantic
        )
        
        return total
    
    def compute_exploration_bonus(self, state: np.ndarray) -> float:
        """
        Compute intrinsic motivation bonus for search algorithms.
        
        Combines curiosity with information-theoretic value.
        """
        curiosity = self.curiosity.compute_curiosity(state)
        
        # Modulate by current exploration coefficient
        alpha = self.alpha()
        
        return alpha * curiosity
    
    def alpha(self) -> float:
        """
        Compute current exploration coefficient.
        
        Anneals from alpha_0 to alpha_min over time.
        """
        return self.alpha_0 * np.exp(-self.t / self.tau) + self.alpha_min
    
    def step(self):
        """Advance time step (call after each search iteration)."""
        self.t += 1
    
    def reset(self):
        """Reset for new search."""
        self.t = 0
    
    def suggest_exploration_direction(self, 
                                       current_state: np.ndarray) -> np.ndarray:
        """
        Suggest direction to explore based on all novelty signals.
        
        Combines:
        - Behavioral gradient (away from archive)
        - Information-theoretic direction (if available)
        """
        weights = self.intent.novelty_weights
        
        # Behavioral novelty gradient
        behavioral_dir = self.behavioral.compute_gradient(current_state)
        
        # Random exploration component (for robustness)
        random_dir = np.random.randn(len(current_state))
        random_dir /= np.linalg.norm(random_dir)
        
        # Combine with intent alignment
        combined = (
            weights["behavioral"] * behavioral_dir +
            weights["topological"] * random_dir * 0.5 +
            (1 - self.alpha()) * np.zeros_like(current_state)  # Reduce noise over time
        )
        
        # Normalize
        norm = np.linalg.norm(combined)
        if norm > 1e-8:
            combined /= norm
        
        return combined
    
    def update(self, 
               state: np.ndarray, 
               behavior: np.ndarray,
               topology: TopologicalInvariants,
               observation: np.ndarray):
        """
        Update all novelty components with new observation.
        """
        # Update behavioral archive
        self.behavioral.add_to_archive(behavior)
        
        # Update topological expectation
        self.topological.update_expectation(topology)
        
        # Update semantic prior (if significant novelty)
        n_semantic = self.semantic.compute(observation, {"scope": self.intent.scope})
        if n_semantic > 1.0:
            self.semantic.update_prior(observation)
        
        # Update curiosity predictor
        self.curiosity.update_predictor([state])
    
    def get_diagnostics(self) -> Dict[str, Any]:
        """Return diagnostic information about novelty engine state."""
        return {
            "t": self.t,
            "alpha": self.alpha(),
            "archive_size": len(self.behavioral.archive),
            "novelty_weights": self.intent.novelty_weights,
            "expected_topology": self.topological.expected,
            "curiosity_predictor_trained": len(self.curiosity.visited_states)
        }


# =============================================================================
# QUALITY-DIVERSITY OPTIMIZER (MAP-Elites Variant)
# =============================================================================

class QualityDiversityOptimizer:
    """
    Quality-Diversity optimization with intent alignment.
    
    Maintains archive of diverse, high-quality solutions.
    
    MAP-Elites algorithm:
    1. Discretize behavior space into cells
    2. For each cell, keep best solution
    3. Generate offspring biased toward novelty
    """
    
    def __init__(self,
                 behavior_dims: int,
                 quality_fn: Callable[[Any], float],
                 novelty_engine: NoveltyEngine,
                 resolution: int = 10):
        self.behavior_dims = behavior_dims
        self.quality_fn = quality_fn
        self.novelty = novelty_engine
        self.resolution = resolution
        
        # Archive: behavior_cell -> (solution, quality, behavior)
        self.archive: Dict[Tuple, Tuple[Any, float, np.ndarray]] = {}
    
    def discretize_behavior(self, behavior: np.ndarray) -> Tuple:
        """Map continuous behavior to discrete cell."""
        # Assume behavior is in [0, 1] range
        normalized = np.clip(behavior, 0, 1)
        # Clamp indices to [0, resolution-1] to avoid off-by-one for behavior==1.0
        idx = (normalized * self.resolution).astype(int)
        idx = np.minimum(idx, self.resolution - 1)
        cell = tuple(idx)
        return cell
    
    def evaluate_and_add(self, 
                          solution: Any, 
                          behavior: np.ndarray) -> bool:
        """
        Evaluate solution and add to archive if novel or better.
        
        Returns True if solution was added.
        """
        quality = self.quality_fn(solution)
        cell = self.discretize_behavior(behavior)
        
        # Add if cell empty or quality higher
        if cell not in self.archive or quality > self.archive[cell][1]:
            self.archive[cell] = (solution, quality, behavior.copy())
            self.novelty.behavioral.add_to_archive(behavior)
            return True
        
        return False
    
    def sample_parent(self) -> Tuple[Any, np.ndarray]:
        """Sample a parent from archive for offspring generation."""
        if not self.archive:
            raise ValueError("Archive is empty")
        
        # Sample uniformly from archive
        # Note: Cannot use np.random.choice on list of tuples directly
        # as numpy converts same-length tuples to 2D array causing ValueError
        keys = list(self.archive.keys())
        idx = np.random.randint(0, len(keys))
        cell = keys[idx]
        solution, _quality, behavior = self.archive[cell]
        return solution, behavior
    
    def get_coverage(self) -> float:
        """Compute coverage of behavior space."""
        total_cells = self.resolution ** self.behavior_dims
        filled_cells = len(self.archive)
        return filled_cells / total_cells
    
    def get_best_solutions(self, n: int = 10) -> List[Tuple[Any, float]]:
        """Get top n solutions by quality."""
        sorted_archive = sorted(
            self.archive.values(),
            key=lambda x: x[1],
            reverse=True
        )
        return [(sol, qual) for sol, qual, _ in sorted_archive[:n]]


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'BehavioralNovelty',
    'CuriosityModule',
    'FisherNoveltyExplorer',
    'NoveltyEngine',
    'QualityDiversityOptimizer',
    'SemanticNovelty',
    'TopologicalInvariants',
    'TopologicalNovelty',
]
