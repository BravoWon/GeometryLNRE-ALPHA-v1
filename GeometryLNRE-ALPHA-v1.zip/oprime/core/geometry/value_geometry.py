"""
Value Geometry (Stage 3 of CTS)
===============================

Implements the Information-Geometric Valuation Framework (IGVF).

Core Equation: g_v = v · g

Where:
    - g: Base Fisher Information Metric (objective geometry)
    - v: Value function (intent-dependent, warps the manifold)
    - g_v: Value-warped metric (subjective geometry)

The value function encodes intent, and its intensity is modulated
by the Intent Alignment dimensions (context × scope).
"""

from dataclasses import dataclass
from typing import Callable, List, Dict, Optional, Tuple, Any
import numpy as np
from abc import ABC, abstractmethod

from ..intent_alignment import IntentConfiguration, IntentAlignedOperator


# =============================================================================
# VALUE FUNCTION INTERFACE
# =============================================================================

class ValueFunction(ABC):
    """
    Abstract interface for value functions.
    
    A value function v: M → R assigns a scalar "relevance" score
    to every point on the manifold.
    """
    
    @abstractmethod
    def evaluate(self, point: np.ndarray) -> float:
        """Compute value at a point."""
        pass
    
    @abstractmethod
    def gradient(self, point: np.ndarray) -> np.ndarray:
        """Compute gradient of value function."""
        pass
    
    def __call__(self, point: np.ndarray) -> float:
        return self.evaluate(point)


class ConstantValue(ValueFunction):
    """Constant value function (no warping)."""
    
    def __init__(self, value: float = 1.0):
        self.value = value
    
    def evaluate(self, point: np.ndarray) -> float:
        return self.value
    
    def gradient(self, point: np.ndarray) -> np.ndarray:
        return np.zeros_like(point)


class GaussianValue(ValueFunction):
    """
    Gaussian value function centered at a goal point.
    
    v(x) = exp(-||x - goal||² / (2σ²))
    
    High value near goal, decays with distance.
    """
    
    def __init__(self, goal: np.ndarray, sigma: float = 1.0):
        self.goal = goal.copy()
        self.sigma = sigma
    
    def evaluate(self, point: np.ndarray) -> float:
        dist_sq = np.sum((point - self.goal) ** 2)
        return np.exp(-dist_sq / (2 * self.sigma ** 2))
    
    def gradient(self, point: np.ndarray) -> np.ndarray:
        dist_sq = np.sum((point - self.goal) ** 2)
        v = np.exp(-dist_sq / (2 * self.sigma ** 2))
        return -v * (point - self.goal) / (self.sigma ** 2)


class MultiGoalValue(ValueFunction):
    """
    Value function with multiple goal regions.
    
    v(x) = max_i exp(-||x - goal_i||² / (2σ_i²))
    
    Supports exploring multiple targets.
    """
    
    def __init__(self, goals: List[np.ndarray], sigmas: Optional[List[float]] = None):
        self.goals = [g.copy() for g in goals]
        self.sigmas = sigmas or [1.0] * len(goals)
    
    def evaluate(self, point: np.ndarray) -> float:
        values = [
            np.exp(-np.sum((point - g) ** 2) / (2 * s ** 2))
            for g, s in zip(self.goals, self.sigmas)
        ]
        return max(values)
    
    def gradient(self, point: np.ndarray) -> np.ndarray:
        # Gradient of max is gradient of the maximizing component
        values = [
            np.exp(-np.sum((point - g) ** 2) / (2 * s ** 2))
            for g, s in zip(self.goals, self.sigmas)
        ]
        max_idx = np.argmax(values)
        
        g = self.goals[max_idx]
        s = self.sigmas[max_idx]
        v = values[max_idx]
        
        return -v * (point - g) / (s ** 2)


class IntentValue(ValueFunction):
    """
    Value function derived from natural language intent.
    
    Uses embedding similarity to score points based on
    semantic alignment with stated intent.
    """
    
    def __init__(self, 
                 intent_embedding: np.ndarray,
                 intensity: float = 1.0):
        self.intent = intent_embedding.copy()
        self.intensity = intensity
    
    def evaluate(self, point: np.ndarray) -> float:
        # Cosine similarity
        norm_point = np.linalg.norm(point)
        norm_intent = np.linalg.norm(self.intent)
        
        if norm_point < 1e-8 or norm_intent < 1e-8:
            return 0.0
        
        similarity = np.dot(point, self.intent) / (norm_point * norm_intent)
        
        # Apply intensity
        return np.power(max(0, similarity), self.intensity)
    
    def gradient(self, point: np.ndarray, epsilon: float = 1e-4) -> np.ndarray:
        grad = np.zeros_like(point)
        v0 = self.evaluate(point)
        
        for i in range(len(point)):
            point_plus = point.copy()
            point_plus[i] += epsilon
            v_plus = self.evaluate(point_plus)
            grad[i] = (v_plus - v0) / epsilon
        
        return grad


# =============================================================================
# VALUE GEOMETRY (IGVF CORE)
# =============================================================================

class ValueGeometry(IntentAlignedOperator):
    """
    Implements IGVF: Information-Geometric Valuation Framework.
    
    Core operation: g_v = v^α · g
    
    Where α is the value intensity from intent alignment.
    """
    
    def __init__(self, 
                 intent: IntentConfiguration,
                 value_fn: ValueFunction,
                 base_metric: Optional[np.ndarray] = None):
        super().__init__(intent)
        
        self.v = value_fn
        self.base_metric = base_metric  # Will be computed per-point if None
        
        # Cache for efficiency
        self._metric_cache: Dict[tuple, np.ndarray] = {}
        self._cache_size = 1000
    
    def compute_base_metric(self, point: np.ndarray) -> np.ndarray:
        """
        Compute base Fisher Information Metric at a point.
        
        Default: Euclidean metric (identity matrix).
        Override for non-flat manifolds.
        """
        if self.base_metric is not None:
            return self.base_metric
        return np.eye(len(point))
    
    def warp_metric(self, point: np.ndarray) -> np.ndarray:
        """
        Apply IGVF conformal transformation.
        
        g_v = v^α · g
        
        Where α is the intent-aligned value intensity.
        """
        # Check cache
        key = tuple(point.round(4))
        if key in self._metric_cache:
            return self._metric_cache[key]
        
        # Compute base metric
        g = self.compute_base_metric(point)
        
        # Compute value
        v = self.v(point)
        
        # Apply intent-aligned intensity
        intensity = self.intent.value_intensity
        warp_factor = np.power(np.abs(v) + 1e-8, intensity)
        
        # Warped metric
        g_v = warp_factor * g
        
        # Cache result
        if len(self._metric_cache) >= self._cache_size:
            self._metric_cache.pop(next(iter(self._metric_cache)))
        self._metric_cache[key] = g_v
        
        return g_v
    
    def compute_geodesic(self, 
                         start: np.ndarray, 
                         end: np.ndarray,
                         n_steps: int = 100) -> List[np.ndarray]:
        """
        Compute geodesic (optimal path) in value-warped geometry.
        
        Uses gradient descent on the warped manifold.
        """
        path = [start.copy()]
        current = start.copy()
        
        for step in range(n_steps):
            # Warped metric at current point
            g_v = self.warp_metric(current)
            
            # Direction to target
            direction = end - current
            
            # Natural gradient (inverse metric)
            try:
                g_v_inv = np.linalg.inv(g_v + 1e-6 * np.eye(len(current)))
            except np.linalg.LinAlgError:
                g_v_inv = np.eye(len(current))
            
            natural_direction = g_v_inv @ direction
            
            # Normalize
            norm = np.linalg.norm(natural_direction)
            if norm > 1e-8:
                natural_direction /= norm
            
            # Adaptive step size based on remaining distance
            remaining_dist = np.linalg.norm(end - current)
            step_size = min(0.1, remaining_dist / 2)
            
            # Step
            current = current + step_size * natural_direction
            path.append(current.copy())
            
            # Check convergence
            if remaining_dist < 0.01:
                break
        
        return path
    
    def identify_phase_transitions(self, 
                                    sample_points: np.ndarray,
                                    threshold_percentile: float = 90) -> np.ndarray:
        """
        Identify Type II (Valuational) Phase Transitions.
        
        These are regions where ||∇v|| > τ — the nodal points
        of maximum leverage.
        """
        gradients = []
        for point in sample_points:
            grad = self.v.gradient(point)
            grad_norm = np.linalg.norm(grad)
            gradients.append(grad_norm)
        
        gradients = np.array(gradients)
        threshold = np.percentile(gradients, threshold_percentile)
        
        # Points exceeding threshold
        phase_transition_mask = gradients > threshold
        
        return sample_points[phase_transition_mask]
    
    def compute_geodesic_distance(self, 
                                   point_a: np.ndarray, 
                                   point_b: np.ndarray) -> float:
        """
        Compute geodesic distance between two points.
        
        Integrates sqrt(dx^T · g_v · dx) along the path.
        """
        path = self.compute_geodesic(point_a, point_b)
        
        total_distance = 0.0
        for i in range(len(path) - 1):
            dx = path[i + 1] - path[i]
            g_v = self.warp_metric(path[i])
            
            # Riemannian distance element
            ds = np.sqrt(np.abs(dx @ g_v @ dx))
            total_distance += ds
        
        return total_distance


# =============================================================================
# MAXOP DETECTOR (High-Leverage Points)
# =============================================================================

class MaxOpDetector(IntentAlignedOperator):
    """
    Identifies Maximum Optimization intervention points.
    
    A MaxOp is a point where small changes have large asymptotic effects.
    
    Leverage = |∂V_∞/∂a| × feasibility(a, s)
    """
    
    def __init__(self, 
                 intent: IntentConfiguration,
                 value_geometry: ValueGeometry):
        super().__init__(intent)
        self.geometry = value_geometry
    
    def compute_leverage(self, 
                         state: np.ndarray, 
                         action: np.ndarray) -> float:
        """
        Compute leverage of an action at a state.
        
        High leverage = small action, large value change.
        """
        # Current value
        v_current = self.geometry.v(state)
        
        # Simulated next state
        next_state = state + action
        v_next = self.geometry.v(next_state)
        
        # Value change
        delta_v = v_next - v_current
        
        # Action magnitude
        action_mag = np.linalg.norm(action)
        
        # Leverage = value change per unit action
        if action_mag < 1e-8:
            return 0.0
        
        leverage = np.abs(delta_v) / action_mag
        
        return leverage
    
    def identify_maxops(self, 
                        trajectory: List[np.ndarray],
                        threshold_percentile: float = 90) -> List[int]:
        """
        Find high-leverage points in a trajectory.
        
        Returns indices of MaxOp candidates.
        """
        leverages = []
        
        for i in range(len(trajectory) - 1):
            action = trajectory[i + 1] - trajectory[i]
            lev = self.compute_leverage(trajectory[i], action)
            leverages.append(lev)
        
        if not leverages:
            return []
        
        leverages = np.array(leverages)
        threshold = np.percentile(leverages, threshold_percentile)
        
        maxop_indices = [i for i, lev in enumerate(leverages) if lev >= threshold]
        
        return maxop_indices
    
    def compute_gradient_leverage(self, point: np.ndarray) -> float:
        """
        Compute leverage based on value gradient magnitude.
        
        High gradient = high leverage region.
        """
        grad = self.geometry.v.gradient(point)
        return np.linalg.norm(grad)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'ValueFunction',
    'ConstantValue',
    'GaussianValue',
    'MultiGoalValue',
    'IntentValue',
    'ValueGeometry',
    'MaxOpDetector',
]
