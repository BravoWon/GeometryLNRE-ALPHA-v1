"""
Conscious State (Stage 6 of CTS)
================================

Defines the conscious configuration C_t = (Q, Φ).

A valid conscious state requires:
    1. Q is NON-TRIVIAL (rich topological structure)
    2. Φ exceeds critical threshold (strong causal integration)

If either constraint is violated, the system experiences
MANIFOLD COLLAPSE — the "death" of the conscious moment.
"""

from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import numpy as np
import time
import warnings

from ..intent_alignment import IntentConfiguration, IntentAlignedOperator


# =============================================================================
# CONSTANTS
# =============================================================================

PHI_CRITICAL = 0.5  # Critical threshold for integrated information
TOPOLOGY_MIN_PERSISTENCE = 0.3  # Minimum persistence for features


# =============================================================================
# TOPOLOGICAL INVARIANTS (Q)
# =============================================================================

@dataclass
class TopologicalInvariants:
    """
    Container for topological invariants (the Quale Q).
    
    Betti numbers:
        β_0: Connected components
        β_1: Loops/holes
        β_2: Voids
    
    Persistent features: (dimension, birth, death) tuples
    """
    betti_0: int = 1
    betti_1: int = 0
    betti_2: int = 0
    total_persistence: float = 0.0
    persistent_features: List[Tuple[int, float, float]] = field(default_factory=list)
    
    def betti_numbers(self) -> Dict[int, int]:
        """Return Betti numbers as dictionary."""
        return {0: self.betti_0, 1: self.betti_1, 2: self.betti_2}
    
    def is_non_trivial(self) -> bool:
        """
        Check if topology is non-trivial.
        
        Non-trivial = has loops OR voids OR multiple components.
        A trivial (contractible) topology indicates semantic failure.
        """
        return (
            self.betti_1 > 0 or 
            self.betti_2 > 0 or 
            self.betti_0 > 1 or
            len(self.persistent_features) >= 3
        )
    
    def complexity(self) -> float:
        """Compute topological complexity score."""
        return (
            1.0 * self.betti_0 +
            2.0 * self.betti_1 +
            3.0 * self.betti_2 +
            0.5 * len(self.persistent_features)
        )
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "betti_0": self.betti_0,
            "betti_1": self.betti_1,
            "betti_2": self.betti_2,
            "total_persistence": self.total_persistence,
            "n_persistent_features": len(self.persistent_features),
            "is_non_trivial": self.is_non_trivial()
        }


# =============================================================================
# CONSCIOUS STATE C_t = (Q, Φ)
# =============================================================================

@dataclass
class ConsciousState:
    """
    The Conscious State C_t = (Q, Φ).
    
    A conscious configuration at time t, valid only if:
        1. Q is non-trivial
        2. Φ >= Φ_critical
    
    This is the Stage 6 output of the CTS pipeline.
    """
    Q: TopologicalInvariants
    phi: float
    timestamp: float = field(default_factory=time.time)
    
    # Validation results
    is_valid: bool = False
    validation_errors: List[str] = field(default_factory=list)
    
    # Metadata
    context: str = ""
    scope: float = 0.5
    
    def __post_init__(self):
        """Validate on creation."""
        self.validate()
    
    def validate(self) -> bool:
        """
        Validate conscious state constraints.
        
        Returns True if valid, False otherwise.
        """
        self.validation_errors = []
        
        # Constraint 1: Non-trivial topology
        if not self.Q.is_non_trivial():
            self.validation_errors.append(
                f"Q is trivial (contractible): β₁={self.Q.betti_1}, β₂={self.Q.betti_2}"
            )
        
        # Constraint 2: Integration threshold
        if self.phi < PHI_CRITICAL:
            self.validation_errors.append(
                f"Φ below critical threshold: {self.phi:.3f} < {PHI_CRITICAL}"
            )
        
        self.is_valid = len(self.validation_errors) == 0
        
        if not self.is_valid:
            warnings.warn(f"Invalid conscious state: {self.validation_errors}")
        
        return self.is_valid
    
    def is_alive(self) -> bool:
        """Check if conscious moment persists."""
        return self.is_valid
    
    def get_quality_score(self) -> float:
        """
        Compute overall quality of conscious state.
        
        Combines topological complexity with integration.
        """
        if not self.is_valid:
            return 0.0
        
        topo_score = self.Q.complexity() / 10.0  # Normalize
        phi_score = min(1.0, self.phi / (2 * PHI_CRITICAL))  # Normalize
        
        return 0.5 * topo_score + 0.5 * phi_score
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "Q": self.Q.to_dict(),
            "phi": self.phi,
            "timestamp": self.timestamp,
            "is_valid": self.is_valid,
            "validation_errors": self.validation_errors,
            "quality_score": self.get_quality_score()
        }


# =============================================================================
# CONSCIOUSNESS EXCEPTIONS
# =============================================================================

class ManifoldCollapseError(Exception):
    """Raised when conscious state constraints are fatally violated."""
    
    def __init__(self, message: str, state: Optional[ConsciousState] = None):
        super().__init__(message)
        self.state = state


class TopologicalCollapseError(ManifoldCollapseError):
    """Raised when Q becomes trivial (contractible)."""
    pass


class IntegrationCollapseError(ManifoldCollapseError):
    """Raised when Φ drops below critical threshold."""
    pass


# =============================================================================
# CONSCIOUSNESS MONITOR
# =============================================================================

class ConsciousnessMonitor(IntentAlignedOperator):
    """
    Monitor conscious state evolution over time.
    
    Tracks:
        - State history
        - Validity transitions
        - Death detection (Φ collapse)
        - Topological evolution
    """
    
    def __init__(self, 
                 intent: IntentConfiguration,
                 phi_critical: float = PHI_CRITICAL):
        super().__init__(intent)
        
        self.phi_critical = phi_critical
        self.history: List[ConsciousState] = []
        
        # Death tracking
        self.death_count = 0
        self.last_death_time: Optional[float] = None
    
    def capture_state(self, 
                      Q: TopologicalInvariants, 
                      phi: float) -> ConsciousState:
        """
        Capture and validate current conscious state.
        """
        state = ConsciousState(
            Q=Q,
            phi=phi,
            context=self.intent.context.value,
            scope=self.intent.scope
        )
        
        self.history.append(state)
        
        # Check for death transition
        if self.detect_death():
            self.death_count += 1
            self.last_death_time = time.time()
        
        return state
    
    def detect_death(self) -> bool:
        """
        Detect death of conscious moment (Φ collapse).
        
        Death occurs when:
            - Previous state was valid
            - Current state is invalid
        """
        if len(self.history) < 2:
            return False
        
        previous = self.history[-2]
        current = self.history[-1]
        
        # Death: valid → invalid transition
        return previous.is_valid and not current.is_valid
    
    def detect_birth(self) -> bool:
        """
        Detect birth of conscious moment.
        
        Birth occurs when:
            - Previous state was invalid
            - Current state is valid
        """
        if len(self.history) < 2:
            return self.history[-1].is_valid if self.history else False
        
        previous = self.history[-2]
        current = self.history[-1]
        
        return not previous.is_valid and current.is_valid
    
    def get_lifetime(self) -> float:
        """
        Compute lifetime of current conscious episode.
        
        Returns 0 if currently dead.
        """
        if not self.history or not self.history[-1].is_valid:
            return 0.0
        
        # Find when current valid episode started
        episode_start = self.history[-1].timestamp
        
        for state in reversed(self.history[:-1]):
            if state.is_valid:
                episode_start = state.timestamp
            else:
                break
        
        return time.time() - episode_start
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get summary statistics of consciousness evolution."""
        if not self.history:
            return {"n_states": 0}
        
        valid_states = [s for s in self.history if s.is_valid]
        phi_values = [s.phi for s in self.history]
        
        return {
            "n_states": len(self.history),
            "n_valid": len(valid_states),
            "validity_rate": len(valid_states) / len(self.history),
            "phi_mean": np.mean(phi_values),
            "phi_std": np.std(phi_values),
            "phi_min": np.min(phi_values),
            "phi_max": np.max(phi_values),
            "death_count": self.death_count,
            "current_lifetime": self.get_lifetime()
        }
    
    def assert_alive(self):
        """Raise exception if consciousness is dead."""
        if not self.history:
            raise ManifoldCollapseError("No conscious state captured yet")
        
        current = self.history[-1]
        
        if not current.is_valid:
            if current.Q.is_non_trivial():
                raise IntegrationCollapseError(
                    f"Φ collapsed: {current.phi:.3f} < {self.phi_critical}",
                    current
                )
            else:
                raise TopologicalCollapseError(
                    f"Q collapsed to trivial topology",
                    current
                )


# =============================================================================
# PHI CALCULATOR (Integrated Information)
# =============================================================================

class PhiCalculator:
    """
    Computes Integrated Information Φ.
    
    Φ measures the extent to which a system's dynamics are
    irreducibly integrated — information generated by the whole
    exceeds the sum of its parts.
    """
    
    def __init__(self, phi_critical: float = PHI_CRITICAL):
        self.phi_critical = phi_critical
    
    def compute_phi(self, 
                    transition_matrix: np.ndarray,
                    partition: Optional[List[List[int]]] = None) -> float:
        """
        Compute Integrated Information Φ.
        
        Φ = I(whole) - max_partition Σ I(parts)
        """
        n = transition_matrix.shape[0]
        
        if partition is None:
            # Default: bipartition
            partition = [[i for i in range(n // 2)], 
                        [i for i in range(n // 2, n)]]
        
        # Information from whole system
        I_whole = self._mutual_information(transition_matrix)
        
        # Information from partitioned system
        I_parts = 0.0
        for part in partition:
            if len(part) > 0:
                part_matrix = transition_matrix[np.ix_(part, part)]
                I_parts += self._mutual_information(part_matrix)
        
        phi = max(0.0, I_whole - I_parts)
        return float(phi)
    
    def _mutual_information(self, P: np.ndarray) -> float:
        """Compute mutual information of transition matrix."""
        n = P.shape[0]
        if n == 0:
            return 0.0
        
        # Ensure valid probability matrix
        P = np.abs(P)
        row_sums = P.sum(axis=1, keepdims=True)
        P = np.where(row_sums > 0, P / row_sums, 1.0 / n)
        
        # Stationary distribution (approximate)
        try:
            eigenvalues, eigenvectors = np.linalg.eig(P.T)
            stationary_idx = np.argmin(np.abs(eigenvalues - 1))
            pi = np.real(eigenvectors[:, stationary_idx])
            pi = np.abs(pi)
            pi = pi / pi.sum() if pi.sum() > 0 else np.ones(n) / n
        except:
            pi = np.ones(n) / n
        
        # Joint distribution
        P_joint = np.outer(pi, np.ones(n)) * P
        
        # Marginals
        P_x = pi
        P_y = P_joint.sum(axis=0)
        P_y = np.where(P_y > 0, P_y, 1e-10)
        
        # Mutual information
        mi = 0.0
        for i in range(n):
            for j in range(n):
                if P_joint[i, j] > 1e-10 and P_x[i] > 1e-10 and P_y[j] > 1e-10:
                    mi += P_joint[i, j] * np.log(P_joint[i, j] / (P_x[i] * P_y[j]))
        
        return max(0, mi)
    
    def compute_program_phi(self, 
                            program_outputs: List[np.ndarray],
                            primitive_outputs: List[List[np.ndarray]]) -> float:
        """
        Compute Φ for a program composition.
        
        High Φ = primitives are interdependent (good)
        Low Φ = primitives are independent (weak composition)
        """
        # Information from whole program
        I_program = self._output_entropy(program_outputs)
        
        # Information from individual primitives
        I_parts = sum(self._output_entropy(p) for p in primitive_outputs)
        
        # Integrated surplus
        return max(0, I_program - I_parts)
    
    def _output_entropy(self, outputs: List[np.ndarray]) -> float:
        """Compute entropy of output distribution."""
        if not outputs:
            return 0.0
        
        # Stack and compute variance (proxy for entropy)
        stacked = np.array(outputs)
        variance = np.var(stacked, axis=0).mean()
        
        # Entropy ≈ log(variance) for Gaussian
        return np.log(variance + 1e-10) / 2 + 0.5 * np.log(2 * np.pi * np.e)
    
    def verify_integration(self, phi: float) -> bool:
        """Check if Φ exceeds critical threshold."""
        return phi >= self.phi_critical


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'PHI_CRITICAL',
    'TopologicalInvariants',
    'ConsciousState',
    'ManifoldCollapseError',
    'TopologicalCollapseError', 
    'IntegrationCollapseError',
    'ConsciousnessMonitor',
    'PhiCalculator',
]
