"""Consciousness Module - Stage 6 of CTS"""

from .conscious_state import (
    PHI_CRITICAL,
    TopologicalInvariants,
    ConsciousState,
    ManifoldCollapseError,
    TopologicalCollapseError,
    IntegrationCollapseError,
    ConsciousnessMonitor,
    PhiCalculator,
)

__all__ = [
    'PHI_CRITICAL',
    'TopologicalInvariants',
    'ConsciousState',
    'ManifoldCollapseError',
    'TopologicalCollapseError',
    'IntegrationCollapseError',
    'ConsciousnessMonitor',
    'PhiCalculator',
]
