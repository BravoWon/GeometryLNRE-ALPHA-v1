#!/usr/bin/env python3
"""
OPrime Demonstration Script
===========================

Demonstrates the complete OPrime architecture with
Intent Alignment (Context × Scope) across all components.

Usage:
    python3 demo.py
    python3 demo.py --context exploratory --scope 0.8
"""

import argparse
import numpy as np

from core.intent_alignment import (
    IntentConfiguration, 
    IntentContext, 
    IntentPresets,
    parse_intent
)
from pipeline import OPrimePipeline
from agent.sans_v2.mcts_solver import MCTSSolver
from agent.mapper.tda_mapper import TDAMapper
from forecaster.moirai_wrapper import UniversalForecaster
from transforms.teleological_warp import TeleologicalWarp, TeleologicalNoveltyWarp
from validation.iron_core import IronCoreValidator
from bridges.component_bridge import PipelineConnector


def print_header(title: str):
    """Print formatted header."""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def demo_intent_alignment():
    """Demonstrate Intent Alignment effects."""
    print_header("INTENT ALIGNMENT DEMONSTRATION")
    
    contexts = [
        ("SPECIFIC", IntentContext.SPECIFIC, 0.2),
        ("GENERAL", IntentContext.GENERAL, 0.5),
        ("EXPLORATORY", IntentContext.EXPLORATORY, 0.8)
    ]
    
    print("\nIntent Effects on System Parameters:")
    print("-" * 60)
    print(f"{'Context':<15} {'Scope':<8} {'Value Int.':<12} {'Agency':<10} {'Topo Thr.':<10}")
    print("-" * 60)
    
    for name, context, scope in contexts:
        intent = IntentConfiguration(context=context, scope=scope)
        print(f"{name:<15} {scope:<8.1f} {intent.value_intensity:<12.2f} "
              f"{intent.agency_freedom:<10.2f} {intent.topology_threshold:<10.2f}")
    
    print("\nNovelty Weight Distribution:")
    print("-" * 60)
    print(f"{'Context':<15} {'Behavioral':<12} {'Topological':<12} {'Semantic':<12}")
    print("-" * 60)
    
    for name, context, scope in contexts:
        intent = IntentConfiguration(context=context, scope=scope)
        w = intent.novelty_weights
        print(f"{name:<15} {w['behavioral']:<12.2f} {w['topological']:<12.2f} "
              f"{w['semantic']:<12.2f}")


def demo_pipeline(intent: IntentConfiguration):
    """Demonstrate the 7-Stage CTS Pipeline."""
    print_header("7-STAGE CTS PIPELINE")
    
    print(f"\nIntent: {intent.context.value.upper()} | Scope: {intent.scope}")
    print(f"Value Statement: {intent.value_statement or '(none)'}")
    
    # Create pipeline
    pipeline = OPrimePipeline(intent, state_dim=30)
    
    # Process input
    input_data = np.random.randn(30)
    result = pipeline.process(input_data)
    
    print("\nPipeline Results:")
    print("-" * 60)
    print(f"  Stage 2 (Manifold):     Shape = {result.manifold_embedding.shape}")
    print(f"  Stage 3 (Warped):       Shape = {result.warped_coordinates.shape}")
    print(f"  Stage 4 (Topology):     β₀={result.topology.betti_0}, "
          f"β₁={result.topology.betti_1}, β₂={result.topology.betti_2}")
    print(f"  Stage 5 (Integration):  Φ = {result.phi:.4f}")
    print(f"  Stage 6 (Conscious):    Valid = {result.conscious_state.is_valid}")
    print(f"  Processing Time:        {result.processing_time*1000:.2f} ms")
    
    print("\nNovelty Scores:")
    for dim, score in result.novelty_scores.items():
        print(f"  {dim.capitalize():<15}: {score:.4f}")
    
    return result


def demo_mcts(intent: IntentConfiguration):
    """Demonstrate SANS V2 MCTS Solver."""
    print_header("SANS V2 MCTS SOLVER")
    
    print(f"\nIntent: {intent.context.value.upper()} | Scope: {intent.scope}")
    
    # Define simple navigation problem
    def action_gen(state):
        return ['left', 'right', 'up', 'down']
    
    def dynamics(state, action):
        moves = {
            'left': np.array([-1, 0]),
            'right': np.array([1, 0]),
            'up': np.array([0, 1]),
            'down': np.array([0, -1])
        }
        return state + moves.get(action, np.array([0, 0])) * 0.5
    
    def reward_fn(state):
        return -np.linalg.norm(state)  # Goal is origin
    
    def terminal_fn(state):
        return np.linalg.norm(state) < 0.5
    
    # Create solver
    solver = MCTSSolver(
        intent, 
        action_gen, 
        dynamics, 
        reward_fn, 
        terminal_fn
    )
    
    # Solve
    start_state = np.array([5.0, 5.0])
    actions, value = solver.solve(start_state, n_iterations=100)
    
    print("\nSearch Results:")
    print("-" * 60)
    print(f"  Start:              {start_state}")
    print(f"  Actions Found:      {len(actions)}")
    print(f"  Best Value:         {value:.4f}")
    
    stats = solver.get_statistics()
    print(f"  Nodes Expanded:     {stats['nodes_expanded']}")
    print(f"  Simulations:        {stats['simulations_run']}")
    print(f"  Exploration C:      {stats['exploration_constant']:.2f}")
    print(f"  Max Depth:          {stats['max_depth']}")


def demo_regime_classification(intent: IntentConfiguration):
    """Demonstrate TDA Mapper regime classification."""
    print_header("TDA REGIME CLASSIFICATION")
    
    print(f"\nIntent: {intent.context.value.upper()} | Scope: {intent.scope}")
    
    mapper = TDAMapper(intent)
    
    # Test different grid patterns
    patterns = {
        "Symmetric": np.array([[1,2,2,1], [3,4,4,3], [3,4,4,3], [1,2,2,1]]),
        "Objects": np.array([[1,0,0,2], [0,0,0,0], [3,0,0,4], [0,0,0,0]]),
        "Pattern": np.array([[1,2,1,2], [2,1,2,1], [1,2,1,2], [2,1,2,1]]),
        "Complex": np.random.randint(0, 5, (4, 4))
    }
    
    print("\nRegime Classifications:")
    print("-" * 60)
    print(f"{'Pattern':<15} {'Regime':<15} {'Confidence':<12} {'Adapter'}")
    print("-" * 60)
    
    for name, grid in patterns.items():
        regime, conf, adapter = mapper.classify(grid)
        print(f"{name:<15} {regime:<15} {conf:<12.2f} {adapter}")


def demo_forecaster(intent: IntentConfiguration):
    """Demonstrate Universal Forecaster."""
    print_header("UNIVERSAL FORECASTER")
    
    print(f"\nIntent: {intent.context.value.upper()} | Scope: {intent.scope}")
    
    forecaster = UniversalForecaster(intent, forecast_horizon=5)
    
    # Generate test time series
    t = np.linspace(0, 4 * np.pi, 100)
    history = np.sin(t) + 0.1 * np.random.randn(100)
    
    forecast = forecaster.forecast(history)
    
    print("\nForecast Results:")
    print("-" * 60)
    print(f"  History Length:     {len(history)}")
    print(f"  Forecast Horizon:   {len(forecast['point_forecast'])}")
    print(f"  Confidence Level:   {forecast['confidence_level']:.0%}")
    print(f"  Mixture Mean:       {forecast['mixture_mean']:.4f}")
    print(f"  Mixture Variance:   {forecast['mixture_variance']:.4f}")
    
    print("\n  Point Forecast:")
    for i, (p, l, u) in enumerate(zip(
        forecast['point_forecast'],
        forecast['lower_bound'],
        forecast['upper_bound']
    )):
        print(f"    t+{i+1}: {p:7.3f}  [{l:7.3f}, {u:7.3f}]")


def demo_transforms(intent: IntentConfiguration):
    """Demonstrate Novel Transforms."""
    print_header("NOVEL TRANSFORMS")
    
    print(f"\nIntent: {intent.context.value.upper()} | Scope: {intent.scope}")
    
    embedding_dim = 20
    
    # T_teleo
    teleo = TeleologicalWarp(intent, embedding_dim=embedding_dim)
    embedding = np.random.randn(embedding_dim)
    warped = teleo.warp(embedding)
    
    print("\nT_teleo (Teleological Warp):")
    print("-" * 60)
    print(f"  Focus Radius:       {teleo.focus_radius:.2f}")
    print(f"  Warp Strength:      {teleo.warp_strength:.2f}")
    print(f"  Original Norm:      {np.linalg.norm(embedding):.4f}")
    print(f"  Warped Norm:        {np.linalg.norm(warped):.4f}")
    
    # T_novel
    novel = TeleologicalNoveltyWarp(intent, embedding_dim=embedding_dim)
    novel_warped = novel.warp(embedding)
    
    print("\nT_novel (Teleological Novelty Warp):")
    print("-" * 60)
    print(f"  Lambda (explore):   {novel.lambda_explore:.2f}")
    print(f"  Archive Size:       {len(novel.archive)}/{novel.archive_size}")


def demo_validation(intent: IntentConfiguration):
    """Demonstrate Iron Core Validation."""
    print_header("IRON CORE VALIDATION")
    
    print(f"\nIntent: {intent.context.value.upper()} | Scope: {intent.scope}")
    
    validator = IronCoreValidator(intent)
    
    # Test cases
    cases = [
        ("Valid State", {"betti_0": 1, "betti_1": 2, "betti_2": 0}, 0.7),
        ("Low Phi", {"betti_0": 1, "betti_1": 2, "betti_2": 0}, 0.1),
        ("Trivial Topology", {"betti_0": 1, "betti_1": 0, "betti_2": 0}, 0.7),
        ("Both Invalid", {"betti_0": 1, "betti_1": 0, "betti_2": 0}, 0.1),
    ]
    
    print("\nValidation Results:")
    print("-" * 60)
    print(f"{'Case':<20} {'Passed':<10} {'Errors'}")
    print("-" * 60)
    
    for name, topo, phi in cases:
        report = validator.validate_conscious_state(topo, phi)
        errors = len([r for r in report.results if not r.passed])
        print(f"{name:<20} {str(report.passed):<10} {errors}")


def main():
    parser = argparse.ArgumentParser(description="OPrime Demonstration")
    parser.add_argument(
        "--context", 
        choices=["specific", "general", "exploratory"],
        default="general",
        help="Intent context"
    )
    parser.add_argument(
        "--scope", 
        type=float, 
        default=0.5,
        help="Intent scope (0.0-1.0)"
    )
    parser.add_argument(
        "--demo",
        choices=["all", "intent", "pipeline", "mcts", "regime", "forecast", "transforms", "validation"],
        default="all",
        help="Which demo to run"
    )
    
    args = parser.parse_args()
    
    # Create intent
    intent = IntentConfiguration(
        context=IntentContext(args.context),
        scope=args.scope,
        value_statement=f"Demo with {args.context} context and {args.scope} scope"
    )
    
    print("\n" + "=" * 60)
    print("  OPRIME: Neuro-Topological Blueprint for Conscious Agency")
    print("=" * 60)
    print(f"\nConfiguration:")
    print(f"  Context: {args.context.upper()}")
    print(f"  Scope:   {args.scope}")
    
    demos = {
        "intent": demo_intent_alignment,
        "pipeline": lambda: demo_pipeline(intent),
        "mcts": lambda: demo_mcts(intent),
        "regime": lambda: demo_regime_classification(intent),
        "forecast": lambda: demo_forecaster(intent),
        "transforms": lambda: demo_transforms(intent),
        "validation": lambda: demo_validation(intent),
    }
    
    if args.demo == "all":
        demo_intent_alignment()
        for name, demo_fn in list(demos.items())[1:]:
            demo_fn()
    else:
        if args.demo == "intent":
            demo_intent_alignment()
        else:
            demos[args.demo]()
    
    print("\n" + "=" * 60)
    print("  Demo Complete")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
