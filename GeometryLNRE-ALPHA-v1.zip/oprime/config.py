"""
OPrime Configuration Management
===============================

Centralized configuration with Intent Alignment presets
and environment-based overrides.

Configuration Hierarchy:
    1. Defaults (base configuration)
    2. Intent Presets (context × scope templates)
    3. Environment Variables (runtime overrides)
    4. Explicit Parameters (highest priority)
"""

import os
from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from enum import Enum

from .core.intent_alignment import IntentConfiguration, IntentContext


# =============================================================================
# CONFIGURATION DATACLASSES
# =============================================================================

@dataclass
class PipelineConfig:
    """Configuration for the CTS pipeline."""
    state_dim: int = 50
    max_processing_time: float = 1.0  # seconds
    enable_novelty: bool = True
    enable_agency: bool = True
    
    # Stage-specific
    manifold_samples: int = 100
    topology_max_dim: int = 2
    phi_critical: float = 0.5


@dataclass
class SearchConfig:
    """Configuration for MCTS search."""
    max_iterations: int = 1000
    time_limit: Optional[float] = None
    exploration_constant: float = 1.0
    max_depth: int = 50
    beam_width: int = 5
    
    # Progressive widening
    widening_k: float = 1.0
    widening_alpha: float = 0.5


@dataclass
class NoveltyConfig:
    """Configuration for novelty engine."""
    archive_size: int = 1000
    k_neighbors: int = 15
    alpha_0: float = 0.5
    alpha_min: float = 0.05
    tau: float = 100


@dataclass
class ValidationConfig:
    """Configuration for Iron Core validation."""
    enable_donders: bool = True
    enable_immutability: bool = True
    enable_topology_check: bool = True
    max_betti_change: int = 2
    tolerance: float = 0.1


@dataclass
class ForecastConfig:
    """Configuration for universal forecaster."""
    forecast_horizon: int = 10
    n_samples: int = 200
    patch_sizes: tuple = (8, 16, 32)


@dataclass 
class OPrimeConfig:
    """Master configuration for OPrime."""
    # Intent
    intent_context: str = "general"
    intent_scope: float = 0.5
    intent_statement: str = ""
    
    # Sub-configurations
    pipeline: PipelineConfig = field(default_factory=PipelineConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    novelty: NoveltyConfig = field(default_factory=NoveltyConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    forecast: ForecastConfig = field(default_factory=ForecastConfig)
    
    # Runtime
    debug: bool = False
    log_level: str = "INFO"
    
    def get_intent(self) -> IntentConfiguration:
        """Create IntentConfiguration from config."""
        return IntentConfiguration(
            context=IntentContext(self.intent_context),
            scope=self.intent_scope,
            value_statement=self.intent_statement
        )
    
    def apply_intent_presets(self):
        """Apply intent-based preset adjustments."""
        intent = self.get_intent()
        
        # Adjust search config
        if intent.context == IntentContext.SPECIFIC:
            self.search.max_depth = 50
            self.search.exploration_constant = 0.5
            self.novelty.alpha_0 = 0.3
        elif intent.context == IntentContext.EXPLORATORY:
            self.search.max_depth = 20
            self.search.exploration_constant = 2.0
            self.novelty.alpha_0 = 0.7
        
        # Adjust validation based on scope
        self.validation.max_betti_change = int(1 + intent.scope * 3)
        self.validation.tolerance = 0.05 + intent.scope * 0.2


# =============================================================================
# PRESET CONFIGURATIONS
# =============================================================================

class ConfigPresets:
    """Pre-defined configuration presets."""
    
    @staticmethod
    def focused_analysis() -> OPrimeConfig:
        """For precise, goal-directed analysis."""
        config = OPrimeConfig(
            intent_context="specific",
            intent_scope=0.2,
            intent_statement="Focused analysis"
        )
        config.search.max_iterations = 2000
        config.pipeline.phi_critical = 0.6
        config.apply_intent_presets()
        return config
    
    @staticmethod
    def balanced_research() -> OPrimeConfig:
        """For general research and exploration."""
        config = OPrimeConfig(
            intent_context="general",
            intent_scope=0.5,
            intent_statement="Balanced research"
        )
        config.apply_intent_presets()
        return config
    
    @staticmethod
    def creative_discovery() -> OPrimeConfig:
        """For maximum novelty and exploration."""
        config = OPrimeConfig(
            intent_context="exploratory",
            intent_scope=0.9,
            intent_statement="Creative discovery"
        )
        config.novelty.archive_size = 2000
        config.search.exploration_constant = 2.5
        config.pipeline.phi_critical = 0.3
        config.apply_intent_presets()
        return config
    
    @staticmethod
    def fast_prototype() -> OPrimeConfig:
        """For quick prototyping with minimal computation."""
        config = OPrimeConfig(
            intent_context="general",
            intent_scope=0.7
        )
        config.search.max_iterations = 100
        config.pipeline.manifold_samples = 20
        config.novelty.archive_size = 100
        config.forecast.n_samples = 50
        return config
    
    @staticmethod
    def production() -> OPrimeConfig:
        """For production deployment with full validation."""
        config = OPrimeConfig(
            intent_context="general",
            intent_scope=0.5
        )
        config.validation.enable_donders = True
        config.validation.enable_immutability = True
        config.search.max_iterations = 5000
        config.debug = False
        config.log_level = "WARNING"
        return config


# =============================================================================
# ENVIRONMENT CONFIGURATION
# =============================================================================

def load_from_env() -> OPrimeConfig:
    """
    Load configuration from environment variables.
    
    Environment Variables:
        OPRIME_INTENT_CONTEXT: specific|general|exploratory
        OPRIME_INTENT_SCOPE: 0.0-1.0
        OPRIME_DEBUG: true|false
        OPRIME_LOG_LEVEL: DEBUG|INFO|WARNING|ERROR
        OPRIME_STATE_DIM: integer
        OPRIME_PHI_CRITICAL: float
    """
    config = OPrimeConfig()
    
    # Intent
    if "OPRIME_INTENT_CONTEXT" in os.environ:
        config.intent_context = os.environ["OPRIME_INTENT_CONTEXT"]
    
    if "OPRIME_INTENT_SCOPE" in os.environ:
        config.intent_scope = float(os.environ["OPRIME_INTENT_SCOPE"])
    
    # Runtime
    if "OPRIME_DEBUG" in os.environ:
        config.debug = os.environ["OPRIME_DEBUG"].lower() == "true"
    
    if "OPRIME_LOG_LEVEL" in os.environ:
        config.log_level = os.environ["OPRIME_LOG_LEVEL"]
    
    # Pipeline
    if "OPRIME_STATE_DIM" in os.environ:
        config.pipeline.state_dim = int(os.environ["OPRIME_STATE_DIM"])
    
    if "OPRIME_PHI_CRITICAL" in os.environ:
        config.pipeline.phi_critical = float(os.environ["OPRIME_PHI_CRITICAL"])
    
    config.apply_intent_presets()
    return config


# =============================================================================
# CONFIGURATION VALIDATION
# =============================================================================

def validate_config(config: OPrimeConfig) -> tuple:
    """
    Validate configuration.
    
    Returns (is_valid, errors).
    """
    errors = []
    
    # Intent validation
    if config.intent_context not in ["specific", "general", "exploratory"]:
        errors.append(f"Invalid intent_context: {config.intent_context}")
    
    if not 0 <= config.intent_scope <= 1:
        errors.append(f"intent_scope must be in [0, 1]: {config.intent_scope}")
    
    # Pipeline validation
    if config.pipeline.state_dim < 1:
        errors.append(f"state_dim must be positive: {config.pipeline.state_dim}")
    
    if config.pipeline.phi_critical < 0:
        errors.append(f"phi_critical must be non-negative: {config.pipeline.phi_critical}")
    
    # Search validation
    if config.search.max_iterations < 1:
        errors.append(f"max_iterations must be positive: {config.search.max_iterations}")
    
    return len(errors) == 0, errors


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'PipelineConfig',
    'SearchConfig',
    'NoveltyConfig',
    'ValidationConfig',
    'ForecastConfig',
    'OPrimeConfig',
    'ConfigPresets',
    'load_from_env',
    'validate_config',
]
