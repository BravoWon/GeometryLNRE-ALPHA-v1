"""
OPrime Knowledge Integration
============================

Integrates the knowledge library into the OPrime runtime,
providing access to documented research and specifications.

The knowledge library contains:
    - 34 research documents
    - 8 thematic categories
    - 50+ cross-referenced topics
    
This module provides:
    - Programmatic access to research documents
    - Semantic search across the corpus
    - Knowledge graph traversal
    - RAG-optimized exports for AI processing
"""

import sys
from pathlib import Path
from typing import Dict, List, Any, Optional

# Add knowledge library to path
KNOWLEDGE_LIBRARY_PATH = Path(__file__).parent.parent.parent / "knowledge_library"
if KNOWLEDGE_LIBRARY_PATH.exists():
    sys.path.insert(0, str(KNOWLEDGE_LIBRARY_PATH / "_tools"))


class KnowledgeInterface:
    """
    Interface to the OPrime Knowledge Library.
    
    Provides access to research documents, topic cross-references,
    and semantic search capabilities.
    
    Usage:
        from oprime.knowledge import KnowledgeInterface
        
        ki = KnowledgeInterface()
        
        # Search by keywords
        results = ki.search(['consciousness', 'topology'])
        
        # Get category overview
        categories = ki.get_categories()
        
        # Find related documents
        related = ki.get_related('SANS_ENGINE_SCIENTIFIC_PAPER')
    """
    
    def __init__(self, library_path: Optional[Path] = None):
        self.library_path = library_path or KNOWLEDGE_LIBRARY_PATH
        self._api = None
        self._initialized = False
    
    @property
    def api(self):
        """Lazy-load the knowledge library API."""
        if self._api is None:
            try:
                from library_api import KnowledgeLibraryAPI
                self._api = KnowledgeLibraryAPI(str(self.library_path))
                self._initialized = True
            except ImportError:
                # Create a minimal fallback
                self._api = MinimalKnowledgeAPI(self.library_path)
                self._initialized = True
        return self._api
    
    @property
    def is_available(self) -> bool:
        """Check if knowledge library is available."""
        return self.library_path.exists()
    
    def search(self, 
               keywords: List[str], 
               match_all: bool = False) -> List[Dict[str, Any]]:
        """
        Search documents by keywords.
        
        Args:
            keywords: List of search terms
            match_all: If True, all keywords must match
            
        Returns:
            List of matching documents with relevance scores
        """
        if not self.is_available:
            return []
        return self.api.search_by_keywords(keywords, match_all)
    
    def get_categories(self) -> Dict[str, Any]:
        """Get all knowledge categories."""
        if not self.is_available:
            return {}
        return self.api.get_all_categories()
    
    def get_documents_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Get documents in a specific category."""
        if not self.is_available:
            return []
        return self.api.get_documents_by_category(category)
    
    def get_related(self, 
                    filename: str, 
                    top_n: int = 5) -> List[Dict[str, Any]]:
        """Get documents related to a given document."""
        if not self.is_available:
            return []
        return self.api.recommend_related_documents(filename, top_n)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get knowledge library statistics."""
        if not self.is_available:
            return {"available": False}
        
        stats = self.api.get_library_statistics()
        stats["available"] = True
        return stats
    
    def export_for_rag(self) -> Dict[str, Any]:
        """Export knowledge in RAG-optimized format."""
        if not self.is_available:
            return {}
        return self.api.export_for_rag()


class MinimalKnowledgeAPI:
    """Minimal fallback when full API not available."""
    
    # Core category definitions
    CATEGORIES = {
        "01_Foundational_Theory": {
            "description": "Core theoretical frameworks and philosophical foundations",
            "keywords": ["geometry of being", "state-adaptive", "consciousness"]
        },
        "02_Mathematical_Foundations": {
            "description": "Rigorous mathematical underpinnings",
            "keywords": ["tensor", "topology", "homology", "persistent"]
        },
        "03_AI_ML_Systems": {
            "description": "Machine learning architectures",
            "keywords": ["machine learning", "deep learning", "transformer", "llm"]
        },
        "04_SANS_Architecture": {
            "description": "Symbolic Abstract Neural Search",
            "keywords": ["sans", "symbolic", "mcts", "program synthesis"]
        },
        "05_Cognitive_Frameworks": {
            "description": "Theories of consciousness and cognition",
            "keywords": ["consciousness", "cognition", "qualia", "agency"]
        },
        "06_Systems_Engineering": {
            "description": "System architecture patterns",
            "keywords": ["architecture", "protocol", "mohlr", "siip"]
        },
        "07_AI_Development": {
            "description": "AI-assisted development workflows",
            "keywords": ["cursor", "development", "debugging", "workflow"]
        },
        "08_Domain_Applications": {
            "description": "Real-world applications",
            "keywords": ["drilling", "sql", "analysis", "domain"]
        }
    }
    
    def __init__(self, library_path: Path):
        self.library_path = library_path
        self._scan_library()
    
    def _scan_library(self):
        """Scan library for documents."""
        self.documents = []
        
        for category_name in self.CATEGORIES.keys():
            category_path = self.library_path / category_name
            if category_path.exists():
                for file_path in category_path.iterdir():
                    if file_path.suffix.lower() in ['.pdf', '.md', '.docx']:
                        self.documents.append({
                            "filename": file_path.name,
                            "category": category_name,
                            "path": str(file_path.relative_to(self.library_path))
                        })
    
    def search_by_keywords(self, 
                            keywords: List[str], 
                            match_all: bool = False) -> List[Dict[str, Any]]:
        """Basic keyword search."""
        keywords_lower = [k.lower() for k in keywords]
        results = []
        
        for doc in self.documents:
            searchable = (
                doc.get('filename', '').lower() + 
                doc.get('category', '').lower()
            )
            matches = sum(1 for kw in keywords_lower if kw in searchable)
            
            if (match_all and matches == len(keywords)) or (not match_all and matches > 0):
                results.append({**doc, "relevance_score": matches})
        
        results.sort(key=lambda x: x['relevance_score'], reverse=True)
        return results
    
    def get_all_categories(self) -> Dict[str, Any]:
        return self.CATEGORIES
    
    def get_documents_by_category(self, category: str) -> List[Dict[str, Any]]:
        return [d for d in self.documents if d.get('category') == category]
    
    def recommend_related_documents(self, 
                                     filename: str, 
                                     top_n: int = 5) -> List[Dict[str, Any]]:
        # Simple: return documents in same category
        source = next((d for d in self.documents if d['filename'] == filename), None)
        if not source:
            return []
        
        related = [d for d in self.documents 
                   if d['category'] == source['category'] and d['filename'] != filename]
        return related[:top_n]
    
    def get_library_statistics(self) -> Dict[str, Any]:
        return {
            "total_documents": len(self.documents),
            "categories": {cat: {"description": info["description"]} 
                          for cat, info in self.CATEGORIES.items()}
        }
    
    def export_for_rag(self) -> Dict[str, Any]:
        return {
            "documents": self.documents,
            "categories": self.CATEGORIES
        }


# Singleton instance
_knowledge_interface: Optional[KnowledgeInterface] = None

def get_knowledge() -> KnowledgeInterface:
    """Get the global knowledge interface instance."""
    global _knowledge_interface
    if _knowledge_interface is None:
        _knowledge_interface = KnowledgeInterface()
    return _knowledge_interface


__all__ = [
    'KnowledgeInterface',
    'get_knowledge',
]
