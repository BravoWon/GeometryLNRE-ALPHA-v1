"""
Tests for OPrime Engine
=======================

Comprehensive tests for the unified engine layer.
"""

import sys
import os

# Add parent of oprime to path for package imports
_workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _workspace not in sys.path:
    sys.path.insert(0, _workspace)

import numpy as np
import unittest

from oprime.engine import OPrimeEngine, EngineState, create_engine, quick_process
from oprime.config import OPrimeConfig, ConfigPresets, validate_config
from oprime.core.intent_alignment import IntentConfiguration, IntentContext


class TestOPrimeEngine(unittest.TestCase):
    """Tests for OPrimeEngine class."""
    
    def test_engine_initialization(self):
        """Test engine initializes correctly."""
        engine = OPrimeEngine()
        
        self.assertEqual(engine._state, EngineState.IDLE)
        self.assertFalse(engine._initialized)
        self.assertIsNotNone(engine.config)
        self.assertIsNotNone(engine.intent)
    
    def test_engine_with_config(self):
        """Test engine with custom config."""
        config = OPrimeConfig(
            intent_context="specific",
            intent_scope=0.2
        )
        engine = OPrimeEngine(config)
        
        self.assertEqual(engine.intent.context, IntentContext.SPECIFIC)
        self.assertAlmostEqual(engine.intent.scope, 0.2)
    
    def test_engine_with_intent(self):
        """Test engine with explicit intent."""
        intent = IntentConfiguration(
            context=IntentContext.EXPLORATORY,
            scope=0.9
        )
        engine = OPrimeEngine(intent=intent)
        
        self.assertEqual(engine.intent.context, IntentContext.EXPLORATORY)
        self.assertAlmostEqual(engine.intent.scope, 0.9)
    
    def test_lazy_initialization(self):
        """Test components are lazily initialized."""
        engine = OPrimeEngine()
        
        # Not initialized yet
        self.assertFalse(engine._initialized)
        self.assertEqual(len(engine._components), 0)
        
        # Force initialization
        engine._init_components()
        
        self.assertTrue(engine._initialized)
        self.assertGreater(len(engine._components), 0)
    
    def test_get_component(self):
        """Test getting specific components."""
        engine = OPrimeEngine()
        
        # Getting component triggers initialization
        mcts = engine.get_component("mcts")
        self.assertIsNotNone(mcts)
        self.assertTrue(engine._initialized)
        
        # Unknown component returns None
        unknown = engine.get_component("nonexistent")
        self.assertIsNone(unknown)
    
    def test_update_intent(self):
        """Test intent update propagation."""
        engine = OPrimeEngine()
        engine._init_components()
        
        # Update intent
        new_intent = IntentConfiguration(
            context=IntentContext.SPECIFIC,
            scope=0.1
        )
        engine.update_intent(new_intent)
        
        self.assertEqual(engine.intent.context, IntentContext.SPECIFIC)
        self.assertAlmostEqual(engine.intent.scope, 0.1)
    
    def test_set_context(self):
        """Test convenience context setter."""
        engine = OPrimeEngine()
        
        engine.set_context("exploratory", 0.8, "Test statement")
        
        self.assertEqual(engine.intent.context, IntentContext.EXPLORATORY)
        self.assertAlmostEqual(engine.intent.scope, 0.8)
        self.assertEqual(engine.intent.value_statement, "Test statement")
    
    def test_process_basic(self):
        """Test basic processing."""
        engine = OPrimeEngine()
        engine.config.pipeline.state_dim = 20
        
        input_data = np.random.randn(20)
        result = engine.process(input_data)
        
        self.assertTrue(result.success)
        self.assertIsNotNone(result.state)
        self.assertIn("observation_dim", result.metrics)
        self.assertEqual(engine._state, EngineState.IDLE)
    
    def test_process_with_goal(self):
        """Test processing with goal state."""
        engine = OPrimeEngine()
        engine.config.pipeline.state_dim = 15
        
        input_data = np.random.randn(15)
        goal = np.ones(15)
        result = engine.process(input_data, goal=goal)
        
        self.assertTrue(result.success)
        self.assertIn("mean_value", result.metrics)
    
    def test_search_basic(self):
        """Test basic search operation."""
        engine = OPrimeEngine()
        engine.config.search.max_iterations = 10
        
        initial = np.array([[1, 0], [0, 1]], dtype=np.float64)
        result = engine.search(initial, max_iterations=5)
        
        self.assertTrue(result.success)
        self.assertIsInstance(result.actions, list)
        self.assertIn("nodes_expanded", result.metrics)
    
    def test_classify_regime(self):
        """Test regime classification."""
        engine = OPrimeEngine()
        
        grid = np.array([
            [1, 0, 0, 1],
            [0, 1, 1, 0],
            [0, 1, 1, 0],
            [1, 0, 0, 1]
        ])
        
        regime, confidence = engine.classify_regime(grid)
        
        self.assertIn(regime, ["symmetry", "counting", "pattern", "reasoning"])
        self.assertGreaterEqual(confidence, 0.0)
        self.assertLessEqual(confidence, 1.0)
    
    def test_forecast(self):
        """Test forecasting."""
        engine = OPrimeEngine()
        
        time_series = np.sin(np.linspace(0, 4*np.pi, 100))
        result = engine.forecast(time_series, horizon=10)
        
        # Check for forecast keys (API uses point_forecast, lower_bound, upper_bound)
        self.assertIn("point_forecast", result)
        self.assertIn("lower_bound", result)
        self.assertIn("upper_bound", result)
        self.assertEqual(len(result["point_forecast"]), 10)
    
    def test_validate(self):
        """Test validation."""
        engine = OPrimeEngine()
        
        state_before = np.array([1, 2, 3])
        state_after = np.array([1, 2, 3])  # Unchanged
        
        result = engine.validate(state_before, state_after)
        
        self.assertIn("immutable", result)
        self.assertIn("topology", result)
        self.assertIn("valid", result)
    
    def test_get_status(self):
        """Test status retrieval."""
        engine = OPrimeEngine()
        status = engine.get_status()
        
        self.assertEqual(status["state"], "idle")
        self.assertFalse(status["initialized"])
        self.assertIn("context", status["intent"])
        self.assertIn("scope", status["intent"])
    
    def test_get_performance_summary(self):
        """Test performance summary."""
        engine = OPrimeEngine()
        engine.config.pipeline.state_dim = 10
        
        # Run some operations
        engine.process(np.random.randn(10))
        
        summary = engine.get_performance_summary()
        
        self.assertIn("total_operations", summary)
        self.assertIn("success_rate", summary)
    
    def test_reset(self):
        """Test engine reset."""
        engine = OPrimeEngine()
        engine.config.pipeline.state_dim = 10
        engine.process(np.random.randn(10))
        
        engine.reset()
        
        self.assertEqual(engine._state, EngineState.IDLE)


class TestEnginePresets(unittest.TestCase):
    """Tests for engine presets."""
    
    def test_create_engine_balanced(self):
        """Test balanced preset."""
        engine = create_engine("balanced")
        
        self.assertIsInstance(engine, OPrimeEngine)
        self.assertEqual(engine.intent.context, IntentContext.GENERAL)
    
    def test_create_engine_focused(self):
        """Test focused preset."""
        engine = create_engine("focused")
        
        self.assertEqual(engine.intent.context, IntentContext.SPECIFIC)
        self.assertLess(engine.intent.scope, 0.5)
    
    def test_create_engine_creative(self):
        """Test creative preset."""
        engine = create_engine("creative")
        
        self.assertEqual(engine.intent.context, IntentContext.EXPLORATORY)
        self.assertGreater(engine.intent.scope, 0.5)
    
    def test_create_engine_fast(self):
        """Test fast preset."""
        engine = create_engine("fast")
        
        self.assertLess(
            engine.config.search.max_iterations, 500
        )
    
    def test_create_engine_production(self):
        """Test production preset."""
        engine = create_engine("production")
        
        self.assertTrue(engine.config.validation.enable_donders)
        self.assertTrue(engine.config.validation.enable_immutability)
    
    def test_create_engine_invalid(self):
        """Test invalid preset raises error."""
        with self.assertRaises(ValueError):
            create_engine("invalid_preset")


class TestQuickProcess(unittest.TestCase):
    """Tests for quick_process function."""
    
    def test_quick_process_default(self):
        """Test quick process with defaults."""
        data = np.random.randn(30)
        result = quick_process(data)
        
        self.assertTrue(result.success)
        self.assertIsNotNone(result.state)
    
    def test_quick_process_specific(self):
        """Test quick process with specific context."""
        data = np.random.randn(20)
        result = quick_process(data, context="specific", scope=0.2)
        
        self.assertTrue(result.success)
    
    def test_quick_process_exploratory(self):
        """Test quick process with exploratory context."""
        data = np.random.randn(25)
        result = quick_process(data, context="exploratory", scope=0.9)
        
        self.assertTrue(result.success)


class TestConfiguration(unittest.TestCase):
    """Tests for configuration system."""
    
    def test_config_defaults(self):
        """Test default configuration."""
        config = OPrimeConfig()
        
        self.assertEqual(config.intent_context, "general")
        self.assertEqual(config.intent_scope, 0.5)
        self.assertEqual(config.pipeline.state_dim, 50)
    
    def test_config_get_intent(self):
        """Test intent extraction from config."""
        config = OPrimeConfig(
            intent_context="specific",
            intent_scope=0.3
        )
        
        intent = config.get_intent()
        
        self.assertEqual(intent.context, IntentContext.SPECIFIC)
        self.assertAlmostEqual(intent.scope, 0.3)
    
    def test_config_apply_presets(self):
        """Test intent preset application."""
        config = OPrimeConfig(intent_context="exploratory")
        original_exploration = config.search.exploration_constant
        
        config.apply_intent_presets()
        
        # Exploratory should increase exploration constant
        self.assertGreater(
            config.search.exploration_constant,
            original_exploration
        )
    
    def test_config_validation_valid(self):
        """Test valid configuration validation."""
        config = OPrimeConfig()
        is_valid, errors = validate_config(config)
        
        self.assertTrue(is_valid)
        self.assertEqual(len(errors), 0)
    
    def test_config_validation_invalid_context(self):
        """Test invalid context validation."""
        config = OPrimeConfig(intent_context="invalid")
        is_valid, errors = validate_config(config)
        
        self.assertFalse(is_valid)
        self.assertGreater(len(errors), 0)
    
    def test_config_validation_invalid_scope(self):
        """Test invalid scope validation."""
        config = OPrimeConfig(intent_scope=1.5)
        is_valid, errors = validate_config(config)
        
        self.assertFalse(is_valid)
    
    def test_presets_focused(self):
        """Test focused preset configuration."""
        config = ConfigPresets.focused_analysis()
        
        self.assertEqual(config.intent_context, "specific")
        self.assertLess(config.intent_scope, 0.5)
    
    def test_presets_creative(self):
        """Test creative preset configuration."""
        config = ConfigPresets.creative_discovery()
        
        self.assertEqual(config.intent_context, "exploratory")
        self.assertGreater(config.intent_scope, 0.5)


class TestTransforms(unittest.TestCase):
    """Tests for transform operations."""
    
    def test_teleological_warp(self):
        """Test teleological warp through engine."""
        engine = OPrimeEngine()
        
        # Use embeddings that match engine's state_dim (default 50)
        embeddings = np.random.randn(10, engine.config.pipeline.state_dim)
        goal = np.ones(engine.config.pipeline.state_dim)
        
        warped = engine.apply_teleological_warp(embeddings, goal)
        
        self.assertEqual(warped.shape, embeddings.shape)
    
    def test_novelty_warp(self):
        """Test novelty warp through engine."""
        engine = OPrimeEngine()
        
        # Use embeddings that match engine's state_dim (default 50)
        dim = engine.config.pipeline.state_dim
        embeddings = np.random.randn(10, dim)
        goal = np.ones(dim)
        archive = [np.random.randn(dim) for _ in range(5)]
        
        warped = engine.apply_novelty_warp(embeddings, goal, archive)
        
        self.assertEqual(warped.shape, embeddings.shape)
    
    def test_regime_switch_check(self):
        """Test regime switch checking."""
        engine = OPrimeEngine()
        
        # Generate layer sequence
        layers = [np.random.randn(20, 10) for _ in range(5)]
        
        result = engine.check_regime_switch(layers)
        
        # Result is either None or a regime name
        self.assertTrue(result is None or isinstance(result, str))


class TestIntentEffects(unittest.TestCase):
    """Tests for intent effects across engine."""
    
    def test_specific_intent_effects(self):
        """Test SPECIFIC intent has tighter focus."""
        engine_specific = create_engine("focused")
        engine_general = create_engine("balanced")
        
        # SPECIFIC should have lower exploration
        self.assertLess(
            engine_specific.config.search.exploration_constant,
            engine_general.config.search.exploration_constant
        )
    
    def test_exploratory_intent_effects(self):
        """Test EXPLORATORY intent has broader search."""
        engine_explore = create_engine("creative")
        engine_general = create_engine("balanced")
        
        # EXPLORATORY should have higher novelty weighting
        self.assertGreater(
            engine_explore.config.novelty.alpha_0,
            engine_general.config.novelty.alpha_0
        )


if __name__ == "__main__":
    print("=" * 60)
    print("OPrime Engine Tests")
    print("=" * 60)
    
    unittest.main(verbosity=2)
