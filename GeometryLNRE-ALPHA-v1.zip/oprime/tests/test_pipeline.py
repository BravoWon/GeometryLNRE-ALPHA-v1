"""
Tests for OPrime Pipeline
=========================

Validates the 7-stage CTS pipeline with intent alignment.
"""

import sys
import os
import numpy as np

# Add parent of oprime to path for package imports
_workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _workspace not in sys.path:
    sys.path.insert(0, _workspace)

from oprime.core.intent_alignment import (
    IntentContext,
    IntentConfiguration,
    IntentPresets,
)
from oprime.core.consciousness.conscious_state import (
    TopologicalInvariants,
    ConsciousState,
    PHI_CRITICAL,
)
from oprime.pipeline import OPrimePipeline, create_pipeline, PipelineResult


def test_pipeline_creation():
    """Test pipeline creation with different intents."""
    # From IntentConfiguration
    intent = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=0.5,
        value_statement="Test pipeline"
    )
    pipeline = OPrimePipeline(intent)
    
    assert pipeline.intent == intent
    assert pipeline.state_dim == 50
    
    print("✓ Pipeline creation test passed")


def test_pipeline_from_prompt():
    """Test pipeline creation from natural language."""
    pipeline = OPrimePipeline.from_prompt(
        "Explore mathematical structures broadly"
    )
    
    assert pipeline.intent.context == IntentContext.GENERAL
    assert pipeline.intent.scope >= 0.5
    
    print("✓ Pipeline from prompt test passed")


def test_create_pipeline_convenience():
    """Test convenience function."""
    pipeline = create_pipeline(
        context="specific",
        scope=0.2,
        goal_statement="Solve the problem",
        state_dim=30
    )
    
    assert pipeline.intent.context == IntentContext.SPECIFIC
    assert pipeline.intent.scope == 0.2
    assert pipeline.state_dim == 30
    
    print("✓ Create pipeline convenience test passed")


def test_pipeline_process():
    """Test full pipeline processing."""
    intent = IntentPresets.balanced_research("topology")
    pipeline = OPrimePipeline(intent, state_dim=20)
    
    # Create test input
    input_data = np.random.randn(20)
    
    # Process
    result = pipeline.process(input_data)
    
    # Check result type
    assert isinstance(result, PipelineResult)
    
    # Check stage outputs
    assert len(result.manifold_embedding) == 20
    assert len(result.warped_coordinates) == 20
    assert isinstance(result.topology, TopologicalInvariants)
    assert isinstance(result.phi, (float, int, np.floating, np.integer))
    assert isinstance(result.conscious_state, ConsciousState)
    
    # Check novelty scores
    assert "behavioral" in result.novelty_scores
    assert "topological" in result.novelty_scores
    assert "semantic" in result.novelty_scores
    
    # Check metadata
    assert result.processing_time > 0
    assert result.intent_alignment["context"] == "general"
    
    print("✓ Pipeline process test passed")


def test_pipeline_result_serialization():
    """Test that pipeline result can be serialized."""
    pipeline = create_pipeline(context="exploratory", scope=0.8)
    input_data = np.random.randn(50)
    result = pipeline.process(input_data)
    
    d = result.to_dict()
    
    assert "topology" in d
    assert "phi" in d
    assert "novelty_scores" in d
    assert "processing_time" in d
    
    print("✓ Pipeline result serialization test passed")


def test_pipeline_different_intents():
    """Test pipeline behavior with different intents."""
    input_data = np.random.randn(20)
    
    # SPECIFIC intent
    specific = create_pipeline(context="specific", scope=0.1, state_dim=20)
    result_specific = specific.process(input_data)
    
    # EXPLORATORY intent
    exploratory = create_pipeline(context="exploratory", scope=0.9, state_dim=20)
    result_exploratory = exploratory.process(input_data)
    
    # Value intensity should differ
    assert result_specific.intent_alignment["value_intensity"] > \
           result_exploratory.intent_alignment["value_intensity"]
    
    # Agency freedom should differ
    assert result_specific.intent_alignment["agency_freedom"] < \
           result_exploratory.intent_alignment["agency_freedom"]
    
    print("✓ Pipeline different intents test passed")


def test_pipeline_multiple_inputs():
    """Test pipeline with multiple sequential inputs."""
    pipeline = create_pipeline(context="general", scope=0.5, state_dim=20)
    
    results = []
    for i in range(5):
        input_data = np.random.randn(20) + i * 0.1
        result = pipeline.process(input_data)
        results.append(result)
    
    # Check that novelty engine is updating
    # Later inputs should have different behavioral novelty
    assert results[-1].novelty_scores["behavioral"] != float('inf') or \
           len(results) < 15  # Archive needs to fill up
    
    print("✓ Pipeline multiple inputs test passed")


def test_conscious_state_validation():
    """Test conscious state validity checking."""
    # Valid topology
    Q_valid = TopologicalInvariants(
        betti_0=1,
        betti_1=2,  # Has loops = non-trivial
        betti_2=0,
        persistent_features=[(0, 0, float('inf')), (1, 0.1, 0.5)]
    )
    
    # Invalid topology (trivial)
    Q_invalid = TopologicalInvariants(
        betti_0=1,
        betti_1=0,  # No loops
        betti_2=0,  # No voids
        persistent_features=[]
    )
    
    # Valid phi
    phi_valid = PHI_CRITICAL + 0.1
    
    # Invalid phi
    phi_invalid = PHI_CRITICAL - 0.1
    
    # Test valid state
    state_valid = ConsciousState(Q=Q_valid, phi=phi_valid)
    assert state_valid.is_valid
    
    # Test invalid (low phi)
    state_low_phi = ConsciousState(Q=Q_valid, phi=phi_invalid)
    assert not state_low_phi.is_valid
    
    # Test invalid (trivial topology)
    state_trivial = ConsciousState(Q=Q_invalid, phi=phi_valid)
    assert not state_trivial.is_valid
    
    print("✓ Conscious state validation test passed")


def run_all_tests():
    """Run all pipeline tests."""
    print("\n=== OPrime Pipeline Tests ===\n")
    
    test_pipeline_creation()
    test_pipeline_from_prompt()
    test_create_pipeline_convenience()
    test_pipeline_process()
    test_pipeline_result_serialization()
    test_pipeline_different_intents()
    test_pipeline_multiple_inputs()
    test_conscious_state_validation()
    
    print("\n=== All Pipeline Tests Passed ===\n")


if __name__ == "__main__":
    run_all_tests()
