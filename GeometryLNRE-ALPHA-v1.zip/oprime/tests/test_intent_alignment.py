"""
Tests for Intent Alignment Framework
=====================================

Validates that intent dimensions (Context × Scope) properly
modulate all downstream computations.
"""

import sys
import os
import numpy as np

# Add parent of oprime to path for package imports
_workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _workspace not in sys.path:
    sys.path.insert(0, _workspace)

from oprime.core.intent_alignment import (
    IntentContext,
    IntentConfiguration,
    IntentPresets,
    parse_intent,
    compute_novelty_weights,
    compute_value_intensity,
    compute_topology_threshold,
    compute_agency_freedom,
)


def test_intent_context_enum():
    """Test IntentContext enum values."""
    assert IntentContext.SPECIFIC.value == "specific"
    assert IntentContext.GENERAL.value == "general"
    assert IntentContext.EXPLORATORY.value == "exploratory"
    print("✓ IntentContext enum test passed")


def test_intent_configuration_creation():
    """Test IntentConfiguration creation and alignment."""
    intent = IntentConfiguration(
        context=IntentContext.SPECIFIC,
        scope=0.3,
        value_statement="Solve the equation"
    )
    
    assert intent.context == IntentContext.SPECIFIC
    assert intent.scope == 0.3
    assert intent.value_statement == "Solve the equation"
    
    # Check that alignment was computed
    assert len(intent.novelty_weights) == 3
    assert intent.value_intensity > 0
    assert 0 < intent.topology_threshold < 1
    assert 0 < intent.agency_freedom <= 1
    
    print("✓ IntentConfiguration creation test passed")


def test_scope_clamping():
    """Test that scope is clamped to [0, 1]."""
    intent_low = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=-0.5
    )
    assert intent_low.scope == 0.0
    
    intent_high = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=1.5
    )
    assert intent_high.scope == 1.0
    
    print("✓ Scope clamping test passed")


def test_novelty_weight_normalization():
    """Test that novelty weights sum to 1."""
    for context in ["specific", "general", "exploratory"]:
        for scope in [0.0, 0.5, 1.0]:
            weights = compute_novelty_weights(context, scope)
            total = sum(weights.values())
            assert abs(total - 1.0) < 1e-6, f"Weights don't sum to 1: {total}"
    
    print("✓ Novelty weight normalization test passed")


def test_value_intensity_ordering():
    """Test that value intensity follows context ordering."""
    # SPECIFIC should have higher intensity than GENERAL
    i_specific = compute_value_intensity(IntentContext.SPECIFIC, 0.5)
    i_general = compute_value_intensity(IntentContext.GENERAL, 0.5)
    i_exploratory = compute_value_intensity(IntentContext.EXPLORATORY, 0.5)
    
    assert i_specific > i_general > i_exploratory
    
    # Narrow scope should have higher intensity than broad
    i_narrow = compute_value_intensity(IntentContext.GENERAL, 0.0)
    i_broad = compute_value_intensity(IntentContext.GENERAL, 1.0)
    
    assert i_narrow > i_broad
    
    print("✓ Value intensity ordering test passed")


def test_topology_threshold_ordering():
    """Test that topology threshold follows context ordering."""
    t_specific = compute_topology_threshold(IntentContext.SPECIFIC, 0.5)
    t_general = compute_topology_threshold(IntentContext.GENERAL, 0.5)
    t_exploratory = compute_topology_threshold(IntentContext.EXPLORATORY, 0.5)
    
    # SPECIFIC should be more strict (higher threshold)
    assert t_specific > t_general > t_exploratory
    
    print("✓ Topology threshold ordering test passed")


def test_agency_freedom_ordering():
    """Test that agency freedom follows context ordering."""
    f_specific = compute_agency_freedom(IntentContext.SPECIFIC, 0.5)
    f_general = compute_agency_freedom(IntentContext.GENERAL, 0.5)
    f_exploratory = compute_agency_freedom(IntentContext.EXPLORATORY, 0.5)
    
    # EXPLORATORY should have most freedom
    assert f_exploratory > f_general > f_specific
    
    print("✓ Agency freedom ordering test passed")


def test_intent_presets():
    """Test preset intent configurations."""
    focused = IntentPresets.focused_goal("Solve x^2 = 4")
    assert focused.context == IntentContext.SPECIFIC
    assert focused.scope == 0.2
    
    explore = IntentPresets.conceptual_exploration("topology")
    assert explore.context == IntentContext.GENERAL
    assert explore.scope == 0.7
    
    discover = IntentPresets.pure_discovery()
    assert discover.context == IntentContext.EXPLORATORY
    assert discover.scope == 1.0
    
    print("✓ Intent presets test passed")


def test_parse_intent():
    """Test natural language intent parsing."""
    # SPECIFIC intent
    specific = parse_intent("Solve this equation precisely")
    assert specific.context == IntentContext.SPECIFIC
    
    # GENERAL intent
    general = parse_intent("Explore mathematical structures")
    assert general.context == IntentContext.GENERAL
    
    # EXPLORATORY intent
    exploratory = parse_intent("Discover novel patterns")
    assert exploratory.context == IntentContext.EXPLORATORY
    
    # Scope modulation
    narrow = parse_intent("Study deeply and focused")
    assert narrow.scope < 0.5
    
    broad = parse_intent("Learn broadly and widely")
    assert broad.scope > 0.5
    
    print("✓ Parse intent test passed")


def test_intent_to_dict():
    """Test serialization."""
    intent = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=0.6,
        value_statement="Test intent"
    )
    
    d = intent.to_dict()
    
    assert d["context"] == "general"
    assert d["scope"] == 0.6
    assert "novelty_weights" in d
    assert "value_intensity" in d
    
    print("✓ Intent serialization test passed")


def run_all_tests():
    """Run all intent alignment tests."""
    print("\n=== Intent Alignment Tests ===\n")
    
    test_intent_context_enum()
    test_intent_configuration_creation()
    test_scope_clamping()
    test_novelty_weight_normalization()
    test_value_intensity_ordering()
    test_topology_threshold_ordering()
    test_agency_freedom_ordering()
    test_intent_presets()
    test_parse_intent()
    test_intent_to_dict()
    
    print("\n=== All Intent Alignment Tests Passed ===\n")


if __name__ == "__main__":
    run_all_tests()
