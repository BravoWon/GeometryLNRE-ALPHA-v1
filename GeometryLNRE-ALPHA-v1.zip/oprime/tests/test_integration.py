"""
Integration Tests
=================

End-to-end tests verifying that all components work together
with consistent Intent Alignment across the system.
"""

import sys
import os
import numpy as np

# Add parent of oprime to path for package imports
_workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _workspace not in sys.path:
    sys.path.insert(0, _workspace)

from oprime.core.intent_alignment import (
    IntentConfiguration, 
    IntentContext, 
    IntentPresets,
    parse_intent
)
from oprime.core.dynamics.sensorimotor import SensorimotorLoop
from oprime.core.topology.persistent_homology import TopologyExtractor, ZigzagPersistence
from oprime.core.geometry.value_geometry import ValueGeometry, GaussianValue
from oprime.core.consciousness.conscious_state import ConsciousState, TopologicalInvariants, PHI_CRITICAL
from oprime.core.novelty.novelty_engine import NoveltyEngine
from oprime.agent.agency.agency_operator import AgencyOperator, ContinuousActionSpace
from oprime.agent.sans_v2.mcts_solver import MCTSSolver, ProgressiveWidening
from oprime.agent.sans_v2.dsl_primitives import DSLRegistry, DSLProgram, ArcObject
from oprime.agent.mapper.tda_mapper import TDAMapper, FeatureExtractor
from oprime.transforms.teleological_warp import TeleologicalWarp, ZigzagRegimeSwitch
from oprime.validation.iron_core import IronCoreValidator
from oprime.forecaster.moirai_wrapper import UniversalForecaster
from oprime.bridges.component_bridge import PipelineConnector
from oprime.pipeline import OPrimePipeline


def test_intent_propagation():
    """Test that intent propagates correctly to all components."""
    print("\n=== Test: Intent Propagation ===")
    
    intent = IntentConfiguration(
        context=IntentContext.EXPLORATORY,
        scope=0.8,
        value_statement="Explore broadly"
    )
    
    # Create components with same intent
    topology = TopologyExtractor(intent)
    novelty = NoveltyEngine(intent, state_dim=20)
    mapper = TDAMapper(intent)
    validator = IronCoreValidator(intent)
    forecaster = UniversalForecaster(intent)
    warp = TeleologicalWarp(intent, embedding_dim=20)
    
    # Verify intent is propagated
    assert topology.intent == intent
    assert novelty.intent == intent
    assert mapper.intent == intent
    assert validator.intent == intent
    assert forecaster.intent == intent
    assert warp.intent == intent
    
    # Verify intent effects
    assert topology.persistence_threshold < 0.3  # Low for exploratory
    assert mapper.switch_threshold < 0.3  # Low for exploratory
    assert forecaster.confidence_level < 0.7  # Wide intervals
    
    print("✓ Intent propagates correctly to all components")


def test_full_pipeline_flow():
    """Test complete pipeline from input to conscious state."""
    print("\n=== Test: Full Pipeline Flow ===")
    
    for context_name, context in [
        ("SPECIFIC", IntentContext.SPECIFIC),
        ("GENERAL", IntentContext.GENERAL),
        ("EXPLORATORY", IntentContext.EXPLORATORY)
    ]:
        intent = IntentConfiguration(context=context, scope=0.5)
        pipeline = OPrimePipeline(intent, state_dim=30)
        
        input_data = np.random.randn(30)
        result = pipeline.process(input_data)
        
        # Verify all stages produced output
        assert result.manifold_embedding is not None
        assert result.warped_coordinates is not None
        assert result.topology is not None
        assert result.phi is not None
        assert result.conscious_state is not None
        
        # Verify novelty scores
        assert "behavioral" in result.novelty_scores
        assert "topological" in result.novelty_scores
        assert "semantic" in result.novelty_scores
        
        print(f"  ✓ {context_name}: Pipeline completed successfully")
    
    print("✓ Full pipeline flow works for all intent contexts")


def test_sensorimotor_to_topology():
    """Test data flow from sensorimotor to topology."""
    print("\n=== Test: Sensorimotor → Topology ===")
    
    intent = IntentPresets.balanced_research("test")
    
    # Sensorimotor loop
    loop = SensorimotorLoop(intent, state_dim=20, observation_dim=20, action_dim=5)
    
    # Process several observations
    states = []
    for _ in range(10):
        obs = np.random.randn(20)
        state, action = loop.step(obs)
        states.append(state)
    
    # Extract topology from trajectory
    trajectory = np.array(states)
    extractor = TopologyExtractor(intent)
    invariants = extractor.extract(trajectory)
    
    assert invariants.betti_0 >= 1
    assert invariants.total_persistence >= 0
    
    print("✓ Sensorimotor output flows correctly to topology extractor")


def test_value_geometry_to_mcts():
    """Test integration of value geometry with MCTS search."""
    print("\n=== Test: Value Geometry → MCTS ===")
    
    intent = IntentPresets.focused_goal("Navigate to origin")
    
    # Value geometry
    goal = np.zeros(2)
    value_fn = GaussianValue(goal, sigma=1.0)
    geometry = ValueGeometry(intent, value_fn)
    
    # MCTS solver
    def action_gen(state):
        return ['left', 'right', 'up', 'down']
    
    def dynamics(state, action):
        moves = {'left': [-0.5, 0], 'right': [0.5, 0], 
                 'up': [0, 0.5], 'down': [0, -0.5]}
        return state + np.array(moves[action])
    
    def reward_fn(state):
        return geometry.v(state)
    
    def terminal_fn(state):
        return np.linalg.norm(state) < 0.5
    
    solver = MCTSSolver(intent, action_gen, dynamics, reward_fn, terminal_fn)
    
    # Solve
    start = np.array([3.0, 3.0])
    actions, value = solver.solve(start, n_iterations=50)
    
    assert len(actions) > 0
    assert value != 0  # Should have found some value
    
    print("✓ Value geometry integrates correctly with MCTS")


def test_novelty_engine_updates():
    """Test that novelty engine updates correctly over time."""
    print("\n=== Test: Novelty Engine Updates ===")
    
    intent = IntentPresets.pure_discovery()
    engine = NoveltyEngine(intent, state_dim=20)
    
    initial_alpha = engine.alpha()
    
    # Process several states
    for i in range(20):
        state = np.random.randn(20)
        behavior = state + 0.1 * np.random.randn(20)
        topology = TopologicalInvariants(betti_0=1, betti_1=i % 3)
        observation = state
        
        engine.update(state, behavior, topology, observation)
        engine.step()
    
    final_alpha = engine.alpha()
    
    # Alpha should decay
    assert final_alpha < initial_alpha
    
    # Archive should be populated
    assert len(engine.behavioral.archive) > 0
    
    print("✓ Novelty engine updates correctly over time")


def test_regime_switching():
    """Test TDA Mapper regime switching."""
    print("\n=== Test: Regime Switching ===")
    
    intent = IntentConfiguration(
        context=IntentContext.EXPLORATORY,
        scope=0.9  # High scope = easy switching
    )
    
    mapper = TDAMapper(intent)
    
    # Symmetric pattern
    symmetric = np.array([
        [1, 2, 2, 1],
        [3, 4, 4, 3],
        [3, 4, 4, 3],
        [1, 2, 2, 1]
    ])
    
    # Pattern with many objects
    objects = np.array([
        [1, 0, 2, 0],
        [0, 0, 0, 0],
        [3, 0, 4, 0],
        [0, 0, 0, 0]
    ])
    
    r1, c1, a1 = mapper.classify(symmetric)
    r2, c2, a2 = mapper.classify(objects)
    
    # Should classify differently
    assert r1 is not None
    assert r2 is not None
    
    print(f"  Symmetric → {r1} (conf={c1:.2f})")
    print(f"  Objects → {r2} (conf={c2:.2f})")
    print("✓ Regime switching works correctly")


def test_dsl_primitives():
    """Test DSL primitives with intent alignment."""
    print("\n=== Test: DSL Primitives ===")
    
    # SPECIFIC intent - limited primitives
    specific = IntentConfiguration(context=IntentContext.SPECIFIC, scope=0.2)
    registry_specific = DSLRegistry(specific)
    
    # EXPLORATORY intent - all primitives
    explore = IntentConfiguration(context=IntentContext.EXPLORATORY, scope=0.9)
    registry_explore = DSLRegistry(explore)
    
    assert len(registry_specific.list_available()) < len(registry_explore.list_available())
    
    # Test basic primitive (use asymmetric grid)
    grid = np.array([
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [0, 0, 0, 0]
    ])
    
    flipped = registry_explore.apply("flip_h", grid)
    assert not np.array_equal(grid, flipped), "Flip should change asymmetric grid"
    
    rotated = registry_explore.apply("rotate", grid, times=1)
    assert rotated.shape[0] == grid.shape[1]
    
    print(f"  SPECIFIC: {len(registry_specific.list_available())} primitives")
    print(f"  EXPLORATORY: {len(registry_explore.list_available())} primitives")
    print("✓ DSL primitives respect intent alignment")


def test_forecaster_to_tda():
    """Test forecaster output to TDA input bridge."""
    print("\n=== Test: Forecaster → TDA Bridge ===")
    
    intent = IntentPresets.balanced_research("test")
    
    # Generate forecast
    forecaster = UniversalForecaster(intent, forecast_horizon=10)
    history = np.sin(np.linspace(0, 4*np.pi, 100))
    forecast = forecaster.forecast(history)
    
    # Bridge to TDA
    connector = PipelineConnector(intent)
    tda_input = connector.connect_forecast_to_topology(forecast)
    
    assert "pointcloud" in tda_input
    assert "features" in tda_input
    assert len(tda_input["pointcloud"]) > 0
    
    print("✓ Forecaster output bridges correctly to TDA")


def test_validation_integration():
    """Test Iron Core validation with conscious state."""
    print("\n=== Test: Validation Integration ===")
    
    intent = IntentPresets.focused_goal("test")
    validator = IronCoreValidator(intent)
    
    # Valid state
    valid_report = validator.validate_conscious_state(
        {"betti_0": 1, "betti_1": 2, "betti_2": 0},
        phi=0.7
    )
    
    # Invalid state (low phi)
    invalid_report = validator.validate_conscious_state(
        {"betti_0": 1, "betti_1": 2, "betti_2": 0},
        phi=0.1
    )
    
    assert valid_report.passed
    assert not invalid_report.passed
    
    print("✓ Validation integrates correctly with conscious state")


def test_transforms_chain():
    """Test chaining multiple transforms."""
    print("\n=== Test: Transform Chain ===")
    
    intent = IntentPresets.conceptual_exploration("math")
    
    # Create transforms
    teleo = TeleologicalWarp(intent, embedding_dim=30)
    
    # Chain transforms
    embedding = np.random.randn(30)
    
    # First warp
    warped1 = teleo.warp(embedding)
    
    # Second warp (should continue toward intent)
    warped2 = teleo.warp(warped1)
    
    # Warped should be closer to intent
    dist_original = np.linalg.norm(embedding - teleo.intent_embedding)
    dist_warped = np.linalg.norm(warped2 - teleo.intent_embedding)
    
    # May not always be closer due to normalization, but should transform
    assert not np.allclose(embedding, warped2)
    
    print("✓ Transforms chain correctly")


def test_zigzag_persistence():
    """Test zigzag persistence across layers."""
    print("\n=== Test: Zigzag Persistence ===")
    
    intent = IntentPresets.balanced_research("layers")
    
    zigzag = ZigzagPersistence(intent)
    extractor = TopologyExtractor(intent)
    
    # Simulate multiple layers
    for i in range(5):
        layer_embeddings = np.random.randn(20, 10) + i * 0.1
        zigzag.add_layer(layer_embeddings, extractor)
    
    # Analyze lifespans
    lifespans = zigzag.compute_feature_lifespan()
    
    assert "components" in lifespans
    assert "loops" in lifespans
    
    # Check cognitive phases
    phase_0 = zigzag.get_cognitive_phase(0)
    phase_mid = zigzag.get_cognitive_phase(2)
    phase_end = zigzag.get_cognitive_phase(4)
    
    assert phase_0 in ["contextualization", "abstraction", "actuation"]
    
    print(f"  Phase 0: {phase_0}")
    print(f"  Phase 2: {phase_mid}")
    print(f"  Phase 4: {phase_end}")
    print("✓ Zigzag persistence works across layers")


def test_end_to_end_with_search():
    """Full end-to-end test with search."""
    print("\n=== Test: End-to-End with Search ===")
    
    intent = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=0.5,
        value_statement="Find optimal solution"
    )
    
    # 1. Create pipeline
    pipeline = OPrimePipeline(intent, state_dim=20)
    
    # 2. Process initial state
    initial_input = np.random.randn(20)
    result = pipeline.process(initial_input)
    
    # 3. Use result to configure search
    def action_gen(state):
        return list(range(4))
    
    def dynamics(state, action):
        directions = [[-1, 0], [1, 0], [0, -1], [0, 1]]
        new_state = state.copy()
        new_state[:2] = state[:2] + np.array(directions[action]) * 0.5
        return new_state
    
    # Use novelty as part of reward
    def reward_fn(state):
        goal_reward = -np.linalg.norm(state[:2])
        novelty = result.exploration_bonus
        return goal_reward + 0.1 * novelty
    
    def terminal_fn(state):
        return np.linalg.norm(state[:2]) < 0.5
    
    solver = MCTSSolver(intent, action_gen, dynamics, reward_fn, terminal_fn)
    
    # 4. Solve
    start = np.zeros(20)
    start[:2] = [3, 3]
    actions, value = solver.solve(start, n_iterations=30)
    
    # 5. Validate result
    validator = IronCoreValidator(intent)
    final_report = validator.validate_conscious_state(
        result.topology.to_dict(),
        result.phi
    )
    
    print(f"  Pipeline result valid: {result.is_valid}")
    print(f"  Search found {len(actions)} actions")
    print(f"  Final validation passed: {final_report.passed}")
    print("✓ End-to-end integration works correctly")


def run_all_integration_tests():
    """Run all integration tests."""
    print("\n" + "=" * 60)
    print("  OPRIME INTEGRATION TESTS")
    print("=" * 60)
    
    test_intent_propagation()
    test_full_pipeline_flow()
    test_sensorimotor_to_topology()
    test_value_geometry_to_mcts()
    test_novelty_engine_updates()
    test_regime_switching()
    test_dsl_primitives()
    test_forecaster_to_tda()
    test_validation_integration()
    test_transforms_chain()
    test_zigzag_persistence()
    test_end_to_end_with_search()
    
    print("\n" + "=" * 60)
    print("  ALL INTEGRATION TESTS PASSED")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    run_all_integration_tests()
