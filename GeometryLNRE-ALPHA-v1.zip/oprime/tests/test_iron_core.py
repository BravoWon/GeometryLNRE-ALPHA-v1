"""
Tests for Iron Core Validation
==============================

Tests covering:
1. DondersSubtraction.run_with_trace - trace recording via callback
2. full_validation with empty-but-valid after_topology
"""

import sys
import os

# Add parent of oprime to path for package imports
_workspace = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _workspace not in sys.path:
    sys.path.insert(0, _workspace)

import numpy as np
import unittest

from oprime.validation.iron_core import (
    DondersSubtraction, 
    IronCoreValidator, 
    TopologyInvariantChecker,
    ImmutabilityValidator,
    ValidationResult
)
from oprime.core.intent_alignment import IntentConfiguration, IntentContext


class TestDondersSubtractionTrace(unittest.TestCase):
    """Tests for DondersSubtraction trace recording."""
    
    def test_trace_recording_with_callback(self):
        """Test that traces are recorded when function uses trace callback."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        donders = DondersSubtraction(intent)
        
        # Create a function that uses the trace callback
        def traceable_function(data, trace=None):
            if trace:
                trace("step_1: received data")
                trace("step_2: processing")
            result = data * 2
            if trace:
                trace("step_3: completed")
            return result
        
        input_data = np.array([1, 2, 3])
        result, trace_list = donders.run_with_trace(
            traceable_function, input_data, "test_trace"
        )
        
        # Verify result is correct
        np.testing.assert_array_equal(result, np.array([2, 4, 6]))
        
        # Verify traces were recorded
        self.assertGreater(len(trace_list), 0)
        self.assertIn("step_1: received data", trace_list)
        self.assertIn("step_2: processing", trace_list)
        self.assertIn("step_3: completed", trace_list)
    
    def test_trace_recording_without_callback(self):
        """Test that functions without trace param still work."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        donders = DondersSubtraction(intent)
        
        # Create a function that doesn't accept trace callback
        def simple_function(data):
            return data * 3
        
        input_data = np.array([1, 2, 3])
        result, trace_list = donders.run_with_trace(
            simple_function, input_data, "simple_trace"
        )
        
        # Verify result is correct
        np.testing.assert_array_equal(result, np.array([3, 6, 9]))
        
        # Traces should be empty (function didn't call trace)
        self.assertEqual(len(trace_list), 0)
    
    def test_trace_method_directly(self):
        """Test that trace() method records to correct trace name."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        donders = DondersSubtraction(intent)
        
        # Record some traces manually (trace(name, step) - name is the trace id, step is the content)
        donders.trace("manual_test", "manual_step_1")
        donders.trace("manual_test", "manual_step_2")
        
        # Verify traces were recorded
        self.assertEqual(len(donders.traces["manual_test"]), 2)
        self.assertIn("manual_step_1", donders.traces["manual_test"])
        self.assertIn("manual_step_2", donders.traces["manual_test"])


class TestFullValidationEmptyTopology(unittest.TestCase):
    """Tests for full_validation with empty-but-valid topology."""
    
    def test_empty_betti_dict_not_skipped(self):
        """Test that empty-but-valid after_topology dict is not skipped."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        validator = IronCoreValidator(intent)
        
        state = np.array([1, 2, 3, 4, 5])
        
        # Create an operation that returns the same state
        def identity_operation(x):
            return x.copy()
        
        # Topology with all zeros (empty but valid)
        empty_topology = {"betti_0": 0, "betti_1": 0, "betti_2": 0}
        
        # Should NOT skip validation just because topology dicts evaluate to falsy
        report = validator.full_validation(
            state=state,
            topology=empty_topology,
            phi=0.6,
            operation=identity_operation,
            after_topology=empty_topology  # Empty but valid dict
        )
        
        # Validation should have run (report contains results)
        self.assertIsNotNone(report)
        # The report should contain transformation validation results
        # since operation and after_topology are both not None
        result_names = [r.check_name for r in report.results]
        # At minimum, we should have basic validations
        self.assertGreater(len(report.results), 0)
    
    def test_none_values_skip_transformation(self):
        """Test that None values correctly skip transformation validation."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        validator = IronCoreValidator(intent)
        
        state = np.array([1, 2, 3])
        topology = {"betti_0": 1, "betti_1": 0, "betti_2": 0}
        
        # With None operation and None after_topology
        report = validator.full_validation(
            state=state,
            topology=topology,
            phi=0.7,
            operation=None,
            after_topology=None
        )
        
        # Should still have basic validations
        self.assertIsNotNone(report)
        self.assertGreater(len(report.results), 0)


class TestTopologyInvariantChecker(unittest.TestCase):
    """Tests for TopologyInvariantChecker."""
    
    def test_betti_preservation_empty_dict(self):
        """Test that empty betti dicts work correctly."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        checker = TopologyInvariantChecker(intent)
        
        # Empty but valid dicts
        before = {"betti_0": 0, "betti_1": 0, "betti_2": 0}
        after = {"betti_0": 0, "betti_1": 0, "betti_2": 0}
        
        # Should return True (no change = preserved)
        result = checker.check_betti_preservation(before, after)
        self.assertTrue(result)
    
    def test_betti_preservation_within_tolerance(self):
        """Test preservation within allowed change."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        checker = TopologyInvariantChecker(intent)
        
        before = {"betti_0": 2, "betti_1": 1, "betti_2": 0}
        after = {"betti_0": 3, "betti_1": 1, "betti_2": 0}  # β₀ changed by 1
        
        # Returns ValidationResult, check passed attribute
        result = checker.check_betti_preservation(before, after)
        self.assertIsInstance(result, (bool, ValidationResult))
        # If ValidationResult, check the passed attribute
        if isinstance(result, ValidationResult):
            self.assertIsInstance(result.passed, bool)


class TestImmutabilityValidator(unittest.TestCase):
    """Tests for ImmutabilityValidator."""
    
    def test_validate_operation_preserves_original(self):
        """Test that original state is preserved after validation."""
        intent = IntentConfiguration(
            context=IntentContext.GENERAL,
            scope=0.5
        )
        validator = ImmutabilityValidator(intent)
        
        original = np.array([1, 2, 3, 4, 5])
        original_copy = original.copy()
        
        def mutating_operation(x):
            result = x * 2
            return result
        
        result = validator.validate_operation(original, mutating_operation)
        
        # Original should be unchanged
        np.testing.assert_array_equal(original, original_copy)
        
        # Result should indicate success
        self.assertIsInstance(result, ValidationResult)


if __name__ == "__main__":
    print("=" * 60)
    print("Iron Core Validation Tests")
    print("=" * 60)
    
    unittest.main(verbosity=2)
