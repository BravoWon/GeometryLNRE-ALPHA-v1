"""
OPrime Pipeline
===============

The unified pipeline implementing the 7-Stage Configurational Term Series (CTS):

    X →[f(x)]→ M →[v]→ M_v →[H_k]→ Q(Φ) →[Agency]→ C_t

Each stage is modulated by Intent Alignment (Context × Scope).

Usage:
    intent = IntentConfiguration(
        context=IntentContext.GENERAL,
        scope=0.6,
        value_statement="Explore the structure of consciousness"
    )
    
    pipeline = OPrimePipeline(intent)
    result = pipeline.process(input_data)
"""

from dataclasses import dataclass
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
import time

try:
    from .core.intent_alignment import (
        IntentConfiguration, 
        IntentContext,
        IntentAlignedOperator,
        parse_intent,
    )
    from .core.geometry.value_geometry import (
        ValueGeometry,
        GaussianValue,
        IntentValue,
        MaxOpDetector,
    )
    from .core.consciousness.conscious_state import (
        ConsciousState,
        TopologicalInvariants,
        ConsciousnessMonitor,
        PhiCalculator,
        PHI_CRITICAL,
        ManifoldCollapseError,
    )
    from .core.novelty.novelty_engine import (
        NoveltyEngine,
        BehavioralNovelty,
        TopologicalNovelty,
        SemanticNovelty,
    )
    from .agent.agency.agency_operator import (
        AgencyOperator,
        ContinuousActionSpace,
        ContinuityGuard,
        Action,
    )
except ImportError:
    from core.intent_alignment import (
        IntentConfiguration, 
        IntentContext,
        IntentAlignedOperator,
        parse_intent,
    )
    from core.geometry.value_geometry import (
        ValueGeometry,
        GaussianValue,
        IntentValue,
        MaxOpDetector,
    )
    from core.consciousness.conscious_state import (
        ConsciousState,
        TopologicalInvariants,
        ConsciousnessMonitor,
        PhiCalculator,
        PHI_CRITICAL,
        ManifoldCollapseError,
    )
    from core.novelty.novelty_engine import (
        NoveltyEngine,
        BehavioralNovelty,
        TopologicalNovelty,
        SemanticNovelty,
    )
    from agent.agency.agency_operator import (
        AgencyOperator,
        ContinuousActionSpace,
        ContinuityGuard,
        Action,
    )


@dataclass
class PipelineResult:
    """Result from OPrime pipeline processing."""
    
    # Stage outputs
    manifold_embedding: np.ndarray  # Stage 2: M
    warped_coordinates: np.ndarray  # Stage 3: M_v
    topology: TopologicalInvariants  # Stage 4: Q
    phi: float  # Stage 5: Φ
    conscious_state: ConsciousState  # Stage 6: C_t
    
    # Novelty metrics
    novelty_scores: Dict[str, float]
    exploration_bonus: float
    
    # Agency output
    recommended_action: Optional[Action]
    action_trajectory: List[np.ndarray]
    
    # Phase transitions
    phase_transitions: List[np.ndarray]
    maxops: List[int]
    
    # Metadata
    processing_time: float
    intent_alignment: Dict[str, Any]
    is_valid: bool
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "manifold_embedding_shape": self.manifold_embedding.shape,
            "warped_coordinates_shape": self.warped_coordinates.shape,
            "topology": self.topology.to_dict(),
            "phi": self.phi,
            "conscious_state": self.conscious_state.to_dict(),
            "novelty_scores": self.novelty_scores,
            "exploration_bonus": self.exploration_bonus,
            "n_phase_transitions": len(self.phase_transitions),
            "n_maxops": len(self.maxops),
            "processing_time": self.processing_time,
            "is_valid": self.is_valid,
        }


class OPrimePipeline(IntentAlignedOperator):
    """
    The OPrime Pipeline: 7-Stage Configurational Term Series.
    
    Stages:
        1. Sensorimotor Interface (X)
        2. Manifold Abstraction (M)
        3. Value Geometry (M_v)
        4. Topological Form (Q)
        5. Integration (Φ)
        6. Conscious State (C_t)
        7. Agency
    
    All stages are modulated by Intent Alignment.
    """
    
    def __init__(self, 
                 intent: IntentConfiguration,
                 state_dim: int = 50,
                 goal: Optional[np.ndarray] = None):
        super().__init__(intent)
        
        self.state_dim = state_dim
        
        # Initialize goal (for value function)
        if goal is None:
            goal = np.zeros(state_dim)
        self.goal = goal
        
        # Intent embedding (from value statement)
        self.intent_embedding = self._compute_intent_embedding(intent.value_statement)
        
        # Stage 3: Value Geometry (IGVF)
        value_fn = IntentValue(self.intent_embedding, intent.value_intensity)
        self.value_geometry = ValueGeometry(intent, value_fn)
        self.maxop_detector = MaxOpDetector(intent, self.value_geometry)
        
        # Stage 5: Phi Calculator
        self.phi_calculator = PhiCalculator(PHI_CRITICAL)
        
        # Stage 6: Consciousness Monitor
        self.consciousness_monitor = ConsciousnessMonitor(intent)
        
        # Novelty Engine
        self.novelty_engine = NoveltyEngine(
            intent,
            state_dim,
            self.intent_embedding
        )
        
        # Stage 7: Agency
        action_space = ContinuousActionSpace(state_dim, step_size=0.1)
        self.agency = AgencyOperator(
            intent,
            action_space,
            lambda x: self.value_geometry.v(x),
            ContinuityGuard()
        )
    
    def _compute_intent_embedding(self, value_statement: str) -> np.ndarray:
        """
        Compute embedding from intent value statement.
        
        Simplified: hash-based embedding.
        In production, use sentence transformer.
        """
        if not value_statement:
            return np.random.randn(self.state_dim)
        
        # Simple hash-based embedding
        np.random.seed(hash(value_statement) % (2**32))
        embedding = np.random.randn(self.state_dim)
        np.random.seed()  # Reset
        
        return embedding / np.linalg.norm(embedding)
    
    def process(self, input_data: np.ndarray) -> PipelineResult:
        """
        Process input through the 7-stage CTS pipeline.
        
        Args:
            input_data: Raw input (Stage 1 substrate)
        
        Returns:
            PipelineResult with all stage outputs
        """
        start_time = time.time()
        
        # =================================================================
        # STAGE 1: Sensorimotor Interface (X)
        # =================================================================
        # Input is already in X (high-dimensional substrate)
        X = input_data.flatten() if input_data.ndim > 1 else input_data
        
        # Pad/truncate to state_dim
        if len(X) < self.state_dim:
            X = np.pad(X, (0, self.state_dim - len(X)))
        elif len(X) > self.state_dim:
            X = X[:self.state_dim]
        
        # =================================================================
        # STAGE 2: Manifold Abstraction (M)
        # =================================================================
        # Simple projection (in production, use diffusion maps)
        M = self._project_to_manifold(X)
        
        # =================================================================
        # STAGE 3: Value Geometry (M_v)
        # =================================================================
        # Apply IGVF warping
        M_v = self._warp_by_value(M)
        
        # Identify phase transitions
        sample_points = self._sample_neighborhood(M_v, n_samples=50)
        phase_transitions = self.value_geometry.identify_phase_transitions(
            sample_points,
            threshold_percentile=self.intent.topology_threshold * 100
        )
        
        # =================================================================
        # STAGE 4: Topological Form (Q)
        # =================================================================
        Q = self._extract_topology(M_v)
        
        # =================================================================
        # STAGE 5: Integration (Φ)
        # =================================================================
        phi = self._compute_integration(M_v)
        
        # =================================================================
        # STAGE 6: Conscious State (C_t)
        # =================================================================
        conscious_state = self.consciousness_monitor.capture_state(Q, phi)
        
        # =================================================================
        # NOVELTY COMPUTATION
        # =================================================================
        behavior = M_v  # Use warped coordinates as behavior descriptor
        observation = X  # Original observation
        
        novelty_scores = {
            "behavioral": self.novelty_engine.behavioral.compute(behavior),
            "topological": self.novelty_engine.topological.compute(Q),
            "semantic": self.novelty_engine.semantic.compute(
                observation, {"scope": self.intent.scope}
            ),
        }
        
        total_novelty = self.novelty_engine.compute_total_novelty(
            M_v, behavior, Q, observation
        )
        
        exploration_bonus = self.novelty_engine.compute_exploration_bonus(M_v)
        
        # Update novelty engine
        self.novelty_engine.update(M_v, behavior, Q, observation)
        self.novelty_engine.step()
        
        # =================================================================
        # STAGE 7: Agency
        # =================================================================
        recommended_action = None
        action_trajectory = []
        maxops = []
        
        if conscious_state.is_valid:
            # Find best action
            recommended_action = self.agency.find_best_action(M_v, Q)
            
            # Navigate toward goal
            if recommended_action is not None:
                action_trajectory = self.agency.navigate(
                    M_v, self.goal, max_steps=20
                )
                
                # Identify MaxOps in trajectory
                if len(action_trajectory) > 1:
                    maxops = self.maxop_detector.identify_maxops(action_trajectory)
        
        # =================================================================
        # RESULT
        # =================================================================
        processing_time = time.time() - start_time
        
        return PipelineResult(
            manifold_embedding=M,
            warped_coordinates=M_v,
            topology=Q,
            phi=phi,
            conscious_state=conscious_state,
            novelty_scores=novelty_scores,
            exploration_bonus=exploration_bonus,
            recommended_action=recommended_action,
            action_trajectory=action_trajectory,
            phase_transitions=list(phase_transitions) if len(phase_transitions) > 0 else [],
            maxops=maxops,
            processing_time=processing_time,
            intent_alignment=self.intent.to_dict(),
            is_valid=conscious_state.is_valid,
        )
    
    def _project_to_manifold(self, X: np.ndarray) -> np.ndarray:
        """
        Stage 2: Project to lower-dimensional manifold.
        
        Simplified: normalize and apply soft nonlinearity.
        In production: use diffusion maps.
        """
        # Normalize
        norm = np.linalg.norm(X)
        if norm > 0:
            X = X / norm
        
        # Soft nonlinearity (manifold embedding)
        M = np.tanh(X)
        
        return M
    
    def _warp_by_value(self, M: np.ndarray) -> np.ndarray:
        """
        Stage 3: Apply IGVF value warping.
        
        Warps the manifold coordinates by the value function.
        """
        # Get warped metric
        g_v = self.value_geometry.warp_metric(M)
        
        # Transform coordinates (simplified)
        # In full implementation: geodesic transport
        v = self.value_geometry.v(M)
        intensity = self.intent.value_intensity
        
        M_v = M * np.power(np.abs(v) + 0.1, intensity / 2)
        
        return M_v
    
    def _sample_neighborhood(self, center: np.ndarray, 
                              n_samples: int, radius: float = 0.5) -> np.ndarray:
        """Sample points in neighborhood of center."""
        samples = []
        for _ in range(n_samples):
            direction = np.random.randn(len(center))
            direction /= np.linalg.norm(direction)
            distance = np.random.uniform(0, radius)
            samples.append(center + direction * distance)
        return np.array(samples)
    
    def _extract_topology(self, M_v: np.ndarray) -> TopologicalInvariants:
        """
        Stage 4: Extract topological invariants.
        
        Simplified: heuristic-based topology.
        In production: use persistent homology (GUDHI).
        """
        # Heuristic topology based on coordinate patterns
        
        # β_0: Connected components (always 1 for single point)
        betti_0 = 1
        
        # β_1: Loops (detected by coordinate oscillations)
        oscillations = np.sum(np.abs(np.diff(np.sign(M_v)))) / 2
        betti_1 = int(oscillations)
        
        # β_2: Voids (detected by local minima)
        betti_2 = 0
        
        # Persistence (heuristic)
        total_persistence = np.sum(np.abs(M_v))
        
        return TopologicalInvariants(
            betti_0=betti_0,
            betti_1=betti_1,
            betti_2=betti_2,
            total_persistence=total_persistence,
            persistent_features=[(0, 0.0, float('inf'))]  # At least one component
        )
    
    def _compute_integration(self, M_v: np.ndarray) -> float:
        """
        Stage 5: Compute integrated information Φ.
        
        Simplified: use variance-based proxy.
        In production: use full IIT calculation.
        """
        # Create synthetic transition matrix from embedding
        n = min(10, len(M_v))
        P = np.outer(M_v[:n], M_v[:n])
        P = np.abs(P)
        P = P / (P.sum(axis=1, keepdims=True) + 1e-8)
        
        # Compute Φ
        phi = self.phi_calculator.compute_phi(P)
        
        return phi
    
    @classmethod
    def from_prompt(cls, prompt: str, **kwargs) -> 'OPrimePipeline':
        """
        Create pipeline from natural language prompt.
        
        Parses intent from prompt and initializes pipeline.
        """
        intent = parse_intent(prompt)
        return cls(intent, **kwargs)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_pipeline(
    context: str = "general",
    scope: float = 0.5,
    goal_statement: str = "",
    state_dim: int = 50
) -> OPrimePipeline:
    """
    Create OPrime pipeline with specified parameters.
    
    Args:
        context: "specific", "general", or "exploratory"
        scope: 0.0 (narrow) to 1.0 (broad)
        goal_statement: Natural language goal
        state_dim: Dimensionality of state space
    
    Returns:
        Configured OPrimePipeline
    """
    intent = IntentConfiguration(
        context=IntentContext(context),
        scope=scope,
        value_statement=goal_statement
    )
    
    return OPrimePipeline(intent, state_dim=state_dim)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'PipelineResult',
    'OPrimePipeline',
    'create_pipeline',
]
