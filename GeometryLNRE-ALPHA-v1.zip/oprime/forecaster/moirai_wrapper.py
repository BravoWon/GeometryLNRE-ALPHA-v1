"""
Universal Forecaster (MOIRAI Wrapper)
=====================================

Implements universal time series forecasting with:
    - Multi-patch projections for cross-frequency learning
    - Any-variate attention for flexible dimensionality
    - Mixture of parametric distributions for uncertainty

This enables OPrime to predict future states across diverse domains.

Intent Alignment:
    - SPECIFIC: Precise forecasting with narrow confidence intervals
    - EXPLORATORY: Probabilistic forecasting with wide intervals
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple, Union
import numpy as np
from abc import ABC, abstractmethod

from ..core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# DISTRIBUTION COMPONENTS
# =============================================================================

@dataclass
class DistributionParams:
    """Parameters for a probability distribution."""
    mean: float
    variance: float
    distribution_type: str = "normal"
    extra_params: Dict[str, float] = field(default_factory=dict)


class MixtureDistribution:
    """
    Mixture of Parametric Distributions.
    
    Combines Normal (low variance), Student's t (fat tails), Log-Normal
    (positive/skewed), and Normal (high variance) for flexible, universal
    probabilistic forecasting.
    
    Note: Currently only supports n_components in {1, 4}.
    """
    
    def __init__(self, n_components: int = 4):
        if n_components not in (1, 4):
            raise ValueError(
                f"n_components must be 1 or 4, got {n_components}. "
                "Only 4-component mixtures (full) or 1-component (single) are supported."
            )
        self.n_components = n_components
        self.weights: List[float] = [1.0 / n_components] * n_components
        self.components: List[DistributionParams] = []
    
    def _validate_weights_components(self):
        """Validate that weights and components have matching lengths."""
        if len(self.weights) != len(self.components):
            raise ValueError(
                f"Weights/components length mismatch: {len(self.weights)} weights "
                f"vs {len(self.components)} components"
            )
    
    def _ensure_fitted(self):
        """Ensure fit() has been called before sampling/quantile operations."""
        if not hasattr(self, 'components') or not self.components:
            raise RuntimeError(
                "MixtureDistribution not fitted: must call fit() before "
                "sample(), quantile(), mean(), or variance()"
            )
    
    def fit(self, data: np.ndarray):
        """
        Fit mixture to data.
        
        Dynamically constructs components based on n_components.
        """
        mean = np.mean(data)
        std = np.std(data) + 1e-8
        
        if self.n_components == 4:
            self.components = [
                # Normal (low variance)
                DistributionParams(mean, std ** 2 * 0.5, "normal"),
                # Student's t (fat tails)
                DistributionParams(mean, std ** 2, "student_t", {"df": 5}),
                # Log-normal (positive, skewed)
                DistributionParams(max(0.1, mean), std ** 2, "lognormal"),
                # Normal (high variance)
                DistributionParams(mean, std ** 2 * 2, "normal_wide"),
            ]
            self.weights = [0.25, 0.25, 0.25, 0.25]
        elif self.n_components == 1:
            self.components = [
                DistributionParams(mean, std ** 2, "normal"),
            ]
            self.weights = [1.0]
        
        # Validate consistency
        self._validate_weights_components()
    
    def sample(self, n_samples: int = 100) -> np.ndarray:
        """Sample from mixture distribution."""
        # Ensure fit() has been called
        self._ensure_fitted()
        # Validate weights/components consistency
        self._validate_weights_components()
        
        samples = []
        
        for _ in range(n_samples):
            # Select component
            component_idx = np.random.choice(
                len(self.components),
                p=self.weights
            )
            params = self.components[component_idx]
            
            # Sample from component
            if params.distribution_type in ["normal", "normal_wide"]:
                sample = np.random.normal(params.mean, np.sqrt(params.variance))
            elif params.distribution_type == "student_t":
                df = params.extra_params.get("df", 5)
                sample = params.mean + np.sqrt(params.variance) * np.random.standard_t(df)
            elif params.distribution_type == "lognormal":
                sigma = np.sqrt(np.log(1 + params.variance / (params.mean ** 2)))
                mu = np.log(params.mean) - 0.5 * sigma ** 2
                sample = np.random.lognormal(mu, sigma)
            else:
                sample = np.random.normal(params.mean, np.sqrt(params.variance))
            
            samples.append(sample)
        
        return np.array(samples)
    
    def mean(self) -> float:
        """Compute mixture mean."""
        self._ensure_fitted()
        return sum(
            w * c.mean 
            for w, c in zip(self.weights, self.components)
        )
    
    def variance(self) -> float:
        """Compute mixture variance."""
        self._ensure_fitted()
        mixture_mean = self.mean()
        return sum(
            w * (c.variance + (c.mean - mixture_mean) ** 2)
            for w, c in zip(self.weights, self.components)
        )
    
    def quantile(self, q: float, n_samples: int = 1000) -> float:
        """Compute quantile via sampling."""
        self._ensure_fitted()
        samples = self.sample(n_samples)
        return np.percentile(samples, q * 100)


# =============================================================================
# MULTI-PATCH PROJECTION
# =============================================================================

class MultiPatchProjection(IntentAlignedOperator):
    """
    Multi-patch projections for cross-frequency learning.
    
    Uses multiple patch sizes to handle varying time series frequencies.
    
    Intent Alignment:
        - SPECIFIC: Fine patches (high resolution)
        - EXPLORATORY: Coarse patches (low resolution, fast)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 patch_sizes: Optional[List[int]] = None):
        super().__init__(intent)
        
        self.patch_sizes = patch_sizes or self._compute_patch_sizes()
    
    def _compute_patch_sizes(self) -> List[int]:
        """Compute patch sizes based on intent."""
        context = self.intent.context
        
        if context == IntentContext.SPECIFIC:
            # Fine resolution
            return [4, 8, 16]
        elif context == IntentContext.GENERAL:
            # Balanced
            return [8, 16, 32]
        else:  # EXPLORATORY
            # Coarse resolution
            return [16, 32, 64]
    
    def project(self, time_series: np.ndarray) -> List[np.ndarray]:
        """
        Project time series at multiple patch sizes.
        
        Returns list of patch embeddings.
        """
        embeddings = []
        
        for patch_size in self.patch_sizes:
            # Ensure divisibility
            length = len(time_series)
            n_patches = max(1, length // patch_size)
            
            # Extract patches
            patches = []
            for i in range(n_patches):
                start = i * patch_size
                end = min(start + patch_size, length)
                patch = time_series[start:end]
                
                # Pad if needed
                if len(patch) < patch_size:
                    patch = np.pad(patch, (0, patch_size - len(patch)))
                
                patches.append(patch)
            
            # Stack and flatten
            if patches:
                patch_embedding = np.concatenate(patches)
            else:
                patch_embedding = np.array([])
            
            embeddings.append(patch_embedding)
        
        return embeddings
    
    def aggregate(self, patch_embeddings: List[np.ndarray]) -> np.ndarray:
        """Aggregate multi-scale patches into single embedding."""
        # Normalize lengths
        max_len = max(len(e) for e in patch_embeddings) if patch_embeddings else 0
        
        aggregated = np.zeros(max_len)
        weight_sum = 0
        
        for i, emb in enumerate(patch_embeddings):
            weight = 1.0 / (i + 1)  # Higher weight for finer patches
            if len(emb) > 0:
                aggregated[:len(emb)] += weight * emb
                weight_sum += weight
        
        if weight_sum > 0:
            aggregated /= weight_sum
        
        return aggregated


# =============================================================================
# ANY-VARIATE ATTENTION
# =============================================================================

class AnyVariateAttention(IntentAlignedOperator):
    """
    Any-variate attention for flexible dimensionality.
    
    Flattens multivariate time series into single sequence,
    using positional encoding to distinguish time vs. variate.
    
    Intent Alignment:
        - SPECIFIC: Focus on primary variates
        - EXPLORATORY: Attend to all variates equally
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 max_variates: int = 100):
        super().__init__(intent)
        
        self.max_variates = max_variates
        self.variate_weights = self._compute_variate_weights()
    
    def _compute_variate_weights(self) -> np.ndarray:
        """Compute attention weights for variates."""
        weights = np.ones(self.max_variates)
        
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            # Decay for later variates
            for i in range(self.max_variates):
                weights[i] = np.exp(-i * 0.1)
        elif context == IntentContext.EXPLORATORY:
            # Uniform weights
            weights = np.ones(self.max_variates)
        
        return weights / weights.sum()
    
    def encode_time(self, t: int, d_model: int = 64) -> np.ndarray:
        """
        Rotary Position Encoding for time axis.
        """
        encoding = np.zeros(d_model)
        for i in range(d_model // 2):
            freq = 1.0 / (10000 ** (2 * i / d_model))
            encoding[2 * i] = np.sin(t * freq)
            encoding[2 * i + 1] = np.cos(t * freq)
        return encoding
    
    def encode_variate(self, v: int, d_model: int = 64) -> np.ndarray:
        """
        Learned binary attention bias for variate axis.
        
        Uses local RNG for thread-safety and reproducibility.
        """
        # Use local generator seeded from variate index (thread-safe)
        rng = np.random.default_rng(v)
        encoding = rng.standard_normal(d_model) * 0.1
        return encoding
    
    def flatten(self, 
                multivariate_ts: np.ndarray,
                d_model: int = 64) -> np.ndarray:
        """
        Flatten multivariate time series to single sequence.
        
        Adds time and variate encodings.
        
        Args:
            multivariate_ts: Input array (1D or 2D)
            d_model: Dimension for time/variate encodings
        
        Raises:
            ValueError: If input contains non-finite values
        """
        # Normalize to numpy array
        multivariate_ts = np.asarray(multivariate_ts)
        
        if multivariate_ts.ndim == 1:
            multivariate_ts = multivariate_ts.reshape(-1, 1)
        
        # Validate finite values before processing
        if not np.isfinite(multivariate_ts).all():
            non_finite_count = np.sum(~np.isfinite(multivariate_ts))
            non_finite_indices = np.argwhere(~np.isfinite(multivariate_ts))
            sample_indices = non_finite_indices[:5].tolist()  # Show first 5
            raise ValueError(
                f"flatten(): input contains {non_finite_count} non-finite values "
                f"(NaN/Inf) in array of shape {multivariate_ts.shape}. "
                f"Sample indices: {sample_indices}"
            )
        
        T, V = multivariate_ts.shape
        V = min(V, self.max_variates)
        
        flattened = []
        
        for t in range(T):
            for v in range(V):
                value = multivariate_ts[t, v]
                time_enc = self.encode_time(t, d_model)
                var_enc = self.encode_variate(v, d_model)
                
                # Combine value with encodings
                combined = np.concatenate([
                    [value * self.variate_weights[v]],
                    time_enc,
                    var_enc
                ])
                flattened.append(combined)
        
        return np.array(flattened)
    
    def compute_attention(self, 
                          sequence: np.ndarray,
                          query: np.ndarray) -> np.ndarray:
        """Compute attention weights."""
        # Validate inputs
        sequence = np.asarray(sequence)
        query = np.asarray(query)
        if sequence.size == 0:
            raise ValueError("sequence must be non-empty")
        if sequence.ndim != 2 or query.ndim != 1 or sequence.shape[1] != query.shape[0]:
            raise ValueError(
                f"Expected sequence shape (N, D) and query shape (D,), "
                f"got sequence {sequence.shape} and query {query.shape}"
            )
        # Simplified dot-product attention
        scores = sequence @ query
        weights = np.exp(scores - np.max(scores))
        weights /= weights.sum()
        return weights


# =============================================================================
# UNIVERSAL FORECASTER
# =============================================================================

class UniversalForecaster(IntentAlignedOperator):
    """
    Universal Time Series Forecaster (MOIRAI-style).
    
    Combines:
        - Multi-patch projections
        - Any-variate attention
        - Mixture distributions
    
    Intent Alignment:
        - SPECIFIC: Point forecasts with narrow intervals
        - EXPLORATORY: Probabilistic forecasts with wide intervals
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 forecast_horizon: int = 10):
        super().__init__(intent)
        
        self.horizon = forecast_horizon
        
        # Components
        self.patch_projection = MultiPatchProjection(intent)
        self.attention = AnyVariateAttention(intent)
        
        # Intent-aligned parameters
        self.confidence_level = self._compute_confidence()
        self.n_samples = self._compute_n_samples()
    
    def _compute_confidence(self) -> float:
        """Compute confidence interval width."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            return 0.9  # Narrow intervals
        elif context == IntentContext.GENERAL:
            return 0.8
        else:  # EXPLORATORY
            return 0.6  # Wide intervals (more uncertainty)
    
    def _compute_n_samples(self) -> int:
        """Compute number of samples for probabilistic forecast."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            return 500
        elif context == IntentContext.GENERAL:
            return 200
        else:  # EXPLORATORY
            return 100
    
    def _validate_history(self, history: Any, min_length: int = 2) -> np.ndarray:
        """
        Validate history input for forecasting.
        
        Args:
            history: Input time series data
            min_length: Minimum required length (default 2 for linear fits)
        
        Returns:
            Validated numpy array
        
        Raises:
            ValueError: If validation fails
        """
        if history is None:
            raise ValueError("history cannot be None")
        
        if not isinstance(history, np.ndarray):
            raise ValueError(
                f"history must be a numpy array, got {type(history).__name__}"
            )
        
        if history.ndim != 1:
            raise ValueError(
                f"history must be 1-dimensional, got {history.ndim} dimensions"
            )
        
        if history.size == 0:
            raise ValueError("history cannot be empty")
        
        if history.size < min_length:
            raise ValueError(
                f"history must have at least {min_length} elements for forecasting, "
                f"got {history.size}"
            )
        
        if np.all(np.isnan(history)):
            raise ValueError("history contains only NaN values")
        
        if np.any(np.isnan(history)):
            raise ValueError(
                f"history contains {np.sum(np.isnan(history))} NaN values; "
                "please handle missing values before forecasting"
            )
        
        return history
    
    def forecast(self,
                 history: np.ndarray,
                 horizon: Optional[int] = None) -> Dict[str, Any]:
        """
        Generate forecast with uncertainty.
        
        Returns dict with point forecast, intervals, and samples.
        
        Args:
            history: 1D numpy array of historical values (min length 2)
            horizon: Forecast horizon (optional, uses default if not provided)
        
        Raises:
            ValueError: If history is invalid (None, wrong type, empty, NaN, etc.)
        """
        # Validate inputs
        history = self._validate_history(history, min_length=2)
        horizon = horizon or self.horizon
        
        # Multi-patch projection
        patches = self.patch_projection.project(history)
        # Note: patches computed for potential future use (e.g., feature extraction)
        _ = self.patch_projection.aggregate(patches)
        
        # Fit mixture distribution
        mixture = MixtureDistribution()
        mixture.fit(history)
        
        # Store baseline statistics from fitted mixture BEFORE any mutations
        baseline_mean = mixture.mean()
        baseline_variance = mixture.variance()
        
        # Generate point forecast (simple trend + seasonal)
        point_forecast = self._generate_point_forecast(history, horizon)
        
        # Generate probabilistic samples using separate step distributions
        # (avoid mutating the fitted mixture)
        samples = np.zeros((self.n_samples, horizon))
        for i in range(horizon):
            base = point_forecast[i]
            # Create per-step distribution without mutating original mixture
            step_variance = baseline_variance * (1 + 0.1 * i)
            step_dist = MixtureDistribution(n_components=1)
            step_dist.components = [DistributionParams(base, step_variance, "normal")]
            step_dist.weights = [1.0]
            samples[:, i] = step_dist.sample(self.n_samples)
        
        # Compute intervals
        lower_q = (1 - self.confidence_level) / 2
        upper_q = 1 - lower_q
        
        lower_bound = np.percentile(samples, lower_q * 100, axis=0)
        upper_bound = np.percentile(samples, upper_q * 100, axis=0)
        
        return {
            "point_forecast": point_forecast,
            "lower_bound": lower_bound,
            "upper_bound": upper_bound,
            "samples": samples,
            "confidence_level": self.confidence_level,
            "mixture_mean": baseline_mean,
            "mixture_variance": baseline_variance
        }
    
    def _generate_point_forecast(self, 
                                  history: np.ndarray,
                                  horizon: int) -> np.ndarray:
        """
        Generate point forecast using trend extrapolation.
        
        Args:
            history: Validated 1D numpy array of historical values
            horizon: Number of steps to forecast
        
        Raises:
            ValueError: If history is invalid
        """
        # Validate inputs (defensive - should already be validated by caller)
        history = self._validate_history(history, min_length=2)
        n = len(history)
        
        # Compute trend (deg is at most 2, requires at least deg+1 points)
        deg = min(2, n - 1)
        x = np.arange(n)
        coeffs = np.polyfit(x, history, deg=deg)
        
        # Extrapolate
        future_x = np.arange(n, n + horizon)
        point_forecast = np.polyval(coeffs, future_x)
        
        # Add mean reversion
        mean_val = np.mean(history)
        reversion_rate = 0.1
        for i in range(horizon):
            point_forecast[i] = (1 - reversion_rate) * point_forecast[i] + reversion_rate * mean_val
        
        return point_forecast
    
    def forecast_multivariate(self,
                               history: np.ndarray,
                               horizon: Optional[int] = None) -> Dict[str, Any]:
        """
        Forecast multivariate time series.
        """
        horizon = horizon or self.horizon
        
        if history.ndim == 1:
            return self.forecast(history, horizon)
        
        n_variates = history.shape[1]
        
        forecasts = []
        for v in range(n_variates):
            forecast = self.forecast(history[:, v], horizon)
            forecasts.append(forecast)
        
        return {
            "variate_forecasts": forecasts,
            "n_variates": n_variates,
            "horizon": horizon
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'AnyVariateAttention',
    'DistributionParams',
    'MixtureDistribution',
    'MultiPatchProjection',
    'UniversalForecaster',
]
