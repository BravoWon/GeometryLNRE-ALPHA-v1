"""
Forecaster Module: Universal Time Series Forecasting
=====================================================

MOIRAI-style universal forecasting with:
- Multi-patch projections for cross-frequency learning
- Any-variate attention for flexible dimensionality
- Mixture of parametric distributions for uncertainty
"""

from .moirai_wrapper import (
    DistributionParams,
    MixtureDistribution,
    MultiPatchProjection,
    AnyVariateAttention,
    UniversalForecaster,
)

__all__ = [
    'DistributionParams',
    'MixtureDistribution',
    'MultiPatchProjection',
    'AnyVariateAttention',
    'UniversalForecaster',
]
