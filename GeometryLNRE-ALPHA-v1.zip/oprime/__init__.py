"""
OPrime: The Neuro-Topological Blueprint for Conscious Agency
=============================================================

A unified architecture synthesizing:
- Configurational Term Series (CTS) — 7-stage consciousness pipeline
- Information-Geometric Valuation Framework (IGVF) — value-warped manifolds
- Symbolic Abstract Neural Search (SANS) — hybrid search
- Novelty Engine — intent-aligned exploration
- Universal Forecaster — time series prediction
- Iron Core Validation — structural integrity

Core Axiom: "Intent warps the manifold, but execution is the key."

Architecture:
- Engine: Unified orchestrator for all components
- Pipeline: 7-stage CTS processing
- Search: MCTS with DSL primitives
- Mapper: TDA regime classification
- Transforms: Teleological warps, regime switches
- Validation: Iron Core integrity checks

Quick Start:
    from oprime import OPrimeEngine, create_engine
    
    # Create engine with preset
    engine = create_engine("balanced")
    
    # Set intent
    engine.set_context("specific", scope=0.3)
    
    # Process data
    result = engine.process(input_data)

Intent Alignment:
    All operations are modulated by IntentConfiguration:
    - context: SPECIFIC | GENERAL | EXPLORATORY
    - scope: 0.0 (narrow) to 1.0 (broad)
    
    This affects search depth, novelty weighting, validation
    strictness, and topological thresholds.
"""

__version__ = "0.2.0"
__author__ = "OPrime Architecture Team"

# Core exports
from .core.intent_alignment import (
    IntentContext,
    IntentConfiguration,
    IntentAlignedOperator,
    IntentPresets,
    parse_intent,
)

# Pipeline
from .pipeline import OPrimePipeline

# Engine
from .engine import (
    OPrimeEngine,
    EngineResult,
    EngineState,
    create_engine,
    quick_process,
)

# Configuration
from .config import (
    OPrimeConfig,
    ConfigPresets,
    load_from_env,
    validate_config,
)

# Logging
from .logging_config import (
    setup_logging,
    PerformanceMonitor,
    IntentLogger,
)

__all__ = [
    # Version
    '__version__',
    
    # Intent
    'IntentContext',
    'IntentConfiguration',
    'IntentAlignedOperator',
    'IntentPresets',
    'parse_intent',
    
    # Engine
    'OPrimeEngine',
    'EngineResult',
    'EngineState',
    'create_engine',
    'quick_process',
    
    # Pipeline
    'OPrimePipeline',
    
    # Configuration
    'OPrimeConfig',
    'ConfigPresets',
    'load_from_env',
    'validate_config',
    
    # Logging
    'setup_logging',
    'PerformanceMonitor',
    'IntentLogger',
]
