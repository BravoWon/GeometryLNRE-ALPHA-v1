"""
SANS V2: Symbolic Abstract Neural Search
=========================================

The "Iron Core" search engine combining:
- MCTS with Progressive Widening
- LLM-guided policy priors
- Continuity Guards for invariant preservation
- Shaped reward functions
- DSL primitives for abstract reasoning
"""

from .mcts_solver import (
    MCTSNode,
    canonical_state_hash,
    ProgressiveWidening,
    ContinuityGuard,
    MCTSSolver,
    ShapedReward,
)

from .dsl_primitives import (
    ArcObject,
    DSLPrimitive,
    DSLRegistry,
    DSLProgram,
    GetObjects,
    PaintObjects,
    Move,
    Rotate,
    FlipHorizontal,
    FlipVertical,
    Recolor,
)

__all__ = [
    # MCTS
    'MCTSNode',
    'canonical_state_hash',
    'ProgressiveWidening',
    'ContinuityGuard',
    'MCTSSolver',
    'ShapedReward',
    # DSL
    'ArcObject',
    'DSLPrimitive',
    'DSLRegistry',
    'DSLProgram',
    'GetObjects',
    'PaintObjects',
    'Move',
    'Rotate',
    'FlipHorizontal',
    'FlipVertical',
    'Recolor',
]
