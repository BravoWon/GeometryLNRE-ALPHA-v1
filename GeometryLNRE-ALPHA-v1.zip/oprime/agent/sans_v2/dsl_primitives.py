"""
DSL Primitives for SANS V2
==========================

Domain-Specific Language for abstract reasoning transformations.

24 primitives organized into 6 functional categories:
    1. Object I/O - Segmentation and painting
    2. Geometric - Rigid body transformations
    3. Symmetry - Manifold folding operations
    4. Color - Semantic property modification
    5. Selection - Filtering operations
    6. Composition - Higher-order functions

All primitives are PURE FUNCTIONS ensuring:
    - Deterministic execution
    - Safe backtracking
    - Immutability preservation

Intent Alignment:
    - SPECIFIC: Precise, minimal transformations
    - EXPLORATORY: Creative, composite transformations
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple, Union
from abc import ABC, abstractmethod
import numpy as np
import copy

from ...core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# ARC OBJECT DATACLASS
# =============================================================================

@dataclass
class ArcObject:
    """
    Represents an object in an ARC grid.
    
    Condition:State representation of a discrete object.
    """
    mask: np.ndarray  # Boolean mask of object pixels
    color: int        # Primary color
    position: Tuple[int, int] = (0, 0)  # Top-left corner
    
    @property
    def size(self) -> int:
        """Number of pixels in object."""
        return int(np.sum(self.mask))
    
    @property
    def bounding_box(self) -> Tuple[int, int, int, int]:
        """Get bounding box (row_min, row_max, col_min, col_max)."""
        rows = np.any(self.mask, axis=1)
        cols = np.any(self.mask, axis=0)
        
        if not np.any(rows) or not np.any(cols):
            return (0, 0, 0, 0)
        
        row_min, row_max = np.where(rows)[0][[0, -1]]
        col_min, col_max = np.where(cols)[0][[0, -1]]
        
        return (int(row_min), int(row_max), int(col_min), int(col_max))
    
    def copy(self) -> 'ArcObject':
        """Create immutable copy."""
        return ArcObject(
            mask=self.mask.copy(),
            color=self.color,
            position=self.position
        )


# =============================================================================
# PRIMITIVE BASE CLASS
# =============================================================================

class DSLPrimitive(ABC):
    """
    Abstract base for DSL primitives.
    
    All primitives must be:
        1. Pure functions (no side effects)
        2. Deterministic
        3. Immutable (copy-on-write)
    """
    
    name: str = "base"
    category: str = "base"
    
    @abstractmethod
    def apply(self, grid: Union[np.ndarray, List[Any]], *args, **kwargs) -> Union[np.ndarray, List[Any]]:
        """Apply primitive to grid or object list."""
        pass
    
    def __call__(self, grid: Union[np.ndarray, List[Any]], *args, **kwargs) -> Union[np.ndarray, List[Any]]:
        """
        Apply primitive with immutability guarantee.
        
        Handles both numpy arrays and lists of objects.
        """
        # Ensure immutability based on input type
        if isinstance(grid, np.ndarray):
            grid_copy = grid.copy()
        elif isinstance(grid, list):
            grid_copy = copy.deepcopy(grid)
        else:
            raise TypeError(
                f"Expected np.ndarray or list, got {type(grid).__name__}"
            )
        return self.apply(grid_copy, *args, **kwargs)


# =============================================================================
# CATEGORY 1: OBJECT I/O
# =============================================================================

class GetObjects(DSLPrimitive):
    """Extract objects from grid via connected component analysis."""
    
    name = "get_objects"
    category = "object_io"
    
    def apply(self, grid: np.ndarray, background: int = 0) -> List[ArcObject]:
        """Segment grid into objects."""
        objects = []
        visited = np.zeros_like(grid, dtype=bool)
        
        for i in range(grid.shape[0]):
            for j in range(grid.shape[1]):
                if grid[i, j] != background and not visited[i, j]:
                    # BFS to find connected component
                    mask = np.zeros_like(grid, dtype=bool)
                    color = grid[i, j]
                    queue = [(i, j)]
                    
                    while queue:
                        r, c = queue.pop(0)
                        if (0 <= r < grid.shape[0] and 
                            0 <= c < grid.shape[1] and
                            not visited[r, c] and 
                            grid[r, c] == color):
                            
                            visited[r, c] = True
                            mask[r, c] = True
                            
                            queue.extend([
                                (r+1, c), (r-1, c),
                                (r, c+1), (r, c-1)
                            ])
                    
                    objects.append(ArcObject(
                        mask=mask,
                        color=int(color),
                        position=(i, j)
                    ))
        
        return objects


class PaintObjects(DSLPrimitive):
    """Paint objects back onto grid."""
    
    name = "paint_objects"
    category = "object_io"
    
    def apply(self, grid: np.ndarray, objects: List[ArcObject], 
              background: int = 0) -> np.ndarray:
        """Paint objects onto grid."""
        result = np.full_like(grid, background)
        
        for obj in objects:
            result[obj.mask] = obj.color
        
        return result


# =============================================================================
# CATEGORY 2: GEOMETRIC
# =============================================================================

class Move(DSLPrimitive):
    """Move object by offset."""
    
    name = "move"
    category = "geometric"
    
    def apply(self, grid: np.ndarray, 
              dr: int = 0, dc: int = 0, background: int = 0) -> np.ndarray:
        """
        Translate grid content.
        
        Args:
            grid: Input grid
            dr: Row offset (positive = move down)
            dc: Column offset (positive = move right)
            background: Value to fill untouched cells (default 0)
        
        Returns:
            Translated grid with background filling empty regions
        """
        result = np.full_like(grid, background)
        
        for i in range(grid.shape[0]):
            for j in range(grid.shape[1]):
                ni, nj = i - dr, j - dc
                if 0 <= ni < grid.shape[0] and 0 <= nj < grid.shape[1]:
                    result[i, j] = grid[ni, nj]
        
        return result


class Rotate(DSLPrimitive):
    """Rotate grid by 90 degrees."""
    
    name = "rotate"
    category = "geometric"
    
    def apply(self, grid: np.ndarray, times: int = 1) -> np.ndarray:
        """Rotate grid 90 degrees clockwise (times) times."""
        result = grid.copy()
        for _ in range(times % 4):
            result = np.rot90(result, k=-1)
        return result


class Scale(DSLPrimitive):
    """Scale grid by factor."""
    
    name = "scale"
    category = "geometric"
    
    def apply(self, grid: np.ndarray, factor: int = 2) -> np.ndarray:
        """Scale grid by integer factor."""
        # Validate factor argument
        if not isinstance(factor, int):
            raise TypeError(
                f"factor must be a positive integer, got {type(factor).__name__}"
            )
        if factor <= 0:
            raise ValueError(
                f"factor must be a positive integer (> 0), got {factor}"
            )
        
        h, w = grid.shape
        result = np.zeros((h * factor, w * factor), dtype=grid.dtype)
        
        for i in range(h):
            for j in range(w):
                result[i*factor:(i+1)*factor, j*factor:(j+1)*factor] = grid[i, j]
        
        return result


# =============================================================================
# CATEGORY 3: SYMMETRY
# =============================================================================

class FlipHorizontal(DSLPrimitive):
    """Flip grid horizontally."""
    
    name = "flip_h"
    category = "symmetry"
    
    def apply(self, grid: np.ndarray) -> np.ndarray:
        """Flip left-right."""
        return np.fliplr(grid.copy())


class FlipVertical(DSLPrimitive):
    """Flip grid vertically."""
    
    name = "flip_v"
    category = "symmetry"
    
    def apply(self, grid: np.ndarray) -> np.ndarray:
        """Flip top-bottom."""
        return np.flipud(grid.copy())


class Transpose(DSLPrimitive):
    """Transpose grid."""
    
    name = "transpose"
    category = "symmetry"
    
    def apply(self, grid: np.ndarray) -> np.ndarray:
        """Transpose (swap rows and columns)."""
        return grid.T.copy()


# =============================================================================
# CATEGORY 4: COLOR
# =============================================================================

class Recolor(DSLPrimitive):
    """Change color of pixels."""
    
    name = "recolor"
    category = "color"
    
    def apply(self, grid: np.ndarray, 
              from_color: int, to_color: int) -> np.ndarray:
        """Replace one color with another."""
        result = grid.copy()
        result[grid == from_color] = to_color
        return result


class FillColor(DSLPrimitive):
    """Fill region with color."""
    
    name = "fill_color"
    category = "color"
    
    def apply(self, grid: np.ndarray, 
              row: int, col: int, color: int) -> np.ndarray:
        """Flood fill from position."""
        result = grid.copy()
        
        # Validate bounds before accessing grid
        if not (0 <= row < grid.shape[0] and 0 <= col < grid.shape[1]):
            raise ValueError(
                f"row/col out of bounds: ({row}, {col}) for grid shape {grid.shape}"
            )
        
        original = grid[row, col]
        
        if original == color:
            return result
        
        queue = [(row, col)]
        visited = set()
        
        while queue:
            r, c = queue.pop(0)
            if (r, c) in visited:
                continue
            
            if (0 <= r < grid.shape[0] and 
                0 <= c < grid.shape[1] and
                result[r, c] == original):
                
                result[r, c] = color
                visited.add((r, c))
                queue.extend([(r+1, c), (r-1, c), (r, c+1), (r, c-1)])
        
        return result


# =============================================================================
# CATEGORY 5: SELECTION
# =============================================================================

class SelectBySize(DSLPrimitive):
    """Select objects by size."""
    
    name = "select_size"
    category = "selection"
    
    def apply(self, objects: List[ArcObject], 
              min_size: int = 0, 
              max_size: int = float('inf')) -> List[ArcObject]:
        """Filter objects by size."""
        return [obj for obj in objects 
                if min_size <= obj.size <= max_size]


class SelectByColor(DSLPrimitive):
    """Select objects by color."""
    
    name = "select_color"
    category = "selection"
    
    def apply(self, objects: List[ArcObject], 
              color: int) -> List[ArcObject]:
        """Filter objects by color."""
        return [obj for obj in objects if obj.color == color]


class SelectLargest(DSLPrimitive):
    """Select largest object."""
    
    name = "select_largest"
    category = "selection"
    
    def apply(self, objects: List[ArcObject]) -> Optional[ArcObject]:
        """Return largest object by pixel count."""
        if not objects:
            return None
        return max(objects, key=lambda o: o.size)


# =============================================================================
# CATEGORY 6: COMPOSITION
# =============================================================================

class MapFunction(DSLPrimitive):
    """Apply function to each object."""
    
    name = "map_fn"
    category = "composition"
    
    def apply(self, objects: List[ArcObject], 
              fn: Callable[[ArcObject], ArcObject]) -> List[ArcObject]:
        """Map function over objects."""
        return [fn(obj.copy()) for obj in objects]


class Compose(DSLPrimitive):
    """Compose multiple primitives."""
    
    name = "compose"
    category = "composition"
    
    def apply(self, grid: np.ndarray, 
              primitives: List[DSLPrimitive]) -> np.ndarray:
        """Apply primitives in sequence."""
        result = grid.copy()
        for prim in primitives:
            result = prim(result)
        return result


class FilterBy(DSLPrimitive):
    """Filter objects by predicate."""
    
    name = "filter_by"
    category = "composition"
    
    def apply(self, objects: List[ArcObject],
              predicate: Callable[[ArcObject], bool]) -> List[ArcObject]:
        """Filter objects by predicate function."""
        return [obj for obj in objects if predicate(obj)]


# =============================================================================
# DSL REGISTRY
# =============================================================================

class DSLRegistry(IntentAlignedOperator):
    """
    Registry of all DSL primitives.
    
    Intent Alignment:
        - SPECIFIC: Use basic primitives
        - EXPLORATORY: Enable composition and advanced primitives
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # Register all primitives
        self.primitives: Dict[str, DSLPrimitive] = {
            # Object I/O
            "get_objects": GetObjects(),
            "paint_objects": PaintObjects(),
            # Geometric
            "move": Move(),
            "rotate": Rotate(),
            "scale": Scale(),
            # Symmetry
            "flip_h": FlipHorizontal(),
            "flip_v": FlipVertical(),
            "transpose": Transpose(),
            # Color
            "recolor": Recolor(),
            "fill_color": FillColor(),
            # Selection
            "select_size": SelectBySize(),
            "select_color": SelectByColor(),
            "select_largest": SelectLargest(),
            # Composition
            "map_fn": MapFunction(),
            "compose": Compose(),
            "filter_by": FilterBy(),
        }
        
        # Intent-aligned primitive availability
        self.available = self._compute_available()
    
    def _compute_available(self) -> List[str]:
        """Compute available primitives based on intent."""
        context = self.intent.context
        
        # Basic primitives always available
        basic = [
            "get_objects", "paint_objects",
            "move", "rotate", "flip_h", "flip_v",
            "recolor", "select_color"
        ]
        
        if context == IntentContext.SPECIFIC:
            return basic
        
        # Add more for general
        general = basic + [
            "scale", "transpose", "fill_color",
            "select_size", "select_largest"
        ]
        
        if context == IntentContext.GENERAL:
            return general
        
        # All for exploratory
        return list(self.primitives.keys())
    
    def get(self, name: str) -> Optional[DSLPrimitive]:
        """Get primitive by name if available."""
        if name in self.available:
            return self.primitives.get(name)
        return None
    
    def list_available(self) -> List[str]:
        """List available primitive names."""
        return self.available.copy()
    
    def apply(self, name: str, *args, **kwargs) -> Any:
        """Apply primitive by name."""
        prim = self.get(name)
        if prim is None:
            raise ValueError(f"Primitive '{name}' not available for {self.intent.context.value} intent")
        return prim(*args, **kwargs)


# =============================================================================
# PROGRAM REPRESENTATION
# =============================================================================

@dataclass
class DSLProgram:
    """
    Represents a program as a sequence of DSL operations.
    
    Supports both grid-only and object-list pipelines via environment resolution.
    Use "$grid" and "$objects" tokens in kwargs to reference environment values.
    """
    steps: List[Tuple[str, Dict[str, Any]]] = field(default_factory=list)
    
    def add(self, primitive_name: str, **kwargs):
        """Add step to program."""
        self.steps.append((primitive_name, kwargs))
    
    def execute(self, grid: np.ndarray, registry: DSLRegistry) -> np.ndarray:
        """
        Execute program on grid.
        
        Maintains an environment dict to support type transitions between
        grid (np.ndarray) and object-list (List[ArcObject]) primitives.
        """
        # Initialize environment with grid and empty objects
        env = {
            'grid': grid.copy(),
            'objects': None,
            'result': grid.copy()  # Current pipeline result
        }
        
        for name, kwargs in self.steps:
            prim = registry.get(name)
            if prim:
                # Resolve kwargs tokens like "$grid" and "$objects"
                resolved_kwargs = self._resolve_kwargs(kwargs, env)
                
                # Execute primitive with current result
                result = prim(env['result'], **resolved_kwargs)
                
                # Update environment based on return type
                if isinstance(result, np.ndarray):
                    env['grid'] = result
                    env['result'] = result
                elif isinstance(result, list):
                    env['objects'] = result
                    env['result'] = result
                else:
                    env['result'] = result
        
        # Return final grid (or last result if it's an array)
        return env['grid'] if isinstance(env['grid'], np.ndarray) else env['result']
    
    def _resolve_kwargs(self, kwargs: Dict[str, Any], 
                        env: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve environment tokens in kwargs."""
        resolved = {}
        for key, value in kwargs.items():
            if isinstance(value, str):
                if value == "$grid":
                    resolved[key] = env['grid']
                elif value == "$objects":
                    resolved[key] = env['objects']
                else:
                    resolved[key] = value
            else:
                resolved[key] = value
        return resolved
    
    def to_string(self) -> str:
        """Convert to string representation."""
        lines = []
        for name, kwargs in self.steps:
            args_str = ", ".join(f"{k}={v}" for k, v in kwargs.items())
            lines.append(f"{name}({args_str})")
        return " -> ".join(lines)
    
    @classmethod
    def from_string(cls, program_str: str) -> 'DSLProgram':
        """
        Parse from string representation with full round-trip support.
        
        Parses step names and kwargs from format: "name(k1=v1, k2=v2) -> ..."
        """
        import ast
        
        program = cls()
        if not program_str.strip():
            return program
        
        steps = program_str.split(" -> ")
        for step in steps:
            step = step.strip()
            if not step:
                continue
            
            if "(" in step and step.endswith(")"):
                # Extract name and args
                paren_idx = step.index("(")
                name = step[:paren_idx].strip()
                args_str = step[paren_idx + 1:-1].strip()
                
                kwargs = {}
                if args_str:
                    # Parse key=value pairs
                    # Handle nested structures by tracking brackets
                    pairs = cls._split_args(args_str)
                    for pair in pairs:
                        pair = pair.strip()
                        if "=" not in pair:
                            continue
                        eq_idx = pair.index("=")
                        key = pair[:eq_idx].strip()
                        value_str = pair[eq_idx + 1:].strip()
                        
                        # Try to parse literal value
                        try:
                            value = ast.literal_eval(value_str)
                        except (ValueError, SyntaxError):
                            # Keep as string if not a valid literal
                            value = value_str
                        
                        kwargs[key] = value
                
                program.add(name, **kwargs)
            elif step:
                # No parentheses - just a name
                program.add(step.strip())
        
        return program
    
    @staticmethod
    def _split_args(args_str: str) -> List[str]:
        """Split argument string by commas, respecting brackets."""
        result = []
        current = []
        depth = 0
        
        for char in args_str:
            if char in "([{":
                depth += 1
                current.append(char)
            elif char in ")]}":
                depth -= 1
                current.append(char)
            elif char == "," and depth == 0:
                result.append("".join(current))
                current = []
            else:
                current.append(char)
        
        if current:
            result.append("".join(current))
        
        return result


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'ArcObject',
    'Compose',
    'DSLPrimitive',
    'DSLProgram',
    'DSLRegistry',
    'FillColor',
    'FilterBy',
    'FlipHorizontal',
    'FlipVertical',
    'GetObjects',
    'MapFunction',
    'Move',
    'PaintObjects',
    'Recolor',
    'Rotate',
    'Scale',
    'SelectByColor',
    'SelectBySize',
    'SelectLargest',
    'Transpose',
]
