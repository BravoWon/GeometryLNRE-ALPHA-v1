"""
SANS V2: MCTS Solver (The Conscious Operator)
==============================================

Monte Carlo Tree Search enhanced with:
    - Progressive Widening (intent-aligned branching)
    - LLM-guided policy priors
    - Beam Rollouts for deep lookahead
    - Continuity Guards for invariant preservation

This is the "search" component of OPrime — navigating the
solution manifold while respecting topological constraints.

Intent Alignment:
    - SPECIFIC: Deep, focused search (narrow beam)
    - EXPLORATORY: Wide, diverse search (broad beam)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple, Set
from collections import defaultdict
import numpy as np
import math
import hashlib

from ...core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# NODE & STATE REPRESENTATIONS
# =============================================================================

@dataclass
class MCTSNode:
    """Node in the MCTS search tree."""
    state: Any
    parent: Optional['MCTSNode'] = None
    action: Optional[Any] = None
    
    # Statistics
    visit_count: int = 0
    value_sum: float = 0.0
    
    # Children
    children: Dict[Any, 'MCTSNode'] = field(default_factory=dict)
    untried_actions: List[Any] = field(default_factory=list)
    
    # Policy prior (from LLM)
    prior: float = 1.0
    
    # Validity flag
    is_valid: bool = True
    
    @property
    def value(self) -> float:
        """Average value of this node."""
        if self.visit_count == 0:
            return 0.0
        return self.value_sum / self.visit_count
    
    @property
    def ucb_score(self) -> float:
        """Upper Confidence Bound score for selection."""
        if self.visit_count == 0:
            return float('inf')
        
        exploitation = self.value
        exploration = math.sqrt(2 * math.log(self.parent.visit_count + 1) / self.visit_count)
        
        return exploitation + exploration * self.prior
    
    def is_leaf(self) -> bool:
        """Check if node is a leaf (no children)."""
        return len(self.children) == 0
    
    def is_terminal(self) -> bool:
        """Check if node represents terminal state."""
        return len(self.untried_actions) == 0 and len(self.children) == 0


def canonical_state_hash(state: Any) -> str:
    """
    Compute canonical hash for state.
    
    Critical: Prevents hash collisions that corrupt memory.
    """
    if isinstance(state, np.ndarray):
        return hashlib.sha256(state.tobytes()).hexdigest()
    elif isinstance(state, (list, tuple)):
        return hashlib.sha256(str(sorted(str(s) for s in state)).encode()).hexdigest()
    else:
        return hashlib.sha256(str(state).encode()).hexdigest()


# =============================================================================
# PROGRESSIVE WIDENING
# =============================================================================

class ProgressiveWidening(IntentAlignedOperator):
    """
    Progressive Widening with LLM-guided priority.
    
    Controls branching factor: max_children = k * visit_count^α
    
    Intent Alignment:
        - SPECIFIC: Low k, high α (focused search)
        - EXPLORATORY: High k, low α (diverse search)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 k: float = 1.0,
                 alpha: float = 0.5):
        super().__init__(intent)
        
        # Adjust parameters based on intent
        self.k = self._compute_k(k)
        self.alpha = self._compute_alpha(alpha)
    
    def _compute_k(self, base_k: float) -> float:
        """Compute widening coefficient k."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            multiplier = 0.5
        elif context == IntentContext.GENERAL:
            multiplier = 1.0
        else:  # EXPLORATORY
            multiplier = 2.0
        
        return base_k * multiplier * (0.5 + self.intent.scope)
    
    def _compute_alpha(self, base_alpha: float) -> float:
        """Compute widening exponent α."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            multiplier = 1.2
        elif context == IntentContext.GENERAL:
            multiplier = 1.0
        else:  # EXPLORATORY
            multiplier = 0.7
        
        return base_alpha * multiplier
    
    def max_children(self, visit_count: int) -> int:
        """Compute maximum children allowed."""
        return max(1, int(self.k * (visit_count ** self.alpha)))
    
    def should_expand(self, node: MCTSNode) -> bool:
        """Check if node should be expanded."""
        max_c = self.max_children(node.visit_count)
        return len(node.children) < max_c and len(node.untried_actions) > 0
    
    def select_action_to_expand(self,
                                 node: MCTSNode,
                                 action_priors: Dict[Any, float]) -> Optional[Any]:
        """
        Select next action to expand, prioritized by LLM prior.
        """
        if not node.untried_actions:
            return None
        
        # Sort by prior (highest first)
        sorted_actions = sorted(
            node.untried_actions,
            key=lambda a: action_priors.get(a, 0.5),
            reverse=True
        )
        
        return sorted_actions[0]


# =============================================================================
# CONTINUITY GUARD (Invariant Validator)
# =============================================================================

class ContinuityGuard(IntentAlignedOperator):
    """
    Continuity Guard for pruning invalid transformations.
    
    Validates that actions preserve topological invariants:
        - Mass conservation
        - Object non-overlap
        - Boundary constraints
    
    Intent Alignment:
        - SPECIFIC: Strict validation (all invariants)
        - EXPLORATORY: Lenient validation (critical only)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 invariants: Optional[List[Callable]] = None):
        super().__init__(intent)
        
        self.invariants = invariants or []
        self.strictness = self._compute_strictness()
        
        # Statistics
        self.pruned_count = 0
        self.validated_count = 0
    
    def _compute_strictness(self) -> float:
        """Compute validation strictness."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 1.0
        elif context == IntentContext.GENERAL:
            base = 0.7
        else:  # EXPLORATORY
            base = 0.4
        
        return base * (1.0 - 0.3 * self.intent.scope)
    
    def add_invariant(self, invariant: Callable[[Any, Any, Any], bool]):
        """Add an invariant checker."""
        self.invariants.append(invariant)
    
    def validate(self,
                 state: Any,
                 action: Any,
                 next_state: Any) -> bool:
        """
        Validate that transformation preserves invariants.
        
        Uses STRICT immutability — never modifies actual state.
        """
        # Basic validity check
        if next_state is None:
            self.pruned_count += 1
            return False
        
        # Apply invariants based on strictness
        n_to_check = max(1, int(len(self.invariants) * self.strictness))
        invariants_to_check = self.invariants[:n_to_check]
        
        for invariant in invariants_to_check:
            try:
                if not invariant(state, action, next_state):
                    self.pruned_count += 1
                    return False
            except Exception:
                # Invariant check failed — conservative rejection
                self.pruned_count += 1
                return False
        
        self.validated_count += 1
        return True
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get validation statistics."""
        total = self.pruned_count + self.validated_count
        return {
            "pruned": self.pruned_count,
            "validated": self.validated_count,
            "prune_rate": self.pruned_count / total if total > 0 else 0
        }


# =============================================================================
# MCTS SOLVER
# =============================================================================

class MCTSSolver(IntentAlignedOperator):
    """
    MCTS Solver: The Conscious Operator.
    
    Performs search over the manifold of potential solutions
    using Monte Carlo Tree Search with:
        - Progressive Widening
        - LLM-guided priors
        - Continuity Guards
        - Beam Rollouts
    
    Intent Alignment affects:
        - Search depth and breadth
        - Exploration vs exploitation balance
        - Pruning strictness
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 action_generator: Callable[[Any], List[Any]],
                 dynamics: Callable[[Any, Any], Any],
                 reward_fn: Callable[[Any], float],
                 terminal_fn: Callable[[Any], bool],
                 llm_policy: Optional[Callable[[Any], Dict[Any, float]]] = None):
        super().__init__(intent)
        
        # Core functions
        self.action_generator = action_generator
        self.dynamics = dynamics
        self.reward_fn = reward_fn
        self.terminal_fn = terminal_fn
        self.llm_policy = llm_policy or (lambda s: {})
        
        # Components
        self.widening = ProgressiveWidening(intent)
        self.guard = ContinuityGuard(intent)
        
        # Search parameters from intent
        self.exploration_constant = self._compute_exploration()
        self.max_depth = self._compute_max_depth()
        self.beam_width = self._compute_beam_width()
        
        # State cache (prevents hash collisions)
        self.state_cache: Dict[str, Any] = {}
        
        # Statistics
        self.nodes_expanded = 0
        self.simulations_run = 0
    
    def _compute_exploration(self) -> float:
        """Compute exploration constant C_p."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.5
        elif context == IntentContext.GENERAL:
            base = 1.0
        else:  # EXPLORATORY
            base = 2.0
        
        return base * (0.5 + self.intent.scope)
    
    def _compute_max_depth(self) -> int:
        """Compute maximum search depth."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 50
        elif context == IntentContext.GENERAL:
            base = 30
        else:  # EXPLORATORY
            base = 20
        
        return int(base * (1.0 - 0.3 * self.intent.scope))
    
    def _compute_beam_width(self) -> int:
        """Compute beam width for rollouts."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 3
        elif context == IntentContext.GENERAL:
            base = 5
        else:  # EXPLORATORY
            base = 8
        
        return int(base * (0.5 + self.intent.scope))
    
    def solve(self,
              initial_state: Any,
              n_iterations: int = 1000,
              time_limit: Optional[float] = None) -> Tuple[List[Any], float]:
        """
        Run MCTS to find solution.
        
        Returns (action_sequence, best_value).
        """
        import time
        start_time = time.time()
        
        # Create root node
        root = MCTSNode(state=initial_state)
        root.untried_actions = self.action_generator(initial_state)
        
        for iteration in range(n_iterations):
            # Check time limit
            if time_limit and (time.time() - start_time) > time_limit:
                break
            
            # Selection
            node = self._select(root)
            
            # Expansion
            if not node.is_terminal() and self.widening.should_expand(node):
                node = self._expand(node)
            
            # Simulation (Rollout)
            value = self._simulate(node)
            
            # Backpropagation
            self._backpropagate(node, value)
            
            self.simulations_run += 1
        
        # Extract best path
        return self._extract_solution(root)
    
    def _select(self, node: MCTSNode) -> MCTSNode:
        """Select leaf node using UCB."""
        while not node.is_leaf() and not self.terminal_fn(node.state):
            # Select child with highest UCB
            best_child = max(
                node.children.values(),
                key=lambda c: c.ucb_score
            )
            node = best_child
        
        return node
    
    def _expand(self, node: MCTSNode) -> MCTSNode:
        """Expand node with new child."""
        # Get LLM priors
        priors = self.llm_policy(node.state)
        
        # Select action to expand
        action = self.widening.select_action_to_expand(node, priors)
        
        if action is None:
            return node
        
        # Remove from untried
        node.untried_actions.remove(action)
        
        # Apply dynamics
        next_state = self.dynamics(node.state, action)
        
        # Validate with continuity guard
        if not self.guard.validate(node.state, action, next_state):
            return node  # Invalid — don't expand
        
        # Create child node
        child = MCTSNode(
            state=next_state,
            parent=node,
            action=action,
            prior=priors.get(action, 0.5)
        )
        child.untried_actions = self.action_generator(next_state)
        
        # Add to children
        node.children[action] = child
        
        self.nodes_expanded += 1
        
        return child
    
    def _simulate(self, node: MCTSNode, depth: int = 0) -> float:
        """
        Simulate (rollout) from node.
        
        Uses beam rollout for stability.
        """
        if self.terminal_fn(node.state) or depth >= self.max_depth:
            return self.reward_fn(node.state)
        
        state = node.state
        total_reward = 0.0
        discount = 0.99
        
        for step in range(self.max_depth - depth):
            if self.terminal_fn(state):
                break
            
            # Get actions and priors
            actions = self.action_generator(state)
            if not actions:
                break
            
            priors = self.llm_policy(state)
            
            # Select action (weighted by prior)
            action_weights = [priors.get(a, 0.1) for a in actions]
            total_weight = sum(action_weights)
            if total_weight > 0:
                action_weights = [w / total_weight for w in action_weights]
            else:
                action_weights = [1.0 / len(actions)] * len(actions)
            
            action = np.random.choice(len(actions), p=action_weights)
            action = actions[action]
            
            # Apply dynamics
            next_state = self.dynamics(state, action)
            
            # Check validity
            if not self.guard.validate(state, action, next_state):
                break
            
            # Accumulate reward
            reward = self.reward_fn(next_state)
            total_reward += (discount ** step) * reward
            
            state = next_state
        
        return total_reward
    
    def _backpropagate(self, node: MCTSNode, value: float):
        """Backpropagate value up the tree."""
        while node is not None:
            node.visit_count += 1
            node.value_sum += value
            node = node.parent
    
    def _extract_solution(self, root: MCTSNode) -> Tuple[List[Any], float]:
        """Extract best action sequence from tree."""
        actions = []
        node = root
        
        while node.children:
            # Select most-visited child
            best_child = max(
                node.children.items(),
                key=lambda x: x[1].visit_count
            )
            actions.append(best_child[0])
            node = best_child[1]
        
        best_value = node.value if node.visit_count > 0 else 0.0
        
        return actions, best_value
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get solver statistics."""
        return {
            "nodes_expanded": self.nodes_expanded,
            "simulations_run": self.simulations_run,
            "guard_stats": self.guard.get_statistics(),
            "exploration_constant": self.exploration_constant,
            "max_depth": self.max_depth,
            "beam_width": self.beam_width
        }


# =============================================================================
# SHAPED REWARD FUNCTIONS
# =============================================================================

class ShapedReward(IntentAlignedOperator):
    """
    Shaped reward function for MCTS.
    
    Combines:
        - Goal proximity (exploitation)
        - Novelty bonus (exploration)
        - Validity penalty
    
    Intent Alignment:
        - SPECIFIC: High goal weight
        - EXPLORATORY: High novelty weight
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 goal_fn: Callable[[Any], float],
                 novelty_fn: Optional[Callable[[Any], float]] = None):
        super().__init__(intent)
        
        self.goal_fn = goal_fn
        self.novelty_fn = novelty_fn
        
        # Weights from intent
        self.goal_weight = self._compute_goal_weight()
        self.novelty_weight = self._compute_novelty_weight()
    
    def _compute_goal_weight(self) -> float:
        """Compute goal reward weight."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.9
        elif context == IntentContext.GENERAL:
            base = 0.6
        else:  # EXPLORATORY
            base = 0.3
        
        return base * (1.0 - 0.3 * self.intent.scope)
    
    def _compute_novelty_weight(self) -> float:
        """Compute novelty reward weight."""
        return 1.0 - self.goal_weight
    
    def compute(self, state: Any) -> float:
        """Compute shaped reward."""
        goal_reward = self.goal_fn(state)
        
        if self.novelty_fn:
            novelty_reward = self.novelty_fn(state)
        else:
            novelty_reward = 0.0
        
        return (
            self.goal_weight * goal_reward +
            self.novelty_weight * novelty_reward
        )


# =============================================================================
# BEAM-CONTINUITY FILTER (B_cont Integration)
# =============================================================================

class BeamContinuityFilter(IntentAlignedOperator):
    """
    B_cont: Fuse MOIRAI-style probabilistic beam search with SANS continuity guards.
    
    Projects a "beam" of future states and applies continuity guards to the
    entire beam. If the density of valid states in the beam drops below a
    threshold, prune the root.
    
    Effect: "Deep Lookahead" intuition. Prunes paths that look valid now but
    lead to topological violations 10+ steps later ("checkmate" scenarios).
    
    This transform emerges from the synthesis of:
    - MOIRAI universal forecasting (probabilistic beams)
    - SANS continuity guards (invariant preservation)
    - IGVF value geometry (value-guided pruning)
    
    Intent Alignment:
        - SPECIFIC: Deep lookahead, strict validity
        - EXPLORATORY: Shallow lookahead, lenient validity
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 continuity_guard: Optional['ContinuityGuard'] = None,
                 beam_width: int = 5,
                 lookahead_depth: int = 10):
        super().__init__(intent)
        
        self.guard = continuity_guard or ContinuityGuard(intent)
        self.beam_width = self._compute_beam_width(beam_width)
        self.lookahead_depth = self._compute_lookahead_depth(lookahead_depth)
        
        # Validity threshold from intent
        self.validity_threshold = self._compute_validity_threshold()
        
        # Statistics
        self.beams_evaluated = 0
        self.roots_pruned = 0
    
    def _compute_beam_width(self, base_width: int) -> int:
        """Compute beam width based on intent."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            multiplier = 0.5  # Narrow beam, focused
        elif context == IntentContext.GENERAL:
            multiplier = 1.0
        else:  # EXPLORATORY
            multiplier = 1.5  # Wide beam, diverse
        
        return max(2, int(base_width * multiplier * (0.5 + self.intent.scope)))
    
    def _compute_lookahead_depth(self, base_depth: int) -> int:
        """Compute lookahead depth based on intent."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            multiplier = 1.5  # Deep lookahead for precision
        elif context == IntentContext.GENERAL:
            multiplier = 1.0
        else:  # EXPLORATORY
            multiplier = 0.5  # Shallow for speed
        
        return max(3, int(base_depth * multiplier * (1.0 - 0.3 * self.intent.scope)))
    
    def _compute_validity_threshold(self) -> float:
        """Compute minimum valid state density in beam."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            return 0.8  # Most states must be valid
        elif context == IntentContext.GENERAL:
            return 0.5
        else:  # EXPLORATORY
            return 0.3  # Allow exploration of risky paths
    
    def project_beam(self,
                     current_state: Any,
                     dynamics_fn: Callable[[Any, Any], Any],
                     action_generator: Callable[[Any], List[Any]],
                     value_fn: Optional[Callable[[Any], float]] = None
                     ) -> List[List[Tuple[Any, Any]]]:
        """
        Project beam of future trajectories.
        
        Returns list of trajectories, each trajectory is a list of (state, action) pairs.
        """
        beams = []
        
        for _ in range(self.beam_width):
            trajectory = []
            state = current_state
            
            for step in range(self.lookahead_depth):
                # Get available actions
                actions = action_generator(state)
                if not actions:
                    break
                
                # Select action (value-guided if available)
                if value_fn:
                    # Score actions by resulting value
                    action_scores = []
                    for action in actions:
                        try:
                            next_state = dynamics_fn(state, action)
                            if next_state is not None:
                                score = value_fn(next_state)
                            else:
                                score = float('-inf')
                        except Exception:
                            score = float('-inf')
                        action_scores.append((action, score))
                    
                    # Sample from top actions with some randomness
                    action_scores.sort(key=lambda x: x[1], reverse=True)
                    top_k = min(3, len(action_scores))
                    idx = np.random.randint(0, top_k)
                    action = action_scores[idx][0]
                else:
                    # Random action
                    action = actions[np.random.randint(0, len(actions))]
                
                # Apply dynamics
                try:
                    next_state = dynamics_fn(state, action)
                    if next_state is None:
                        break
                except Exception:
                    break
                
                trajectory.append((state, action))
                state = next_state
            
            if trajectory:
                beams.append(trajectory)
        
        self.beams_evaluated += len(beams)
        return beams
    
    def evaluate_beam_validity(self,
                                beams: List[List[Tuple[Any, Any]]]) -> List[float]:
        """
        Evaluate validity of each beam trajectory.
        
        Returns validity scores (fraction of valid transitions).
        """
        scores = []
        
        for trajectory in beams:
            if not trajectory:
                scores.append(0.0)
                continue
            
            valid_count = 0
            for state, action in trajectory:
                # Use guard's validate method
                # Create a dummy "next state" by applying action conceptually
                if self.guard.validate(state, action, state):  # Simplified check
                    valid_count += 1
            
            scores.append(valid_count / len(trajectory) if trajectory else 0.0)
        
        return scores
    
    def should_prune_root(self,
                          current_state: Any,
                          action: Any,
                          dynamics_fn: Callable[[Any, Any], Any],
                          action_generator: Callable[[Any], List[Any]],
                          value_fn: Optional[Callable[[Any], float]] = None
                          ) -> Tuple[bool, float]:
        """
        Determine if an action from root should be pruned based on beam lookahead.
        
        Returns (should_prune, average_validity_score).
        """
        # Apply action to get next state
        try:
            next_state = dynamics_fn(current_state, action)
            if next_state is None:
                return True, 0.0
        except Exception:
            return True, 0.0
        
        # Project beam from next state
        beams = self.project_beam(next_state, dynamics_fn, action_generator, value_fn)
        
        if not beams:
            # No beams projected - conservative: don't prune
            return False, 1.0
        
        # Evaluate beam validity
        validity_scores = self.evaluate_beam_validity(beams)
        avg_validity = np.mean(validity_scores) if validity_scores else 0.0
        
        should_prune = avg_validity < self.validity_threshold
        
        if should_prune:
            self.roots_pruned += 1
        
        return should_prune, avg_validity
    
    def filter_actions(self,
                       current_state: Any,
                       actions: List[Any],
                       dynamics_fn: Callable[[Any, Any], Any],
                       action_generator: Callable[[Any], List[Any]],
                       value_fn: Optional[Callable[[Any], float]] = None
                       ) -> List[Tuple[Any, float]]:
        """
        Filter actions based on beam validity lookahead.
        
        Returns list of (action, validity_score) for non-pruned actions,
        sorted by validity score (highest first).
        """
        results = []
        
        for action in actions:
            should_prune, validity = self.should_prune_root(
                current_state, action, dynamics_fn, action_generator, value_fn
            )
            
            if not should_prune:
                results.append((action, validity))
        
        # Sort by validity score
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get filter statistics."""
        return {
            "beams_evaluated": self.beams_evaluated,
            "roots_pruned": self.roots_pruned,
            "beam_width": self.beam_width,
            "lookahead_depth": self.lookahead_depth,
            "validity_threshold": self.validity_threshold,
            "guard_stats": self.guard.get_statistics()
        }


class EnhancedMCTSSolver(MCTSSolver):
    """
    Enhanced MCTS Solver with Beam-Continuity Filter and Novelty Integration.
    
    Extends base MCTSSolver with:
    - B_cont: Beam-Continuity Filter for deep lookahead pruning
    - N: Novelty Engine integration for exploration bonus
    - Sheaf-based consistency validation (optional)
    
    This represents the "Iron Core" SANS V2 implementation.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 action_generator: Callable[[Any], List[Any]],
                 dynamics: Callable[[Any, Any], Any],
                 reward_fn: Callable[[Any], float],
                 terminal_fn: Callable[[Any], bool],
                 llm_policy: Optional[Callable[[Any], Dict[Any, float]]] = None,
                 enable_beam_filter: bool = True,
                 novelty_engine: Optional['NoveltyEngine'] = None):
        super().__init__(
            intent, action_generator, dynamics, reward_fn, terminal_fn, llm_policy
        )
        
        # Beam-Continuity Filter
        self.beam_filter = BeamContinuityFilter(
            intent, self.guard
        ) if enable_beam_filter else None
        
        # Novelty Engine
        self.novelty_engine = novelty_engine
        self.exploration_bonus_weight = 0.1
        
        # Enhanced statistics
        self.beam_pruned_actions = 0
    
    def _expand(self, node: MCTSNode) -> MCTSNode:
        """
        Enhanced expansion with beam-continuity filtering.
        """
        # Get LLM priors
        priors = self.llm_policy(node.state)
        
        # Select action to expand
        action = self.widening.select_action_to_expand(node, priors)
        
        if action is None:
            return node
        
        # Beam-continuity filter check (if enabled)
        if self.beam_filter:
            should_prune, _ = self.beam_filter.should_prune_root(
                node.state, action, self.dynamics, 
                self.action_generator, self.reward_fn
            )
            
            if should_prune:
                # Skip this action, try next one
                node.untried_actions.remove(action)
                self.beam_pruned_actions += 1
                
                # Recursively try to expand with remaining actions
                if node.untried_actions:
                    return self._expand(node)
                return node
        
        # Remove from untried
        node.untried_actions.remove(action)
        
        # Apply dynamics
        next_state = self.dynamics(node.state, action)
        
        # Validate with continuity guard
        if not self.guard.validate(node.state, action, next_state):
            return node  # Invalid — don't expand
        
        # Create child node
        child = MCTSNode(
            state=next_state,
            parent=node,
            action=action,
            prior=priors.get(action, 0.5)
        )
        child.untried_actions = self.action_generator(next_state)
        
        # Add to children
        node.children[action] = child
        
        self.nodes_expanded += 1
        
        return child
    
    def _simulate(self, node: MCTSNode, depth: int = 0) -> float:
        """
        Enhanced simulation with novelty bonus.
        """
        base_value = super()._simulate(node, depth)
        
        # Add novelty exploration bonus if engine available
        if self.novelty_engine and isinstance(node.state, np.ndarray):
            novelty_bonus = self.novelty_engine.compute_exploration_bonus(node.state)
            return base_value + self.exploration_bonus_weight * novelty_bonus
        
        return base_value
    
    def solve(self,
              initial_state: Any,
              n_iterations: int = 1000,
              time_limit: Optional[float] = None) -> Tuple[List[Any], float]:
        """
        Enhanced solve with novelty annealing.
        """
        # Reset novelty engine if available
        if self.novelty_engine:
            self.novelty_engine.reset()
        
        result = super().solve(initial_state, n_iterations, time_limit)
        
        return result
    
    def get_statistics(self) -> Dict[str, Any]:
        """Enhanced statistics."""
        base_stats = super().get_statistics()
        
        base_stats["beam_pruned_actions"] = self.beam_pruned_actions
        
        if self.beam_filter:
            base_stats["beam_filter"] = self.beam_filter.get_statistics()
        
        if self.novelty_engine:
            base_stats["novelty"] = self.novelty_engine.get_diagnostics()
        
        return base_stats


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'MCTSNode',
    'canonical_state_hash',
    'ProgressiveWidening',
    'ContinuityGuard',
    'MCTSSolver',
    'ShapedReward',
    'BeamContinuityFilter',
    'EnhancedMCTSSolver',
]
