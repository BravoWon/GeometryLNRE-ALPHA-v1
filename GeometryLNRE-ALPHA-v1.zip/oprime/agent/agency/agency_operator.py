"""
Agency Operator (Stage 7 of CTS)
================================

Agency is modeled as a continuous, topology-preserving transformation
f: M_v → M_v that:
    1. Preserves Q (topological invariants / identity)
    2. Maintains Φ >= Φ_c (integration)
    3. Maximizes expected value

Key Insight: Agency is NOT freedom from causality.
             Agency IS topological continuity — the capacity to navigate
             the value landscape while preserving self.

The Agency Operator is the final stage of the CTS pipeline,
connecting conscious state to action.
"""

from dataclasses import dataclass
from typing import List, Tuple, Dict, Any, Callable, Optional
import numpy as np
from abc import ABC, abstractmethod
import copy
import hashlib

from ...core.intent_alignment import IntentConfiguration, IntentAlignedOperator
from ...core.consciousness.conscious_state import (
    ConsciousState, 
    TopologicalInvariants,
    PHI_CRITICAL,
    ManifoldCollapseError
)


# =============================================================================
# CONTINUITY GUARD (Invariant Validator)
# =============================================================================

class ContinuityGuard:
    """
    The Continuity Guard validates that transformations preserve invariants.
    
    Implements the "Iron Core" validation logic:
        - Immutability (copy-on-write)
        - Topology preservation
        - Boundary checking
        - Object non-overlap
    """
    
    def __init__(self, 
                 bounds: Optional[Tuple[np.ndarray, np.ndarray]] = None,
                 max_topology_change: int = 1):
        self.bounds = bounds  # (min_bounds, max_bounds)
        self.max_topology_change = max_topology_change
    
    def validate(self, 
                 current_state: np.ndarray, 
                 proposed_state: np.ndarray,
                 current_Q: Optional[TopologicalInvariants] = None,
                 proposed_Q: Optional[TopologicalInvariants] = None) -> bool:
        """
        Validate that transformation is valid.
        
        Returns True if all invariants preserved.
        """
        # Check bounds
        if not self._check_bounds(proposed_state):
            return False
        
        # Check continuity (no teleportation)
        if not self._check_continuity(current_state, proposed_state):
            return False
        
        # Check topology preservation if available
        if current_Q is not None and proposed_Q is not None:
            if not self._check_topology(current_Q, proposed_Q):
                return False
        
        return True
    
    def _check_bounds(self, state: np.ndarray) -> bool:
        """Check if state is within bounds."""
        if self.bounds is None:
            return True
        
        min_bounds, max_bounds = self.bounds
        return np.all(state >= min_bounds) and np.all(state <= max_bounds)
    
    def _check_continuity(self, 
                          current: np.ndarray, 
                          proposed: np.ndarray,
                          max_step: float = 1.0) -> bool:
        """Check if step is continuous (not a teleport)."""
        distance = np.linalg.norm(proposed - current)
        return distance <= max_step
    
    def _check_topology(self, 
                        current_Q: TopologicalInvariants,
                        proposed_Q: TopologicalInvariants) -> bool:
        """Check if topological change is acceptable."""
        # Compute Betti number changes
        delta_beta = (
            abs(current_Q.betti_0 - proposed_Q.betti_0) +
            abs(current_Q.betti_1 - proposed_Q.betti_1) +
            abs(current_Q.betti_2 - proposed_Q.betti_2)
        )
        
        return delta_beta <= self.max_topology_change


class ImmutableStateManager:
    """
    Strict immutability via copy-on-write with commit-on-success model.
    
    Prevents "false memories" and state corruption —
    critical for the Iron Core.
    
    States are only persisted to history after successful validation.
    The initial state is recorded on first use to enable full rollback.
    """
    
    def __init__(self, initial_state: Optional[np.ndarray] = None):
        self.state_history: List[np.ndarray] = []
        self.max_history = 1000
        
        # Record initial state if provided
        if initial_state is not None:
            self.state_history.append(initial_state.copy())
    
    def set_initial_state(self, state: np.ndarray):
        """Set initial state (call once before any mutations)."""
        if not self.state_history:
            self.state_history.append(state.copy())
    
    def mutate(self, 
               state: np.ndarray, 
               mutation: Callable[[np.ndarray], np.ndarray],
               commit: bool = False) -> np.ndarray:
        """
        Apply mutation via copy-on-write.
        
        Original state is NEVER modified.
        Does NOT persist to history unless commit=True.
        
        Args:
            state: Input state
            mutation: Function to apply
            commit: If True, append result to history
        
        Returns:
            Mutated state (caller should validate before committing)
        """
        # Deep copy
        state_copy = state.copy()
        
        # Record original hash
        original_hash = hashlib.sha256(state.tobytes()).digest()
        
        # Apply mutation to copy
        mutated = mutation(state_copy)
        
        # Verify original unchanged
        if hashlib.sha256(state.tobytes()).digest() != original_hash:
            raise RuntimeError("CRITICAL: Original state was modified!")
        
        # Only store in history if commit=True
        if commit:
            self.commit(mutated)
        
        return mutated
    
    def commit(self, state: np.ndarray):
        """Commit a validated state to history."""
        if len(self.state_history) >= self.max_history:
            self.state_history.pop(0)
        self.state_history.append(state.copy())
    
    def rollback(self, steps: int = 1) -> Optional[np.ndarray]:
        """
        Rollback to previous state.
        
        Returns the state at (current - steps) position.
        Can rollback to initial state if it was recorded.
        """
        if steps < 1:
            return self.state_history[-1].copy() if self.state_history else None
        
        if len(self.state_history) <= steps:
            # Can't rollback that far, return initial if available
            return self.state_history[0].copy() if self.state_history else None
        
        # Remove states from history
        for _ in range(steps):
            if len(self.state_history) > 1:  # Keep at least initial state
                self.state_history.pop()
        
        return self.state_history[-1].copy() if self.state_history else None
    
    def get_current(self) -> Optional[np.ndarray]:
        """Get current state without modifying history."""
        return self.state_history[-1].copy() if self.state_history else None


# =============================================================================
# ACTION INTERFACE
# =============================================================================

def _canonicalize_value(val: Any) -> Any:
    """Convert value to a hashable canonical form."""
    if isinstance(val, np.ndarray):
        return val.tobytes()
    elif isinstance(val, list):
        return tuple(_canonicalize_value(v) for v in val)
    elif isinstance(val, dict):
        return frozenset(
            (k, _canonicalize_value(v)) for k, v in val.items()
        )
    elif isinstance(val, (int, float, str, bool, type(None))):
        return val
    else:
        # Fallback to repr for other types
        return repr(val)


@dataclass
class Action:
    """Represents an action in the agency system."""
    name: str
    parameters: Dict[str, Any]
    vector: Optional[np.ndarray] = None
    
    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, Action):
            return False
        if self.name != other.name:
            return False
        if self.parameters != other.parameters:
            return False
        # Handle vector comparison (may be None or ndarray)
        if self.vector is None and other.vector is None:
            return True
        if self.vector is None or other.vector is None:
            return False
        return np.array_equal(self.vector, other.vector)
    
    def __hash__(self) -> int:
        # Canonicalize parameters for hashing
        param_items = frozenset(
            (k, _canonicalize_value(v)) for k, v in self.parameters.items()
        )
        # Canonicalize vector
        vector_hash = self.vector.tobytes() if self.vector is not None else None
        return hash((self.name, param_items, vector_hash))


class ActionSpace(ABC):
    """Abstract interface for action spaces."""
    
    @abstractmethod
    def get_actions(self, state: np.ndarray) -> List[Action]:
        """Get available actions from current state."""
        pass
    
    @abstractmethod
    def apply_action(self, state: np.ndarray, action: Action) -> np.ndarray:
        """Apply action to state, returning new state."""
        pass


class ContinuousActionSpace(ActionSpace):
    """Continuous action space with direction vectors."""
    
    def __init__(self, dim: int, step_size: float = 0.1):
        self.dim = dim
        self.step_size = step_size
        
        # Cardinal directions
        self.directions = []
        for i in range(dim):
            for sign in [-1, 1]:
                d = np.zeros(dim)
                d[i] = sign
                self.directions.append(d)
    
    def get_actions(self, state: np.ndarray) -> List[Action]:
        """Get cardinal direction actions."""
        actions = []
        for i, d in enumerate(self.directions):
            actions.append(Action(
                name=f"move_{i}",
                parameters={"direction": i},
                vector=d * self.step_size
            ))
        return actions
    
    def apply_action(self, state: np.ndarray, action: Action) -> np.ndarray:
        """Apply action to state."""
        if action.vector is not None:
            return state + action.vector
        return state


# =============================================================================
# AGENCY OPERATOR (Stage 7)
# =============================================================================

class AgencyOperator(IntentAlignedOperator):
    """
    Stage 7: Agency as Transformation.
    
    Agency is a continuous, topology-preserving map f: M_v → M_v that:
        1. Preserves Q (identity/structure)
        2. Maintains Φ >= Φ_c (integration)
        3. Maximizes expected value
    
    The AgencyOperator ensures the agent does not "disintegrate"
    or lose its self-definition while acting.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 action_space: ActionSpace,
                 value_fn: Callable[[np.ndarray], float],
                 continuity_guard: Optional[ContinuityGuard] = None):
        super().__init__(intent)
        
        self.action_space = action_space
        self.value_fn = value_fn
        self.guard = continuity_guard or ContinuityGuard()
        self.state_manager = ImmutableStateManager()
        
        # Tracking
        self.action_history: List[Action] = []
        self.state_trajectory: List[np.ndarray] = []
    
    def act(self, 
            current_state: np.ndarray,
            action: Action,
            current_Q: Optional[TopologicalInvariants] = None,
            proposed_Q: Optional[TopologicalInvariants] = None) -> Tuple[np.ndarray, bool]:
        """
        Execute an action while preserving topological integrity.
        
        Uses commit-on-success model: state is only persisted to
        state_manager.state_history after validation passes.
        
        Returns: (new_state, success)
        """
        # Set initial state if not already set
        self.state_manager.set_initial_state(current_state)
        
        # Apply action via immutable state manager (without committing yet)
        def apply_mutation(s):
            return self.action_space.apply_action(s, action)
        
        proposed_state = self.state_manager.mutate(
            current_state, 
            apply_mutation,
            commit=False  # Don't commit yet - wait for validation
        )
        
        # INVARIANT CHECK: Continuity
        if not self.guard.validate(current_state, proposed_state, current_Q, proposed_Q):
            return current_state, False
        
        # Validation passed - now commit to state history
        self.state_manager.commit(proposed_state)
        
        # Record successful action
        self.action_history.append(action)
        self.state_trajectory.append(proposed_state.copy())
        
        return proposed_state, True
    
    def find_best_action(self,
                          current_state: np.ndarray,
                          current_Q: Optional[TopologicalInvariants] = None) -> Optional[Action]:
        """
        Find action that maximizes value while preserving invariants.
        
        Filters action space by intent-aligned agency freedom.
        """
        actions = self.action_space.get_actions(current_state)
        
        valid_actions = []
        for action in actions:
            # Simulate action
            proposed_state = self.action_space.apply_action(current_state.copy(), action)
            
            # Check validity
            if self.guard.validate(current_state, proposed_state, current_Q, None):
                value = self.value_fn(proposed_state)
                valid_actions.append((action, value))
        
        if not valid_actions:
            return None
        
        # Apply intent-based filtering
        action_scores = {a: v for a, v in valid_actions}
        filtered_actions = self.filter_actions_by_intent(
            [a for a, _ in valid_actions],
            action_scores
        )
        
        if not filtered_actions:
            return None
        
        # Return highest-value valid action
        best_action = max(filtered_actions, key=lambda a: action_scores.get(a, 0))
        return best_action
    
    def navigate(self,
                 start: np.ndarray,
                 goal: np.ndarray,
                 max_steps: int = 100) -> List[np.ndarray]:
        """
        Navigate from start to goal via topology-preserving path.
        
        Uses greedy action selection with invariant preservation.
        """
        path = [start.copy()]
        current = start.copy()
        
        for step in range(max_steps):
            # Check if goal reached
            if np.linalg.norm(current - goal) < 0.1:
                break
            
            # Get action toward goal
            direction = goal - current
            direction = direction / (np.linalg.norm(direction) + 1e-8)
            
            # Create action
            action = Action(
                name="navigate",
                parameters={"step": step},
                vector=direction * 0.1
            )
            
            # Execute with invariant preservation
            new_state, success = self.act(current, action)
            
            if success:
                current = new_state
                path.append(current.copy())
            else:
                # Try alternative directions
                perturbed = direction + 0.1 * np.random.randn(len(direction))
                perturbed = perturbed / (np.linalg.norm(perturbed) + 1e-8)
                
                alt_action = Action(
                    name="navigate_alt",
                    parameters={"step": step},
                    vector=perturbed * 0.1
                )
                new_state, success = self.act(current, alt_action)
                
                if success:
                    current = new_state
                    path.append(current.copy())
        
        return path
    
    def rollback(self, steps: int = 1) -> Optional[np.ndarray]:
        """Rollback to previous state."""
        state = self.state_manager.rollback(steps)
        
        if state is not None:
            # Remove from history
            for _ in range(min(steps, len(self.action_history))):
                self.action_history.pop()
                if self.state_trajectory:
                    self.state_trajectory.pop()
        
        return state
    
    def get_trajectory(self) -> List[np.ndarray]:
        """Get full trajectory of visited states."""
        return self.state_trajectory.copy()
    
    def get_action_history(self) -> List[Action]:
        """Get history of executed actions."""
        return self.action_history.copy()


# =============================================================================
# TOPOLOGY-PRESERVING TRANSFORM
# =============================================================================

class TopologyPreservingTransform:
    """
    Ensures transformations are homeomorphisms (topology-preserving).
    
    A valid transform must be:
        1. Continuous
        2. Bijective (one-to-one and onto)
        3. Have continuous inverse
    """
    
    def __init__(self, max_betti_change: int = 1):
        self.max_betti_change = max_betti_change
    
    def is_homeomorphism(self,
                          Q_before: TopologicalInvariants,
                          Q_after: TopologicalInvariants) -> bool:
        """
        Check if transformation is approximately a homeomorphism.
        
        Homeomorphisms preserve Betti numbers exactly.
        We allow small changes for numerical stability.
        """
        delta = (
            abs(Q_before.betti_0 - Q_after.betti_0) +
            abs(Q_before.betti_1 - Q_after.betti_1) +
            abs(Q_before.betti_2 - Q_after.betti_2)
        )
        
        return delta <= self.max_betti_change
    
    def project_to_valid(self,
                          proposed_Q: TopologicalInvariants,
                          reference_Q: TopologicalInvariants) -> TopologicalInvariants:
        """
        Project proposed topology to nearest valid topology.
        
        Ensures transform remains approximately homeomorphic.
        """
        def clamp(val, ref, max_change):
            return max(ref - max_change, min(ref + max_change, val))
        
        return TopologicalInvariants(
            betti_0=clamp(proposed_Q.betti_0, reference_Q.betti_0, self.max_betti_change),
            betti_1=clamp(proposed_Q.betti_1, reference_Q.betti_1, self.max_betti_change),
            betti_2=clamp(proposed_Q.betti_2, reference_Q.betti_2, self.max_betti_change),
            total_persistence=proposed_Q.total_persistence,
            persistent_features=proposed_Q.persistent_features
        )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'Action',
    'ActionSpace',
    'AgencyOperator',
    'ContinuityGuard',
    'ContinuousActionSpace',
    'ImmutableStateManager',
    'TopologyPreservingTransform',
]
