"""
Mapper Module: TDA-based Regime Classification
===============================================

Uses Topological Data Analysis to classify tasks into
reasoning regimes and enable Linguistic Arbitrage
(switching specialized adapters).
"""

from .tda_mapper import (
    Regime,
    REGIMES,
    FeatureExtractor,
    TDAMapper,
    RegimeAdaptiveLLM,
)

__all__ = [
    'Regime',
    'REGIMES',
    'FeatureExtractor',
    'TDAMapper',
    'RegimeAdaptiveLLM',
]
