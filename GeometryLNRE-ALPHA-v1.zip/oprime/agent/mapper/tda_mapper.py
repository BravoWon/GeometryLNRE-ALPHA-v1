"""
TDA Mapper: Regime Classification
=================================

Uses Topological Data Analysis (Mapper algorithm) to classify
the current task into reasoning regimes.

Regimes:
    - Symmetry: Mirror/rotation transformations
    - Counting: Object enumeration
    - Pattern: Repeating structure detection
    - Reasoning: Logical inference

This enables "Linguistic Arbitrage" — switching specialized
adapters (LoRA) to match the detected regime.

Intent Alignment:
    - SPECIFIC: Stable regime (resist switching)
    - EXPLORATORY: Dynamic regime (eager switching)
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Callable, Optional, Tuple
from collections import defaultdict
import numpy as np
from abc import ABC, abstractmethod

from ...core.intent_alignment import IntentConfiguration, IntentAlignedOperator, IntentContext


# =============================================================================
# REGIME DEFINITIONS
# =============================================================================

@dataclass
class Regime:
    """Defines a reasoning regime."""
    name: str
    description: str
    adapter_id: str
    feature_signature: Dict[str, float] = field(default_factory=dict)
    
    def match_score(self, features: Dict[str, float]) -> float:
        """Compute match score against feature signature."""
        if not self.feature_signature:
            return 0.0
        
        score = 0.0
        for key, expected in self.feature_signature.items():
            actual = features.get(key, 0.0)
            # Gaussian similarity
            score += np.exp(-((actual - expected) ** 2) / 0.5)
        
        return score / len(self.feature_signature)


# Standard regimes
REGIMES = {
    "symmetry": Regime(
        name="symmetry",
        description="Mirror, rotation, and reflection transformations",
        adapter_id="lora_symmetry",
        feature_signature={
            "symmetry_score": 0.8,
            "repetition_score": 0.6,
            "object_count": 0.3
        }
    ),
    "counting": Regime(
        name="counting",
        description="Object enumeration and quantity reasoning",
        adapter_id="lora_counting",
        feature_signature={
            "object_count": 0.8,
            "color_diversity": 0.5,
            "symmetry_score": 0.2
        }
    ),
    "pattern": Regime(
        name="pattern",
        description="Repeating structure and sequence detection",
        adapter_id="lora_pattern",
        feature_signature={
            "repetition_score": 0.8,
            "grid_regularity": 0.7,
            "symmetry_score": 0.5
        }
    ),
    "reasoning": Regime(
        name="reasoning",
        description="Logical inference and abstract reasoning",
        adapter_id="lora_reasoning",
        feature_signature={
            "complexity": 0.7,
            "abstraction_level": 0.8,
            "object_count": 0.5
        }
    )
}


# =============================================================================
# FEATURE EXTRACTOR
# =============================================================================

class FeatureExtractor(IntentAlignedOperator):
    """
    Extracts task features for regime classification.
    
    Produces Unified Grid Feature Space (UGFS) representation.
    
    Intent Alignment:
        - SPECIFIC: Focus on goal-relevant features
        - EXPLORATORY: Extract all features
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 feature_dim: int = 50):
        super().__init__(intent)
        
        self.feature_dim = feature_dim
        self.feature_weights = self._compute_feature_weights()
    
    def _compute_feature_weights(self) -> Dict[str, float]:
        """Compute feature importance weights based on intent."""
        context = self.intent.context
        
        if context == IntentContext.SPECIFIC:
            # Focus on goal-relevant features
            return {
                "symmetry_score": 0.3,
                "object_count": 0.2,
                "complexity": 0.5
            }
        elif context == IntentContext.GENERAL:
            # Balanced features
            return {
                "symmetry_score": 0.25,
                "object_count": 0.25,
                "repetition_score": 0.25,
                "complexity": 0.25
            }
        else:  # EXPLORATORY
            # All features equal
            return {
                "symmetry_score": 0.2,
                "object_count": 0.2,
                "repetition_score": 0.2,
                "color_diversity": 0.2,
                "complexity": 0.2
            }
    
    def extract(self, task_input: np.ndarray) -> Dict[str, float]:
        """
        Extract features from task input.
        
        Returns normalized feature dictionary.
        """
        # Ensure 2D
        if task_input.ndim == 1:
            size = int(np.sqrt(len(task_input)))
            task_input = task_input[:size*size].reshape(size, size)
        
        features = {}
        
        # Symmetry score
        features["symmetry_score"] = self._compute_symmetry(task_input)
        
        # Object count (simplified)
        features["object_count"] = self._compute_object_count(task_input)
        
        # Repetition score
        features["repetition_score"] = self._compute_repetition(task_input)
        
        # Color diversity
        features["color_diversity"] = self._compute_color_diversity(task_input)
        
        # Complexity
        features["complexity"] = self._compute_complexity(task_input)
        
        # Grid regularity
        features["grid_regularity"] = self._compute_grid_regularity(task_input)
        
        # Abstraction level
        features["abstraction_level"] = self._compute_abstraction(task_input)
        
        # Return raw features for regime matching
        # Intent-based weights are stored separately for downstream use
        # (e.g., for prioritizing features in search or visualization)
        # but should NOT be applied before regime classification since
        # Regime.match_score() expects raw feature values
        return features
    def _compute_symmetry(self, grid: np.ndarray) -> float:
        """Compute horizontal and vertical symmetry."""
        h, w = grid.shape
        
        # Horizontal symmetry
        h_sym = np.mean(grid == np.flip(grid, axis=1))
        
        # Vertical symmetry
        v_sym = np.mean(grid == np.flip(grid, axis=0))
        
        return (h_sym + v_sym) / 2
    
    def _compute_object_count(self, grid: np.ndarray) -> float:
        """Estimate object count (normalized)."""
        unique_values = len(np.unique(grid))
        return min(1.0, unique_values / 10)
    
    def _compute_repetition(self, grid: np.ndarray) -> float:
        """Detect repeating patterns."""
        h, w = grid.shape
        
        # Check for repeating rows/columns
        row_repeat = 0
        for i in range(h - 1):
            if np.array_equal(grid[i], grid[i + 1]):
                row_repeat += 1
        
        col_repeat = 0
        for j in range(w - 1):
            if np.array_equal(grid[:, j], grid[:, j + 1]):
                col_repeat += 1
        
        return (row_repeat / max(1, h - 1) + col_repeat / max(1, w - 1)) / 2
    
    def _compute_color_diversity(self, grid: np.ndarray) -> float:
        """Compute color/value diversity."""
        unique = len(np.unique(grid))
        return min(1.0, unique / 10)
    
    def _compute_complexity(self, grid: np.ndarray) -> float:
        """Estimate task complexity."""
        # Use entropy as proxy
        values, counts = np.unique(grid, return_counts=True)
        probs = counts / counts.sum()
        entropy = -np.sum(probs * np.log(probs + 1e-10))
        
        return min(1.0, entropy / 3)
    
    def _compute_grid_regularity(self, grid: np.ndarray) -> float:
        """Check if grid has regular structure."""
        h, w = grid.shape
        
        # Check for checkerboard-like patterns
        regularity = 0.0
        if h > 1 and w > 1:
            # Compare alternating cells
            for i in range(h - 1):
                for j in range(w - 1):
                    if grid[i, j] == grid[i + 1, j + 1]:
                        regularity += 1
        
        total_checks = max(1, (h - 1) * (w - 1))
        return regularity / total_checks
    
    def _compute_abstraction(self, grid: np.ndarray) -> float:
        """Estimate abstraction level."""
        # High abstraction = few unique patterns
        unique_rows = len(set(tuple(row) for row in grid))
        unique_cols = len(set(tuple(grid[:, j]) for j in range(grid.shape[1])))
        
        h, w = grid.shape
        return 1.0 - (unique_rows / h + unique_cols / w) / 2
    
    def to_vector(self, features: Dict[str, float]) -> np.ndarray:
        """Convert features to vector representation."""
        # Fixed order for consistency
        keys = sorted(features.keys())
        vector = np.array([features.get(k, 0.0) for k in keys])
        
        # Pad to feature_dim
        if len(vector) < self.feature_dim:
            vector = np.pad(vector, (0, self.feature_dim - len(vector)))
        
        return vector[:self.feature_dim]


# =============================================================================
# TDA MAPPER
# =============================================================================

class TDAMapper(IntentAlignedOperator):
    """
    TDA Mapper for regime classification.
    
    Uses topological features to cluster tasks into regimes.
    
    Intent Alignment:
        - SPECIFIC: Stable regime assignment
        - EXPLORATORY: Dynamic regime switching
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 regimes: Optional[Dict[str, Regime]] = None):
        super().__init__(intent)
        
        self.regimes = regimes or REGIMES
        self.feature_extractor = FeatureExtractor(intent)
        
        # Intent-aligned parameters
        self.switch_threshold = self._compute_switch_threshold()
        self.smoothing = self._compute_smoothing()
        
        # State
        self.current_regime = "reasoning"  # Default
        self.regime_history: List[str] = []
        self.confidence_history: List[float] = []
    
    def _compute_switch_threshold(self) -> float:
        """Compute threshold for regime switching."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.4  # High threshold = stable
        elif context == IntentContext.GENERAL:
            base = 0.2
        else:  # EXPLORATORY
            base = 0.1  # Low threshold = dynamic
        
        return base * (1.0 - 0.5 * self.intent.scope)
    
    def _compute_smoothing(self) -> float:
        """Compute temporal smoothing factor."""
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            return 0.8  # Strong smoothing
        elif context == IntentContext.GENERAL:
            return 0.5
        else:  # EXPLORATORY
            return 0.2  # Weak smoothing
    
    def classify(self, task_input: np.ndarray) -> Tuple[str, float, str]:
        """
        Classify task into regime.
        
        Returns (regime_name, confidence, adapter_id).
        """
        # Extract features
        features = self.feature_extractor.extract(task_input)
        
        # Score each regime
        scores = {}
        for name, regime in self.regimes.items():
            scores[name] = regime.match_score(features)
        
        # Apply temporal smoothing
        if self.regime_history:
            last_regime = self.regime_history[-1]
            scores[last_regime] += self.smoothing * 0.2
        
        # Find best regime
        best_regime = max(scores.items(), key=lambda x: x[1])
        
        # Check if switch is warranted
        confidence = best_regime[1]
        new_regime = best_regime[0]
        
        if new_regime != self.current_regime:
            # Need sufficient confidence to switch
            current_score = scores.get(self.current_regime, 0)
            if confidence - current_score < self.switch_threshold:
                # Stay with current regime
                new_regime = self.current_regime
                confidence = current_score
        
        # Update state
        self.regime_history.append(new_regime)
        self.confidence_history.append(confidence)
        self.current_regime = new_regime
        
        # Get adapter
        adapter_id = self.regimes[new_regime].adapter_id
        
        return new_regime, confidence, adapter_id
    
    def get_regime_distribution(self) -> Dict[str, float]:
        """Get distribution of regimes in history."""
        if not self.regime_history:
            return {}
        
        counts = defaultdict(int)
        for r in self.regime_history:
            counts[r] += 1
        
        total = len(self.regime_history)
        return {k: v / total for k, v in counts.items()}
    
    def reset(self):
        """Reset mapper state."""
        self.current_regime = "reasoning"
        self.regime_history = []
        self.confidence_history = []


# =============================================================================
# REGIME-ADAPTIVE LLM
# =============================================================================

class RegimeAdaptiveLLM(IntentAlignedOperator):
    """
    Regime-Adaptive LLM with LoRA switching.
    
    Switches specialized adapters based on detected regime.
    
    Intent Alignment:
        - SPECIFIC: Conservative switching
        - EXPLORATORY: Aggressive switching
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 base_model: Any = None,
                 adapters: Optional[Dict[str, Any]] = None):
        super().__init__(intent)
        
        self.base_model = base_model
        self.adapters = adapters or {}
        
        self.mapper = TDAMapper(intent)
        
        # Current adapter state
        self.current_adapter: Optional[str] = None
        self.switch_count = 0
    
    def load_adapter(self, adapter_id: str):
        """Load a LoRA adapter."""
        if adapter_id in self.adapters:
            self.current_adapter = adapter_id
            self.switch_count += 1
            # In real implementation: self.base_model.load_adapter(...)
            return True
        return False
    
    def infer(self, 
              task_input: np.ndarray,
              prompt: str) -> Tuple[str, Dict[str, Any]]:
        """
        Run inference with regime-adaptive adapter selection.
        
        Returns (output, metadata).
        """
        # Classify regime
        regime, confidence, adapter_id = self.mapper.classify(task_input)
        
        # Switch adapter if needed
        adapter_loaded = True
        if adapter_id != self.current_adapter:
            adapter_loaded = self.load_adapter(adapter_id)
        
        # Run inference (placeholder)
        output = f"[{regime}] Inference result for prompt: {prompt[:50]}..."
        
        metadata = {
            "regime": regime,
            "confidence": confidence,
            "adapter": self.current_adapter,
            "adapter_requested": adapter_id,
            "adapter_loaded": adapter_loaded,
            "switch_count": self.switch_count
        }
        
        return output, metadata
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get LLM statistics."""
        return {
            "current_adapter": self.current_adapter,
            "switch_count": self.switch_count,
            "regime_distribution": self.mapper.get_regime_distribution()
        }


# =============================================================================
# ZIGZAG-REGIME COUPLING (Z_switch Integration)
# =============================================================================

class ZigzagRegimeTracker(IntentAlignedOperator):
    """
    Tracks topological features across layers using Zigzag Persistence.
    
    Implements the "Layer-as-Time" hypothesis from the OPrime blueprint:
    - Short-lived features: High rearrangement (early/late layers)
    - Long-lived features: Stable concepts (middle layers)
    
    Triggers regime switches on Type II Phase Transitions:
    - Sudden spike in short-lived features = topology change
    - This signals need for "Linguistic Arbitrage" (adapter switching)
    
    Intent Alignment:
        - SPECIFIC: Conservative switching (high threshold)
        - EXPLORATORY: Aggressive switching (low threshold)
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 window_size: int = 5,
                 transition_sensitivity: float = 1.0):
        super().__init__(intent)
        
        self.window_size = window_size
        self.transition_sensitivity = transition_sensitivity
        
        # Feature tracking
        self.betti_history: List[Dict[int, int]] = []
        self.persistence_history: List[float] = []
        self.entropy_history: List[float] = []
        
        # Transition detection
        self.transition_threshold = self._compute_transition_threshold()
        self.detected_transitions: List[int] = []
        
        # Cognitive phase tracking
        self.current_phase = "contextualization"
    
    def _compute_transition_threshold(self) -> float:
        """
        Compute threshold for detecting Type II Phase Transitions.
        
        SPECIFIC: High threshold (resist transitions)
        EXPLORATORY: Low threshold (detect more transitions)
        """
        context = self.intent.context
        if context == IntentContext.SPECIFIC:
            base = 0.7
        elif context == IntentContext.GENERAL:
            base = 0.4
        else:  # EXPLORATORY
            base = 0.2
        
        return base * (1.5 - self.intent.scope) * self.transition_sensitivity
    
    def compute_feature_entropy(self, betti_numbers: Dict[int, int]) -> float:
        """
        Compute entropy of topological features.
        
        High entropy = many short-lived features (rearrangement)
        Low entropy = stable features (retention)
        """
        total = sum(betti_numbers.values()) + 1e-8
        probs = [v / total for v in betti_numbers.values()]
        
        # Shannon entropy
        entropy = -sum(p * np.log(p + 1e-10) for p in probs if p > 0)
        return entropy
    
    def add_layer(self,
                  betti_0: int,
                  betti_1: int,
                  betti_2: int,
                  persistence: float) -> Dict[str, Any]:
        """
        Add a layer's topological features.
        
        Returns analysis of the layer including phase and transitions.
        """
        betti = {0: betti_0, 1: betti_1, 2: betti_2}
        entropy = self.compute_feature_entropy(betti)
        
        # Store in history
        self.betti_history.append(betti)
        self.persistence_history.append(persistence)
        self.entropy_history.append(entropy)
        
        # Keep windowed history
        if len(self.betti_history) > self.window_size * 2:
            self.betti_history.pop(0)
            self.persistence_history.pop(0)
            self.entropy_history.pop(0)
        
        # Detect transitions
        transition_detected = self._detect_transition()
        if transition_detected:
            self.detected_transitions.append(len(self.betti_history) - 1)
        
        # Update cognitive phase
        self._update_phase()
        
        return {
            "betti": betti,
            "entropy": entropy,
            "persistence": persistence,
            "phase": self.current_phase,
            "transition_detected": transition_detected
        }
    
    def _detect_transition(self) -> bool:
        """
        Detect Type II Phase Transition.
        
        Triggered by sudden changes in:
        - Betti number ratios
        - Feature entropy
        - Persistence patterns
        """
        if len(self.entropy_history) < 2:
            return False
        
        # Entropy delta
        entropy_delta = abs(
            self.entropy_history[-1] - self.entropy_history[-2]
        )
        
        # Betti number changes
        if len(self.betti_history) >= 2:
            prev_betti = self.betti_history[-2]
            curr_betti = self.betti_history[-1]
            
            betti_delta = sum(
                abs(curr_betti.get(k, 0) - prev_betti.get(k, 0))
                for k in set(prev_betti.keys()) | set(curr_betti.keys())
            )
        else:
            betti_delta = 0
        
        # Combined transition score
        transition_score = entropy_delta * 0.5 + betti_delta * 0.3
        
        return transition_score > self.transition_threshold
    
    def _update_phase(self):
        """
        Update cognitive phase based on feature patterns.
        
        Phases:
        - contextualization: High entropy (early)
        - abstraction: Low entropy, high persistence (middle)
        - actuation: Rising entropy (late)
        """
        if len(self.entropy_history) < 3:
            return
        
        # Recent trend
        recent_entropy = self.entropy_history[-3:]
        trend = recent_entropy[-1] - recent_entropy[0]
        avg_entropy = np.mean(recent_entropy)
        
        avg_persistence = np.mean(self.persistence_history[-3:])
        
        if avg_entropy > 0.5 and trend > 0:
            self.current_phase = "contextualization"
        elif avg_persistence > 0.5 and abs(trend) < 0.1:
            self.current_phase = "abstraction"
        elif trend > 0.2:
            self.current_phase = "actuation"
    
    def get_feature_lifespan(self) -> Dict[str, List[int]]:
        """
        Track which features persist across layers.
        
        Returns layer indices where each feature type is present.
        """
        lifespans = {
            "components": [],  # β_0 > 1
            "loops": [],       # β_1 > 0
            "voids": []        # β_2 > 0
        }
        
        for i, betti in enumerate(self.betti_history):
            if betti.get(0, 1) > 1:
                lifespans["components"].append(i)
            if betti.get(1, 0) > 0:
                lifespans["loops"].append(i)
            if betti.get(2, 0) > 0:
                lifespans["voids"].append(i)
        
        return lifespans
    
    def should_switch_regime(self) -> bool:
        """
        Determine if regime switch should occur based on zigzag analysis.
        
        Returns True if recent transitions indicate regime change.
        """
        if len(self.detected_transitions) == 0:
            return False
        
        # Check if transition was recent
        latest_transition = self.detected_transitions[-1]
        current_layer = len(self.betti_history) - 1
        
        return (current_layer - latest_transition) <= 1
    
    def get_recommended_regime(self) -> str:
        """
        Recommend regime based on current cognitive phase.
        
        Maps phases to reasoning regimes.
        """
        phase_to_regime = {
            "contextualization": "pattern",
            "abstraction": "reasoning",
            "actuation": "symmetry"
        }
        return phase_to_regime.get(self.current_phase, "reasoning")
    
    def reset(self):
        """Reset tracker state."""
        self.betti_history = []
        self.persistence_history = []
        self.entropy_history = []
        self.detected_transitions = []
        self.current_phase = "contextualization"


class EnhancedTDAMapper(TDAMapper):
    """
    Enhanced TDA Mapper with Zigzag-Regime Coupling.
    
    Extends base TDAMapper with:
    - Zigzag persistence tracking
    - Automatic regime switching on phase transitions
    - Cognitive phase awareness
    
    This implements the full "Linguistic Arbitrage" capability:
    Switch LoRA adapters mid-inference based on topological signals.
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 regimes: Optional[Dict[str, Regime]] = None,
                 enable_zigzag: bool = True):
        super().__init__(intent, regimes)
        
        self.enable_zigzag = enable_zigzag
        self.zigzag_tracker = ZigzagRegimeTracker(intent) if enable_zigzag else None
        
        # Enhanced state
        self.layer_count = 0
        self.auto_switches = 0
    
    def classify_with_zigzag(self,
                             task_input: np.ndarray,
                             layer_topology: Optional[Dict[str, Any]] = None
                             ) -> Tuple[str, float, str, Dict[str, Any]]:
        """
        Classify with zigzag-aware regime switching.
        
        Args:
            task_input: Input to classify
            layer_topology: Optional topology from current layer
                           {"betti_0": int, "betti_1": int, "betti_2": int, 
                            "persistence": float}
        
        Returns:
            (regime_name, confidence, adapter_id, zigzag_info)
        """
        # Base classification
        regime, confidence, adapter = self.classify(task_input)
        
        zigzag_info = {}
        
        # Zigzag analysis if enabled and topology provided
        if self.enable_zigzag and self.zigzag_tracker and layer_topology:
            layer_result = self.zigzag_tracker.add_layer(
                betti_0=layer_topology.get("betti_0", 1),
                betti_1=layer_topology.get("betti_1", 0),
                betti_2=layer_topology.get("betti_2", 0),
                persistence=layer_topology.get("persistence", 0.5)
            )
            
            zigzag_info = layer_result
            
            # Check for regime switch trigger
            if self.zigzag_tracker.should_switch_regime():
                recommended = self.zigzag_tracker.get_recommended_regime()
                
                if recommended != regime:
                    # Override with zigzag recommendation
                    regime = recommended
                    adapter = self.regimes[recommended].adapter_id
                    self.auto_switches += 1
                    
                    zigzag_info["auto_switched"] = True
                    zigzag_info["original_regime"] = self.current_regime
        
        self.layer_count += 1
        
        return regime, confidence, adapter, zigzag_info
    
    def process_layer_stream(self,
                              layer_embeddings: List[np.ndarray],
                              task_input: np.ndarray
                              ) -> List[Tuple[str, str, Dict[str, Any]]]:
        """
        Process a stream of layer embeddings.
        
        Tracks topology across layers and triggers switches.
        
        Returns list of (regime, adapter, zigzag_info) for each layer.
        """
        results = []
        
        for i, embedding in enumerate(layer_embeddings):
            # Extract topology from embedding
            from ...core.topology.persistent_homology import TopologyExtractor
            extractor = TopologyExtractor(self.intent)
            invariants = extractor.extract_from_embedding(embedding)
            
            layer_topology = {
                "betti_0": invariants.betti_0,
                "betti_1": invariants.betti_1,
                "betti_2": invariants.betti_2,
                "persistence": invariants.total_persistence
            }
            
            # Classify with zigzag
            regime, conf, adapter, zigzag_info = self.classify_with_zigzag(
                task_input, layer_topology
            )
            
            zigzag_info["layer_index"] = i
            results.append((regime, adapter, zigzag_info))
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get enhanced statistics."""
        base_stats = {
            "current_regime": self.current_regime,
            "regime_distribution": self.get_regime_distribution(),
            "layer_count": self.layer_count,
            "auto_switches": self.auto_switches
        }
        
        if self.zigzag_tracker:
            base_stats["zigzag"] = {
                "current_phase": self.zigzag_tracker.current_phase,
                "transitions_detected": len(self.zigzag_tracker.detected_transitions),
                "feature_lifespans": self.zigzag_tracker.get_feature_lifespan()
            }
        
        return base_stats
    
    def reset(self):
        """Reset mapper state."""
        super().reset()
        if self.zigzag_tracker:
            self.zigzag_tracker.reset()
        self.layer_count = 0
        self.auto_switches = 0


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'Regime',
    'REGIMES',
    'FeatureExtractor',
    'TDAMapper',
    'RegimeAdaptiveLLM',
    'ZigzagRegimeTracker',
    'EnhancedTDAMapper',
]
