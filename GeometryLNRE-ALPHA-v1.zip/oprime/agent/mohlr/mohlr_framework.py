"""
MOHLR: Maximum Optimization Human-in-the-Loop Reinforcement
============================================================

Framework for embedding expert strategic intuition into learning systems.
Based on the MOHLR Adaptive Execution System Architecture from the knowledge library.

Core Components:
    1. MaxOp Identification: High-leverage intervention points
    2. Strategic Feedback Loops: Human-AI collaboration
    3. Asymptotic Trajectory Shaping: Long-term optimization
    4. Ternary Feedback: Positive/Negative/Neutral signals

The MOHLR system implements the Centaur Model - human-AI symbiosis where:
    - Human: Provides value function, ethical boundaries, strategic intent
    - AI: Provides processing speed, pattern recognition, execution
    
Architecture:
    Human Expert → MaxOp Selection → AI Pattern Recognition → Learned Policy
                          ↑                                         ↓
                    Ternary Feedback ←───────────────────────────────┘

Intent Alignment:
    - SPECIFIC: Focus on exploitation of known MaxOps
    - GENERAL: Balance exploration and exploitation
    - EXPLORATORY: Actively search for new MaxOp patterns
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Callable, Tuple
from enum import Enum
from collections import deque
import numpy as np
import time
import copy

from ...core.intent_alignment import (
    IntentConfiguration,
    IntentAlignedOperator,
    IntentContext,
)


class FeedbackType(Enum):
    """Ternary feedback signals for MOHLR."""
    POSITIVE = 1
    NEUTRAL = 0
    NEGATIVE = -1


@dataclass
class MaxOp:
    """
    Maximum Optimization - A high-leverage intervention point.
    
    MaxOps are actions or decisions that dramatically alter a system's
    asymptotic trajectory. They are the "pivots" where small inputs
    yield large shifts in long-term outcomes.
    
    Attributes:
        id: Unique identifier for this MaxOp
        state_pattern: Conditions under which this MaxOp applies
        action: The intervention to take
        expected_impact: Predicted magnitude of trajectory change
        confidence: Certainty that this is a true MaxOp
        domain: Category or regime where this MaxOp applies
        source: Who/what identified this MaxOp (human/AI)
    """
    id: str
    state_pattern: Dict[str, Any]
    action: Any
    expected_impact: float
    confidence: float = 0.5
    domain: str = "general"
    source: str = "human"
    
    # Tracking
    times_selected: int = 0
    times_successful: int = 0
    cumulative_impact: float = 0.0
    feedback_history: List[FeedbackType] = field(default_factory=list)
    
    @property
    def success_rate(self) -> float:
        """Compute success rate of this MaxOp."""
        if self.times_selected == 0:
            return 0.5  # Prior
        return self.times_successful / self.times_selected
    
    @property
    def average_impact(self) -> float:
        """Compute average observed impact."""
        if self.times_selected == 0:
            return self.expected_impact
        return self.cumulative_impact / self.times_selected
    
    def update_from_feedback(self, feedback: FeedbackType, observed_impact: float):
        """Update MaxOp statistics from feedback."""
        self.times_selected += 1
        self.cumulative_impact += observed_impact
        self.feedback_history.append(feedback)
        
        if feedback == FeedbackType.POSITIVE:
            self.times_successful += 1
            # Increase confidence with positive feedback
            self.confidence = min(1.0, self.confidence + 0.1)
        elif feedback == FeedbackType.NEGATIVE:
            # Decrease confidence with negative feedback
            self.confidence = max(0.0, self.confidence - 0.15)


@dataclass
class TrajectoryPoint:
    """A point on the system's trajectory through state space."""
    state: Any
    timestamp: float
    value: float
    maxop_applied: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class MaxOpLibrary(IntentAlignedOperator):
    """
    Library of discovered MaxOps with pattern matching.
    
    Provides:
        - Storage and retrieval of MaxOps
        - Pattern matching for applicable MaxOps
        - Learning from human feedback
        - Domain-specific organization
    """
    
    def __init__(self, intent: IntentConfiguration):
        super().__init__(intent)
        
        # MaxOp storage by domain
        self.maxops: Dict[str, List[MaxOp]] = {}
        
        # Pattern matching threshold (intent-modulated)
        self.match_threshold = self._compute_match_threshold()
        
        # Learning parameters
        self.learning_rate = 0.1
    
    def _compute_match_threshold(self) -> float:
        """Compute pattern matching threshold from intent."""
        if self.intent.context == IntentContext.SPECIFIC:
            return 0.9  # Strict matching for focused work
        elif self.intent.context == IntentContext.GENERAL:
            return 0.7
        else:  # EXPLORATORY
            return 0.5  # Loose matching for discovery
    
    def add_maxop(self, maxop: MaxOp):
        """Add a MaxOp to the library."""
        domain = maxop.domain
        if domain not in self.maxops:
            self.maxops[domain] = []
        self.maxops[domain].append(maxop)
    
    def find_matching_maxops(self, 
                              state: Dict[str, Any],
                              domain: Optional[str] = None
                              ) -> List[Tuple[MaxOp, float]]:
        """
        Find MaxOps that match the current state.
        
        Returns list of (MaxOp, match_score) tuples sorted by score.
        """
        results = []
        
        domains_to_search = [domain] if domain else list(self.maxops.keys())
        
        for d in domains_to_search:
            if d not in self.maxops:
                continue
            
            for maxop in self.maxops[d]:
                score = self._compute_match_score(state, maxop.state_pattern)
                
                if score >= self.match_threshold:
                    results.append((maxop, score))
        
        # Sort by match score * confidence * expected impact
        results.sort(
            key=lambda x: x[1] * x[0].confidence * x[0].expected_impact,
            reverse=True
        )
        
        return results
    
    def _compute_match_score(self, 
                              state: Dict[str, Any], 
                              pattern: Dict[str, Any]) -> float:
        """Compute how well a state matches a pattern."""
        if not pattern:
            return 0.5  # Empty pattern = weak match
        
        matches = 0
        total = len(pattern)
        
        for key, expected in pattern.items():
            if key in state:
                actual = state[key]
                
                # Exact match
                if actual == expected:
                    matches += 1
                # Numeric range match
                elif isinstance(expected, tuple) and len(expected) == 2:
                    if expected[0] <= actual <= expected[1]:
                        matches += 0.8
                # Partial string match
                elif isinstance(expected, str) and isinstance(actual, str):
                    if expected.lower() in actual.lower():
                        matches += 0.7
        
        return matches / total if total > 0 else 0.0
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get library statistics."""
        total_maxops = sum(len(mops) for mops in self.maxops.values())
        
        domain_stats = {}
        for domain, mops in self.maxops.items():
            avg_confidence = np.mean([m.confidence for m in mops]) if mops else 0
            avg_success = np.mean([m.success_rate for m in mops]) if mops else 0
            domain_stats[domain] = {
                "count": len(mops),
                "avg_confidence": avg_confidence,
                "avg_success_rate": avg_success
            }
        
        return {
            "total_maxops": total_maxops,
            "domains": domain_stats,
            "match_threshold": self.match_threshold
        }


class TernaryFeedbackCollector:
    """
    Collects and processes ternary feedback from human experts.
    
    Ternary feedback (Positive/Negative/Neutral) provides richer
    information than binary pass/fail, enabling faster learning
    and better calibration of MaxOp effectiveness.
    """
    
    def __init__(self):
        self.feedback_history: List[Dict[str, Any]] = []
        self.pending_feedback: Dict[str, TrajectoryPoint] = {}
    
    def request_feedback(self, 
                          trajectory_point: TrajectoryPoint,
                          maxop_id: str) -> str:
        """
        Register a point for feedback collection.
        
        Returns a feedback request ID.
        """
        request_id = f"fb_{maxop_id}_{int(time.time() * 1000)}"
        self.pending_feedback[request_id] = trajectory_point
        return request_id
    
    def submit_feedback(self,
                         request_id: str,
                         feedback: FeedbackType,
                         observed_impact: float = 0.0,
                         notes: str = "") -> bool:
        """
        Submit human feedback for a trajectory point.
        """
        if request_id not in self.pending_feedback:
            return False
        
        point = self.pending_feedback.pop(request_id)
        
        feedback_record = {
            "request_id": request_id,
            "timestamp": time.time(),
            "trajectory_point": point,
            "feedback": feedback,
            "observed_impact": observed_impact,
            "notes": notes
        }
        
        self.feedback_history.append(feedback_record)
        return True
    
    def get_pending_count(self) -> int:
        """Number of feedback requests awaiting response."""
        return len(self.pending_feedback)
    
    def get_feedback_summary(self) -> Dict[str, Any]:
        """Summarize collected feedback."""
        if not self.feedback_history:
            return {"total": 0}
        
        positive = sum(1 for f in self.feedback_history 
                       if f["feedback"] == FeedbackType.POSITIVE)
        negative = sum(1 for f in self.feedback_history 
                       if f["feedback"] == FeedbackType.NEGATIVE)
        neutral = len(self.feedback_history) - positive - negative
        
        return {
            "total": len(self.feedback_history),
            "positive": positive,
            "negative": negative,
            "neutral": neutral,
            "positive_rate": positive / len(self.feedback_history),
            "pending": self.get_pending_count()
        }


class AsymptoticTrajectoryTracker:
    """
    Tracks and predicts the system's asymptotic trajectory.
    
    The goal of MOHLR is to shape the asymptotic trajectory - 
    where the system is heading in the long term. MaxOps are
    interventions that shift this trajectory toward desired outcomes.
    """
    
    def __init__(self, 
                 window_size: int = 100,
                 prediction_horizon: int = 10):
        self.trajectory: deque = deque(maxlen=window_size)
        self.prediction_horizon = prediction_horizon
        
        # Trend estimation
        self.trend_slope = 0.0
        self.trend_intercept = 0.0
    
    def add_point(self, point: TrajectoryPoint):
        """Add a point to the trajectory."""
        self.trajectory.append(point)
        self._update_trend()
    
    def _update_trend(self):
        """Update trend estimation using linear regression."""
        if len(self.trajectory) < 5:
            return
        
        # Extract values
        times = np.array([p.timestamp for p in self.trajectory])
        values = np.array([p.value for p in self.trajectory])
        
        # Normalize times
        times = times - times[0]
        
        # Simple linear regression
        n = len(times)
        sum_x = np.sum(times)
        sum_y = np.sum(values)
        sum_xy = np.sum(times * values)
        sum_xx = np.sum(times * times)
        
        denom = n * sum_xx - sum_x * sum_x
        if abs(denom) > 1e-10:
            self.trend_slope = (n * sum_xy - sum_x * sum_y) / denom
            self.trend_intercept = (sum_y - self.trend_slope * sum_x) / n
    
    def predict_asymptote(self) -> float:
        """
        Predict the asymptotic value the system is heading toward.
        
        Uses trend extrapolation with damping.
        """
        if len(self.trajectory) < 2:
            return 0.0
        
        current_time = self.trajectory[-1].timestamp - self.trajectory[0].timestamp
        future_time = current_time + self.prediction_horizon
        
        # Damped extrapolation
        raw_prediction = self.trend_intercept + self.trend_slope * future_time
        
        # Apply damping toward current value
        current_value = self.trajectory[-1].value
        damping = 0.7
        
        return damping * raw_prediction + (1 - damping) * current_value
    
    def get_trend_direction(self) -> str:
        """Get qualitative trend direction."""
        if abs(self.trend_slope) < 0.01:
            return "stable"
        elif self.trend_slope > 0:
            return "improving"
        else:
            return "declining"
    
    def get_volatility(self) -> float:
        """Compute trajectory volatility."""
        if len(self.trajectory) < 3:
            return 0.0
        
        values = [p.value for p in self.trajectory]
        return np.std(values)
    
    def detect_inflection(self, lookback: int = 10) -> bool:
        """Detect if a trajectory inflection occurred recently."""
        if len(self.trajectory) < lookback:
            return False
        
        recent = list(self.trajectory)[-lookback:]
        
        # Compute second differences
        values = [p.value for p in recent]
        if len(values) < 3:
            return False
        
        first_diff = np.diff(values)
        second_diff = np.diff(first_diff)
        
        # Check for sign change in second derivative
        for i in range(len(second_diff) - 1):
            if second_diff[i] * second_diff[i + 1] < 0:
                return True
        
        return False


class MOHLRFramework(IntentAlignedOperator):
    """
    Maximum Optimization Human-in-the-Loop Reinforcement Framework.
    
    Implements the Centaur Model for human-AI symbiosis in strategic
    decision-making. The human expert identifies MaxOps (high-leverage
    intervention points) and the AI learns to recognize similar patterns.
    
    Components:
        - MaxOp Library: Store and retrieve strategic interventions
        - Feedback Collector: Gather ternary human feedback
        - Trajectory Tracker: Monitor asymptotic system behavior
        - Pattern Learner: Extract MaxOp patterns from experience
    
    Usage:
        framework = MOHLRFramework(intent)
        
        # Human identifies a MaxOp
        framework.register_maxop(maxop)
        
        # AI suggests applicable MaxOps for current state
        suggestions = framework.suggest_maxops(current_state)
        
        # Human provides feedback
        framework.provide_feedback(request_id, FeedbackType.POSITIVE)
        
        # System learns and improves suggestions
    """
    
    def __init__(self,
                 intent: IntentConfiguration,
                 domains: Optional[List[str]] = None):
        super().__init__(intent)
        
        # Core components
        self.maxop_library = MaxOpLibrary(intent)
        self.feedback_collector = TernaryFeedbackCollector()
        self.trajectory_tracker = AsymptoticTrajectoryTracker()
        
        # Default domains
        self.domains = domains or ["general", "search", "reasoning", "validation"]
        
        # Learning parameters (intent-modulated)
        self.exploration_rate = self._compute_exploration_rate()
        self.min_confidence_for_auto = self._compute_auto_threshold()
        
        # Statistics
        self.total_suggestions = 0
        self.human_overrides = 0
        self.auto_selections = 0
    
    def _compute_exploration_rate(self) -> float:
        """Compute exploration rate based on intent."""
        if self.intent.context == IntentContext.SPECIFIC:
            return 0.1  # Low exploration
        elif self.intent.context == IntentContext.GENERAL:
            return 0.3
        else:  # EXPLORATORY
            return 0.5  # High exploration
    
    def _compute_auto_threshold(self) -> float:
        """Compute confidence threshold for automatic MaxOp application."""
        if self.intent.context == IntentContext.SPECIFIC:
            return 0.95  # High bar for automation
        elif self.intent.context == IntentContext.GENERAL:
            return 0.85
        else:  # EXPLORATORY
            return 0.99  # Almost never auto in exploration mode
    
    def register_maxop(self, 
                       id: str,
                       state_pattern: Dict[str, Any],
                       action: Any,
                       expected_impact: float,
                       domain: str = "general") -> MaxOp:
        """
        Register a new MaxOp identified by human expert.
        
        This is the primary interface for human-in-the-loop learning.
        """
        maxop = MaxOp(
            id=id,
            state_pattern=state_pattern,
            action=action,
            expected_impact=expected_impact,
            domain=domain,
            source="human"
        )
        
        self.maxop_library.add_maxop(maxop)
        return maxop
    
    def suggest_maxops(self,
                        current_state: Dict[str, Any],
                        domain: Optional[str] = None,
                        top_k: int = 3) -> List[Tuple[MaxOp, float, bool]]:
        """
        Suggest applicable MaxOps for the current state.
        
        Returns:
            List of (MaxOp, confidence, can_auto_apply) tuples
        """
        self.total_suggestions += 1
        
        # Find matching MaxOps
        matches = self.maxop_library.find_matching_maxops(current_state, domain)
        
        # Limit to top_k
        matches = matches[:top_k]
        
        # Determine which can be auto-applied
        results = []
        for maxop, match_score in matches:
            combined_confidence = match_score * maxop.confidence * maxop.success_rate
            can_auto = combined_confidence >= self.min_confidence_for_auto
            results.append((maxop, combined_confidence, can_auto))
        
        return results
    
    def apply_maxop(self,
                     maxop: MaxOp,
                     current_state: Any,
                     apply_fn: Callable[[Any, Any], Any],
                     auto: bool = False) -> Tuple[Any, str]:
        """
        Apply a MaxOp and register for feedback.
        
        Args:
            maxop: The MaxOp to apply
            current_state: Current system state
            apply_fn: Function to apply the MaxOp action
            auto: Whether this is an automatic application
        
        Returns:
            (next_state, feedback_request_id)
        """
        # Track auto vs human selection
        if auto:
            self.auto_selections += 1
        else:
            self.human_overrides += 1
        
        # Apply the action
        next_state = apply_fn(current_state, maxop.action)
        
        # Record trajectory point
        point = TrajectoryPoint(
            state=next_state,
            timestamp=time.time(),
            value=self._compute_state_value(next_state),
            maxop_applied=maxop.id
        )
        self.trajectory_tracker.add_point(point)
        
        # Register for feedback
        request_id = self.feedback_collector.request_feedback(point, maxop.id)
        
        return next_state, request_id
    
    def provide_feedback(self,
                          request_id: str,
                          feedback: FeedbackType,
                          observed_impact: float = 0.0,
                          notes: str = "") -> bool:
        """
        Provide human feedback on a MaxOp application.
        
        This feedback is used to update MaxOp confidence and learn
        better pattern matching.
        """
        success = self.feedback_collector.submit_feedback(
            request_id, feedback, observed_impact, notes
        )
        
        if not success:
            return False
        
        # Extract MaxOp ID from request ID
        parts = request_id.split("_")
        if len(parts) >= 2:
            maxop_id = parts[1]
            
            # Find and update the MaxOp
            for domain_maxops in self.maxop_library.maxops.values():
                for maxop in domain_maxops:
                    if maxop.id == maxop_id:
                        maxop.update_from_feedback(feedback, observed_impact)
                        break
        
        return True
    
    def _compute_state_value(self, state: Any) -> float:
        """Compute value of a state (placeholder for actual value function)."""
        if isinstance(state, dict) and "value" in state:
            return state["value"]
        if isinstance(state, np.ndarray):
            return float(np.mean(state))
        return 0.0
    
    def get_trajectory_status(self) -> Dict[str, Any]:
        """Get current trajectory status."""
        return {
            "trend": self.trajectory_tracker.get_trend_direction(),
            "predicted_asymptote": self.trajectory_tracker.predict_asymptote(),
            "volatility": self.trajectory_tracker.get_volatility(),
            "inflection_detected": self.trajectory_tracker.detect_inflection(),
            "points_tracked": len(self.trajectory_tracker.trajectory)
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive framework statistics."""
        return {
            "total_suggestions": self.total_suggestions,
            "auto_selections": self.auto_selections,
            "human_overrides": self.human_overrides,
            "automation_rate": (
                self.auto_selections / self.total_suggestions 
                if self.total_suggestions > 0 else 0.0
            ),
            "library": self.maxop_library.get_statistics(),
            "feedback": self.feedback_collector.get_feedback_summary(),
            "trajectory": self.get_trajectory_status(),
            "exploration_rate": self.exploration_rate,
            "auto_threshold": self.min_confidence_for_auto
        }
    
    def export_learned_patterns(self) -> Dict[str, Any]:
        """
        Export learned MaxOp patterns for AI pattern recognition.
        
        This enables the AI to recognize MaxOp opportunities independently.
        """
        patterns = []
        
        for domain, maxops in self.maxop_library.maxops.items():
            for maxop in maxops:
                if maxop.times_selected >= 3 and maxop.confidence >= 0.6:
                    patterns.append({
                        "id": maxop.id,
                        "domain": domain,
                        "pattern": maxop.state_pattern,
                        "action": str(maxop.action),
                        "expected_impact": maxop.average_impact,
                        "confidence": maxop.confidence,
                        "success_rate": maxop.success_rate,
                        "samples": maxop.times_selected
                    })
        
        return {
            "exported_at": time.time(),
            "pattern_count": len(patterns),
            "patterns": patterns
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    'FeedbackType',
    'MaxOp',
    'TrajectoryPoint',
    'MaxOpLibrary',
    'TernaryFeedbackCollector',
    'AsymptoticTrajectoryTracker',
    'MOHLRFramework',
]
