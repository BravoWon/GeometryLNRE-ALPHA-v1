"""
MOHLR: Maximum Optimization Human-in-the-Loop Reinforcement
============================================================

Framework for embedding expert strategic intuition into learning systems.
Implements the Centaur Model for human-AI symbiosis.

Components:
    - MaxOp: High-leverage intervention points
    - MaxOpLibrary: Storage and pattern matching for MaxOps
    - TernaryFeedbackCollector: Human feedback with Positive/Negative/Neutral
    - AsymptoticTrajectoryTracker: Long-term trajectory monitoring
    - MOHLRFramework: Integrated framework orchestrator
"""

from .mohlr_framework import (
    FeedbackType,
    MaxOp,
    TrajectoryPoint,
    MaxOpLibrary,
    TernaryFeedbackCollector,
    AsymptoticTrajectoryTracker,
    MOHLRFramework,
)

__all__ = [
    'FeedbackType',
    'MaxOp',
    'TrajectoryPoint',
    'MaxOpLibrary',
    'TernaryFeedbackCollector',
    'AsymptoticTrajectoryTracker',
    'MOHLRFramework',
]
